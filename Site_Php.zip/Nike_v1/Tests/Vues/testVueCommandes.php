<?php

require_once 'Framework/Vue.php';
$commandes = [
    [
        'id' => '1001',
        'utilisateur_id' => '1',
        'prix' => '20',
        'detail' => 'Commande numero 1001 test',
    ],
    [
        'id' => '1002',
        'utilisateur_id' => '1',
        'prix' => '30',
        'detail' => 'Commande numero 1002 test',
    ]
];
$vue = new Vue('index', 'Commandes');
$vue->generer(['commandes' => $commandes]);

