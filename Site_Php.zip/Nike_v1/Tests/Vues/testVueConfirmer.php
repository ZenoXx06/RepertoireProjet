<?php

require_once 'Framework/Vue.php';
$article = [
        'id' => '1003',
        'commande_id' => '1',
        'nom' => 'Article test 1003',
        'prix' => '10',
    ];
$vue = new Vue('Confirmer', 'AdminArticles');
$vue->generer(['article' => $article]);

