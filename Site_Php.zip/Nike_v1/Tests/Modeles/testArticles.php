<?php

require_once 'Modele/Article.php';

$tstArticle = new Article;
$articles = $tstArticle->getArticles(1);
echo '<h3>Test getArticles : </h3>';
var_dump($articles->rowCount());

$article = $tstArticle->getArticle(1);
echo '<h3>Test getArticle : </h3>';
var_dump($article);