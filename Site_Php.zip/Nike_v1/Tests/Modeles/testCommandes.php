<?php

require_once 'Modele/Commande.php';

$tstCommande = new Commande;
$commandes = $tstCommande->getCommandes();
echo '<h3>Test getCommandes : </h3>';
var_dump($commandes->rowCount());

echo '<h3>Test getCommande : </h3>';
$commande =  $tstCommande->getCommande(1);
var_dump($commande);