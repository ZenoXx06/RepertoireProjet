<!-- Affichage -->
<!doctype html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <base href="<?= $racineWeb ?>" >
        <link rel="stylesheet" href="Contenu/css/style.css" />
        <title><?= $titre ?></title>   <!-- Élément spécifique -->
    </head>
    <body>
        <div id="global">
            <header>

                <a href=""><h1 id="titreNike">Nike</h1></a>
                <a href="tests.php">
                    <h3>TESTS</h3>
                </a>
                <a href="Apropos">
                    <h4>À propos</h4>
                </a>
                <?php if (isset($utilisateur)) : ?>
                    <h3>Bonjour <?= $utilisateur['nom'] ?>,
                        <a href="Utilisateurs/deconnecter"><small>[Se déconnecter]</small></a>
                    </h3>
                    <a href="<?= $utilisateur != null ? 'Admin' : ''; ?>Articles">
                        <h4>Afficher tous les articles de toutes les commandes</h4>
                    </a>
                <?php else : ?>
                    <h3>[<a href="Utilisateurs/index">Se connecter</a>] <small>(admin)</small></h3>
                    <a href="Articles">
                        <h4>Afficher tous les articles de toutes les commandes</h4>
                    </a>
                <?php endif; ?>
            </header>
            <div id="contenu">
                <?= $contenu ?>   <!-- Élément spécifique -->
            </div> <!-- #contenu -->
            <footer id="piedBlog">
                Site réalisé avec PHP, HTML5 et CSS.
            </footer>
        </div> <!-- #global -->
    </body>
</html>



