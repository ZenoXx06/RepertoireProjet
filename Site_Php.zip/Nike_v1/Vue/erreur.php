<?php $titre = 'Erreur'; ?>


<p>Une erreur est survenue : <?= $msgErreur ?></p>


