<?php $this->titre = "Le Blogue du prof - " . $commande['detail']; ?>

<header>
    <h1 id="titreReponses">Modifier la commande: </h1>
    <h3> <?= $commande["detail"] . " - " . $commande["prix"] . "$"?> </h3>
</header>
<form action="AdminCommandes/miseAJour" method="post">
    <h2>Modifier la commande</h2>
    <p>
        <label for="detail">Detail</label> : <input type="text" name="detail" id="detail" /> <br />
        <label for="prix">Prix</label> :  <input type="number" name="prix" id="prix" /><br />
        <input type="hidden" name="utilisateur_id" value="1" /><br />
        <input type="hidden" name="id" value="<?= $commande['id'] ?>" /><br />
        <input type="submit" value="Modifier" />
    </p>
</form>
<form action="AdminCommandes/lire/<?= $commande['id'] ?>" method="post">
    <input type="submit" value="Annuler" />
</form>

