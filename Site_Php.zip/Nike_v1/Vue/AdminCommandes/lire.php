<?php $titre = "Le Blogue du prof - " . $commande['detail']; ?>

<article>
    <header>
        <h1 class="titreCommande"><?= $commande['detail'] ?></h1>
        Commande de l'utilisateur #<?= $commande['utilisateur_id'] ?>
    </header>
    <p><?= $commande['prix'] ?> $</p>
</article>
<hr />
<header>
    <h1 id="titreCommande"><?= $commande['detail'] ?> :</h1>
</header>

<?php
foreach ($articles as $article):
    ?>
    <?php if ($article['efface'] == '0') : ?>
        <p><a href="AdminArticles/confirmer/<?= $this->nettoyer($article['id']) ?>" >
                [Effacer]</a>
                <?= $this->nettoyer($article['nom']) ?>
        </p>
    <?php else : ?>
        <p class="efface"><a href="AdminArticles/retablir/<?= $this->nettoyer($article['id']) ?>" >
                [Rétablir]</a>
                Article éffacé: <?= $this->nettoyer($article['nom']) ?>
        </p>
    <?php endif; ?>
<?php endforeach; ?>

