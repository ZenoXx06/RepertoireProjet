<?php $this->titre = 'Nike'; ?>

<a href="AdminCommandes/ajouter">
    <h2 class="titreCommande">Ajouter une commande</h2>
</a>
<?php foreach ($commandes as $commande):
    ?>

    <article>
        <header>
            <a href="AdminCommandes/lire/<?= $commande['id'] ?>">
                <h1 class="titreCommande"><?= $commande['detail'] ?></h1>
            </a>
            Commande de l'utilisateur #<?= $commande['utilisateur_id'] ?>
        </header>
        <p><?= $commande['prix'] ?> $
            <a href="AdminCommandes/modifier/<?= $commande['id'] ?>"> [modifier la commande]</a>
        </p>
    </article>
    <hr />
<?php endforeach; ?>    