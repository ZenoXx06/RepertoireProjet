<?php $titre = "Le Blogue du prof - " . $commandes['detail']; ?>

<header>
    <h1 id="titreReponses">Ajouter une commande de l'utilisateur 1 :</h1>
</header>
<form action="AdminCommandes/nouveau" method="post">
    <h2>Ajouter une commande</h2>
    <p>
        <label for="detail">Detail</label> : <input type="text" name="detail" id="detail" /> <br />
        <label for="prix">Prix</label> :  <input type="number" name="prix" id="prix" /><br />
        <input type="hidden" name="utilisateur_id" value="1" /><br />
        <input type="submit" value="Envoyer" />
    </p>
</form>

