<?php $titre = 'À propos de Nike'; ?>

<h2>Guillaume Giguère - Nike</h2>
<h3>L'application "Nike" permet de construire des commandes et d'y rajouter des articles.</h3>
<ul>
    <li>La page d'Accueil contient la liste des commandes, on y retrouve: </br></li>
    <ul>
        <li>Un lien pour tester l'application.<br>
        </li>
        <li>Un lien vers cette page.<br>
        </li>
        <li>Un lien qui permet de se connecter ou se déconnecter.<br>
        </li>
        <ul>
            <li>L'utilisateur peut rentrer ses informations pour se connecter.</li>
            <li>L'utilisateur aura ensuite accès a des nouvelles fonctionalitées (admin). </li>
        </ul>
        <li>Un lien qui permet de voir tout les articles:<br>
        </li>
        <ul>
            <li>Lorsque connecté: </li>
                <ul>
                    <li> On peut effacer des articles de toute les commandes. </li>
                    <li> On peut consulté la commande qui contient l'article.</li>
                </ul>
            <li>Lorsque déconnecté: </li>
                <ul>
                    <li> On peut consulté la commande qui contient l'article.</li>
                </ul>
        </ul>
        <li>Les différente commandes avec un lien qui permet de les voir en détail:<br>
        </li>
        <ul>
            <li>Lorsque connecté: </li>
                <ul>
                    <li> On peut effacer des articles de la commande. </li>
                </ul>
            <li>Lorsque déconnecté: </li>
                <ul>
                    <li> On peut ajouté des article dans la commande.</li>
                </ul>
        </ul>
        <li>Lorsque connecté, l'utilisateur à un lien pour modifier les commandes:<br>
        </li>
        <ul>
            <li>On peut rentrer de nouvelle informations pour la commandes. </li>
        </ul>
    <ul>
</ul>
<h4>Base de données utilisée par l'application :</h4>
<img src="Contenu/images/NikeDiagramme.png" alt=""/>