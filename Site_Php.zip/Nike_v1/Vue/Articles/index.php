<?php $this->titre = "Nike - Article" ?>

<header>
    <h1 id="titreReponses">Articles de Nike :</h1>
</header>
<?php
foreach ($articles as $article):
    ?>
    <?php if ($article['efface'] == '0') : ?>
        <p>
            <strong><?= $this->nettoyer($article['nom']) ?></strong><br/>
            <?= $this->nettoyer($article['prix']) . " $"?><br />
            <a href="Commandes/lire/<?= $this->nettoyer($article['commande_id']) ?>" >
                [Voir la commande]</a>
        </p>
    <?php endif; ?>
<?php endforeach; ?>