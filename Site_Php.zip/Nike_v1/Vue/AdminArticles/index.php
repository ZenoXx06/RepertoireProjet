<?php $this->titre = "Le site - Articles" ?>

<header>
    <h1 id="titreReponses">Article du site :</h1>
</header>
<?php
foreach ($articles as $article):
    ?>
    <?php if ($article['efface'] == '0') : ?>
        <p><a href="AdminArticles/confirmer/<?= $this->nettoyer($article['id']) ?>" >
                [Effacer]</a>
            <?= $this->nettoyer($article['nom']) ?><br />
            <a href="AdminCommandes/lire/<?= $this->nettoyer($article['commande_id']) ?>" >
                [Voir la commande]</a>
        </p>
    <?php else : ?>
        <p class="efface"><a href="AdminArticles/retablir/<?= $this->nettoyer($article['id']) ?>" >
                [Rétablir]</a>
            Article: <?= $this->nettoyer($article['nom']) ?>, effacé!
        </p>
    <?php endif; ?>
<?php endforeach; ?>