<?php $titre = "Supprimer - " . $article['nom']; ?>

<article>
    <header>
        <p><h1>
            Effacer?
        </h1>
        <p><?= $article['nom'] ?>: <?= $article['prix'] ?> $</p>
        </p>
    </header>
</article>

<form action="AdminArticles/supprimer/<?= $article['id'] ?>" method="post">
    <input type="submit" value="Oui" />
</form>
<form action="AdminCommandes/lire/<?= $article['commande_id'] ?>" method="post" >
    <input type="submit" value="Annuler" />
</form>
