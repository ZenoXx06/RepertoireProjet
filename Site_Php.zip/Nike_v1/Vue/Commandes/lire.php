<?php $titre = "Nike - " . $commande['detail']; ?>

<article>
    <header>
        <h1 class="titreCommande"><?= $commande['detail'] ?></h1>
        Commande de l'utilisateur #<?= $commande['utilisateur_id'] ?>
    </header>
    <p><?= $commande['prix'] ?> $ </p>
</article>
<hr />

<?php
foreach ($articles as $article):
    ?>
        <p>
            <strong><?= $this->nettoyer($article['nom']) ?></strong><br/>
            <?= $this->nettoyer($article['prix']) . "$"?>
        </p>
<?php endforeach; ?>

<form action="Articles/ajouter" method="post">
    <h2>Ajouter un article</h2>
    <p>
        <label for="nom">Nom de l'article</label> : <input type="text" name="nom" id="nom" /><br />
        <label for="prix">Prix de l'article</label> :  <input type="number" name="prix" id="prix" /><br />
        <input type="hidden" name="commande_id" value="<?= $commande['id'] ?>" /><br />
        <input type="submit" value="Envoyer" />
    </p>
</form>

