<?php $this->titre = 'Nike'; ?>

<?php foreach ($commandes as $commande):
    ?>

    <article>
        <header>
            <a href="Commandes/lire/<?= $commande['id'] ?>">
                <h1 class="titreCommande"><?= $commande['detail'] ?></h1>
            </a>
            Commande de l'utilisateur #<?= $commande['utilisateur_id'] ?>
        </header>
        <p><?= $commande['prix'] ?> $ </p>
    </article>
    <hr />
<?php endforeach; ?>    
