<?php

require_once 'Framework/Modele.php';

/**
 * Fournit les services d'accès aux commandes 
 * 
 * @author André Pilon
 */
class Commande extends Modele {

// Renvoie la liste de tous les commandes, triés par identifiant décroissant
    public function getCommandes() {
        $sql = 'select * from commande'
                . ' order by ID desc';
        $commandes = $this->executerRequete($sql);
        return $commandes;
    }

// Renvoie la liste de tous les commandes, triés par identifiant décroissant
    public function setCommande($commande) {
        $sql = 'INSERT INTO commande (utilisateur_id, prix, detail) VALUES(?, ?, ?)';
        $result = $this->executerRequete($sql, [$commande['utilisateur_id'], $commande['prix'], $commande['detail']]);
        return $result;
    }

// Renvoie les informations sur un commande
    function getCommande($idCommande) {
        $sql = 'select * from commande'
                . ' where ID=?';
        $commande = $this->executerRequete($sql, [$idCommande]);
        if ($commande->rowCount() == 1) {
            return $commande->fetch();  // Accès à la première ligne de résultat
        } else {
            throw new Exception("Aucune commande ne correspond à l'identifiant '$idCommande'");
        }
    }
// Met à jour un commande
    public function updateCommande($commande) {
        $sql = 'UPDATE commande'
                . ' SET utilisateur_id = ?, prix = ?, detail = ? WHERE id = ?';
        $result = $this->executerRequete($sql, [$commande['utilisateur_id'], $commande['prix'], $commande['detail'], $commande['id']]);
        return $result;
    }
    
}
