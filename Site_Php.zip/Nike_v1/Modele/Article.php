<?php

require_once 'Framework/Modele.php';

/**
 * Fournit les services d'accès aux genres musicaux 
 * 
 * @author Baptiste Pesquet
 */
class Article extends Modele {

    // Renvoie la liste des articles associés à un commande
    public function getArticles($idCommande = NULL) {
        if ($idCommande == NULL) {
            $sql = 'select * from article';
            $articles = $this->executerRequete($sql);
        } else {
            $sql = 'select * from article'
                    . ' where commande_id = ?';
            $articles = $this->executerRequete($sql, [$idCommande]);
        }
        return $articles;
    }

// Renvoie un article spécifique
    public function getArticle($id) {
        $sql = 'select * from article'
                . ' where id = ?';
        $article = $this->executerRequete($sql, [$id]);
        if ($article->rowCount() == 1) {
            return $article->fetch();  // Accès à la première ligne de résultat
        } else {
            throw new Exception("Aucun article ne correspond à l'identifiant '$id'");
        }
    }

// Efface un article
    public function deleteArticle($id) {
        $sql = 'UPDATE article'
                . ' SET efface = 1'
                . ' WHERE id = ?';
        $result = $this->executerRequete($sql, [$id]);
        return $result;
    }

    // Réactive un article
    public function restoreArticle($id) {
        $sql = 'UPDATE article'
                . ' SET efface = 0'
                . ' WHERE id = ?';
        $result = $this->executerRequete($sql, [$id]);
        return $result;
    }

// Ajoute un article associés à un commande
    public function setArticle($article) {
        $sql = 'INSERT INTO article (commande_id, nom, prix) VALUES(?, ?, ?)';
        $result = $this->executerRequete($sql, [$article['commande_id'], $article['nom'], $article['prix']]);
        return $result;
    }

}
