<?php

require_once 'Framework/Controleur.php';
require_once 'Modele/Commande.php';
require_once 'Modele/Article.php';

class ControleurCommandes extends Controleur {

    private $commande;
    private $article;

    public function __construct() {
        $this->commande = new Commande();
        $this->article = new Article();
    }

// Affiche la liste de tous les commandes du blog
    public function index() {
        $commandes = $this->commande->getCommandes();
        $this->genererVue(['commandes' => $commandes]);
    }

// Affiche les détails sur un commande
    public function lire() {
        $idCommande = $this->requete->getParametreId("id");
        $commande = $this->commande->getCommande($idCommande);
        $erreur = $this->requete->getSession()->existeAttribut("erreur") ? $this->requete->getsession()->getAttribut("erreur") : '';
        $articles = $this->article->getArticles($idCommande);
        $this->genererVue(['commande' => $commande, 'articles' => $articles, 'erreur' => $erreur]);
    }

}
