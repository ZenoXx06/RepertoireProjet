<?php

require_once 'Modele/Article.php';
require_once 'Framework/Vue.php';

class ControleurArticles extends Controleur {

    private $article;

    public function __construct() {
        $this->article = new Article();
    }

// L'action index n'est pas utilisée mais pourrait ressembler à ceci 
// en ajoutant la fonctionnalité de faire afficher tous les articles
    public function index() {
        $articles = $this->article->getArticles();
        $this->genererVue(['articles' => $articles]);
    }

// Ajoute un article à un article
    public function ajouter() {
        $article['commande_id'] = $this->requete->getParametreId("commande_id");
        $article['nom'] = $this->requete->getParametre('nom');
        $article['prix'] = $this->requete->getParametre('prix');
        $this->article->setArticle($article);
        //Recharger la page pour mettre à jour la liste des articles associés ou afficher une erreur
        $this->rediriger('Commandes', 'lire/' . $article['commande_id']);
    }

// Confirmer la suppression d'un article
    public function confirmer() {
        $id = $this->requete->getParametreId("id");
        // Lire le article à l'aide du modèle
        $article = $this->article->getArticle($id);
        $this->genererVue(['article' => $article]);
    }

// Supprimer un article
    public function supprimer() {
        $id = $this->requete->getParametreId("id");
        // Lire le article afin d'obtenir le id de l'article associé
        $article = $this->article->getArticle($id);
        // Supprimer le article à l'aide du modèle
        $this->article->deleteArticle($id);
        //Recharger la page pour mettre à jour la liste des articles associés
        $this->rediriger('Articles', 'article/' . $article['commande_id']);
    }

    // Rétablir un article
    public function retablir() {
        $id = $this->requete->getParametreId("id");
        // Lire le article afin d'obtenir le id de l'article associé
        $article = $this->article->getArticle($id);
        // Supprimer le article à l'aide du modèle
        $this->article->restoreArticle($id);
        //Recharger la page pour mettre à jour la liste des articles associés
        $this->rediriger('Articles', 'article/' . $article['article_id']);
    }

}
