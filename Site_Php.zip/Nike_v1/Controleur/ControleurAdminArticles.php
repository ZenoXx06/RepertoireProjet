<?php

require_once 'Controleur/ControleurAdmin.php';
require_once 'Modele/Article.php';

class ControleurAdminArticles extends ControleurAdmin {

    private $article;

    public function __construct() {
        $this->article = new Article();
    }

// L'action index n'est pas utilisée mais pourrait ressembler à ceci 
// en ajoutant la fonctionnalité de faire afficher tous les articles
    public function index() {
        $articles = $this->article->getArticles();
        $this->genererVue(['articles' => $articles]);
    }
  
// Confirmer la suppression d'un article
    public function confirmer() {
        $id = $this->requete->getParametreId("id");
        // Lire le article à l'aide du modèle
        $article = $this->article->getArticle($id);
        $this->genererVue(['article' => $article]);
    }

// Supprimer un article
    public function supprimer() {
        $id = $this->requete->getParametreId("id");
        // Lire le article afin d'obtenir le id de l'article associé
        $article = $this->article->getArticle($id);
        // Supprimer le article à l'aide du modèle
        $this->article->deleteArticle($id);
        //Recharger la page pour mettre à jour la liste des articles associés
        $this->rediriger('AdminCommandes', 'lire/' . $article['commande_id']);
    }

    // Rétablir un article
    public function retablir() {
        $id = $this->requete->getParametreId("id");
        // Lire le article afin d'obtenir le id de l'article associé
        $article = $this->article->getArticle($id);
        // Supprimer le article à l'aide du modèle
        $this->article->restoreArticle($id);
        //Recharger la page pour mettre à jour la liste des articles associés
        $this->rediriger('AdminCommandes', 'lire/' . $article['commande_id']);
    }

}
