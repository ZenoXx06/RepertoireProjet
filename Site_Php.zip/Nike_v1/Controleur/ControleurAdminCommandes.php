<?php

require_once 'Controleur/ControleurAdmin.php';
require_once 'Modele/Commande.php';
require_once 'Modele/Article.php';

class ControleurAdminCommandes extends ControleurAdmin {

    private $commande;
    private $article;

    public function __construct() {
        $this->commande = new Commande();
        $this->article = new Article();
    }

// Affiche la liste de tous les commandes du blog
    public function index() {
        $commandes = $this->commande->getCommandes();
        $this->genererVue(['commandes' => $commandes]);
    }

// Affiche les détails sur un commande
    public function lire() {
        $idCommande = $this->requete->getParametreId("id");
        $commande = $this->commande->getCommande($idCommande);
        $erreur = $this->requete->getSession()->existeAttribut("erreur") ? $this->requete->getsession()->getAttribut("erreur") : '';
        $articles = $this->article->getArticles($idCommande);
        $this->genererVue(['commande' => $commande, 'articles' => $articles, 'erreur' => $erreur]);
    }

    public function ajouter() {
        $vue = new Vue("Ajouter");
        $this->genererVue();
    }

// Enregistre le nouvel commande et retourne à la liste des commandes
    public function nouveau() {
        $commande['utilisateur_id'] = $this->requete->getParametreId('utilisateur_id');
        $commande['prix'] = $this->requete->getParametre('prix');
        $commande['detail'] = $this->requete->getParametre('detail');
        $this->commande->setCommande($commande);
        $this->executerAction('index');
    }

// Modifier un commande existant    
    public function modifier() {
        $id = $this->requete->getParametreId('id');
        $commande = $this->commande->getCommande($id);
        $this->genererVue(['commande' => $commande]);
    }

// Enregistre l'commande modifié et retourne à la liste des commandes
    public function miseAJour() {
        $commande['id'] = $this->requete->getParametreId('id');
        $commande['utilisateur_id'] = $this->requete->getParametreId('utilisateur_id');
        $commande['prix'] = $this->requete->getParametre('prix');
        $commande['detail'] = $this->requete->getParametre('detail');
        $this->commande->updateCommande($commande);
        $this->executerAction('index');
    }

}
