import sys
from machine import Pin, I2C
import time
import random
from I2C_LCD import I2CLcd
import _thread

distance = 0
velocite_son = 340
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
i2c_add = i2c.scan()[0]
lcd = I2CLcd(i2c, i2c_add, 2, 16) 
trigger = Pin(19, Pin.OUT)
echo = Pin(18, Pin.IN)
ledVerte = Pin(14, Pin.OUT)
ledRouge = Pin(15, Pin.OUT)
terminateThread = False
rep = ""
mesure = 0
distanceJ1 = 0
distanceJ2 = 0
gagnant = ""
btn1 = Pin(17, Pin.IN, Pin.PULL_UP)
btn2 = Pin(16, Pin.IN, Pin.PULL_UP)
btn1Prev=btn1.value()
btn2Prev=btn2.value()

def lectureRep():
    global terminateThread, rep
    while True:
        if terminateThread:
            break
        rep = sys.stdin.readline().strip()
        
def led_verteOn():
    ledVerte.value(1)
def led_verteOff():
    ledVerte.value(0)
def led_rougeOn():
    ledRouge.value(1)
def led_rougeOff():
    ledRouge.value(0)

def lectureDistance():
            trigger.value(1)
            time.sleep_us(10)
            trigger.value(0)
            while not echo.value():
                pass
            ping_debut = time.ticks_us()
            while echo.value():
                pass
            ping_fin = time.ticks_us()
            distance_temps = time.ticks_diff(ping_fin, ping_debut) // 2
            distance = (velocite_son * distance_temps) // 10000
            return distance
        
def clignoterVert():
    led_verteOn()
    time.sleep(0.2)
    led_verteOff()
    time.sleep(0.2)
    led_verteOn()
    time.sleep(0.2)
    led_verteOff()
    time.sleep(0.2)
    led_verteOn()
    time.sleep(0.2)
    led_verteOff()
    time.sleep(0.2)
    led_verteOn()
    time.sleep(0.2)
    led_verteOff()
    time.sleep(0.2)
    
def clignoterRouge():
    led_rougeOn()
    time.sleep(0.2)
    led_rougeOff()
    time.sleep(0.2)
    led_rougeOn()
    time.sleep(0.2)
    led_rougeOff()
    time.sleep(0.2)
    led_rougeOn()
    time.sleep(0.2)
    led_rougeOff()
    time.sleep(0.2)
    led_rougeOn()
    time.sleep(0.2)
    led_rougeOff()
    time.sleep(0.2)
    
while True:
    terminateThread = False
    rep = ""
    mesure = 0
    distanceJ1 = 0
    distanceJ2 = 0
    gagnant = ""
    _thread.start_new_thread(lectureRep, ())
    try:
        while True:
            if rep.lower() == "active":
                lcd.clear()
                lcd.putstr("Veuillez lancer")
                lcd.move_to(0,1)
                lcd.putstr("une partie")
                rep = ""
            elif rep.lower() == "sauvegarder":
                lcd.clear()
                lcd.putstr("Une partie a")
                lcd.move_to(0,1)
                lcd.putstr("ete sauvegarder")
                print((gagnant))
                clignoterVert()
                time.sleep(2)
                rep = "ACTIVE"
            elif rep.lower() == "nonsauvegarder":
                lcd.clear()
                lcd.putstr("Rentrez les noms")
                clignoterRouge()
                time.sleep(2)
                rep = "ACTIVE"
            elif rep.lower() == "commencer":
                lcd.clear()
                lcd.putstr("La mesure est: ")
                lcd.move_to(0,1)
                mesure = random.randint(1, 100)
                lcd.putstr(str(mesure) + " cm")
                time.sleep(3)
                lcd.clear()
                lcd.putstr("Joueur 1")
                lcd.move_to(0,1)
                lcd.putstr("C'est a vous")
                fini = False
                while fini == False:
                    distance = lectureDistance()
                    if distance > 100:
                        distance = 100
                    if btn1.value() == 1 and btn1.value() != btn1Prev:
                        btn1Prev = btn1.value()
                        clignoterVert()
                        distanceJ1 = distance
                        lcd.clear()
                        lcd.putstr("Joueur 2")
                        lcd.move_to(0,1)
                        lcd.putstr("C'est a vous")
                        time.sleep(0.5)
                        while fini == False:
                            distance = lectureDistance()
                            if distance > 100:
                                distance = 100
                            if btn1.value() == 1 and btn1.value() != btn1Prev:
                                btn1Prev = btn1.value()
                                clignoterVert()
                                distanceJ2 = distance
                                fini = True
                                rep = "FINI"
                            elif btn2.value() == 1 and btn2.value() != btn2Prev:
                                btn2Prev = btn2.value()
                                lcd.clear()
                                lcd.putstr("La distance est:")
                                lcd.move_to(0,1)
                                lcd.putstr(str(mesure) + " cm")
                                time.sleep(2)
                                lcd.clear()
                                lcd.putstr("Joueur 2")
                                lcd.move_to(0,1)
                                lcd.putstr("C'est a vous")
                            btn1Prev = btn1.value()
                            btn2Prev = btn2.value()
                            time.sleep(0.1)
                    elif btn2.value() == 1 and btn2.value() != btn2Prev:
                        btn2Prev = btn2.value()
                        lcd.clear()
                        lcd.putstr("La distance est:")
                        lcd.move_to(0,1)
                        lcd.putstr(str(mesure) + " cm")
                        time.sleep(2)
                        lcd.clear()
                        lcd.putstr("Joueur 1")
                        lcd.move_to(0,1)
                        lcd.putstr("C'est a vous")
                    btn1Prev = btn1.value()
                    btn2Prev = btn2.value()
                    time.sleep(0.1)
            elif rep.lower() == "fini":
                lcd.clear()
                lcd.putstr("La partie")
                lcd.move_to(0,1)
                lcd.putstr("est fini")
                clignoterRouge()
                diff1 = abs(mesure - distanceJ1)
                diff2 = abs(mesure - distanceJ2)
                if diff1 < diff2:
                    lcd.clear()
                    lcd.putstr("Le gagnant est:")
                    lcd.move_to(0,1)
                    lcd.putstr("Le joueur 1")
                    gagnant = "Joueur1"
                elif diff2 < diff1:
                    lcd.clear()
                    lcd.putstr("Le gagnant est:")
                    lcd.move_to(0,1)
                    lcd.putstr("Le joueur 2")
                    gagnant = "Joueur2"
                else:
                    lcd.clear()
                    lcd.putstr("Le gagnant est:")
                    lcd.move_to(0,1)
                    lcd.putstr("Egalite")
                    gagnant = "Egalite"
                time.sleep(2)
                lcd.clear()
                lcd.putstr("Dist. J1: " + str(distanceJ1) + " cm")
                lcd.move_to(0,1)
                lcd.putstr("Dist. J2: " + str(distanceJ2) + " cm")
                time.sleep(5)
                rep = "active"
    except KeyboardInterrupt:
        terminateThread = True