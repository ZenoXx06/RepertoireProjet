import tkinter as tk
from tkinter import ttk
import serial

s = serial.Serial("COM9", timeout=0.05)

class Partie:
    'Classe pour l\'objet partie'
    
    def __init__(self, joueur1, joueur2, gagnant):
        self.joueur1 = joueur1
        self.joueur2 = joueur2
        self.gagnant = gagnant
        
        
    def __repr__(self):
        return self.joueur1 + " VS " + self.joueur2 + " - Gagnant = " + self.gagnant
    
    def afficherMesure(self):
        print("Joueur1: " + self.joueur1 
              + " - joueur2: " + self.joueur2
              + " - Gagnant3: " + self.gagnant)

partie = Partie(joueur1="", joueur2="", gagnant="")

class Interface(tk.Tk):
    def __init__(self):
        super().__init__()
        #Paramètre de la page
        self.title("Graphique")
        self.geometry("400x400")
        
class FenetrePrincipal(ttk.Frame):
    def __init__(self, conteneur):
        super().__init__(conteneur)
        options = {"padx" : 2, "pady" : 2}
        self.lbl_titre = ttk.Label(self, text = "Le Jeux de la mesure")
        self.lbl_titre.pack(**options)
        
        self.lbl_titre = ttk.Label(self, text = "Soyez le plus proche de la mesure!")
        self.lbl_titre.pack(**options)
        
        self.lbl_regle = ttk.Label(self, text = "Bouton 1 = Confirmer distance \n Bouton 2 = Revoir la distance")
        self.lbl_regle.pack(**options)
        
        self.btn_allumer = ttk.Button(self, text = "Démarrer le jeux")
        self.btn_allumer["command"] = self.allumer
        self.btn_allumer.pack(**options)
        
        self.btn_mesurer= ttk.Button(self, text = "Commencer une partie", state="disabled")
        self.btn_mesurer["command"] = self.commencer
        self.btn_mesurer.pack(**options)
        
        self.lbl_regleSauvegarde = ttk.Label(self, text = "Rentrez le nom des joueurs avant de sauvegarder une partie")
        self.lbl_regleSauvegarde.pack(**options)
        
        self.lbl_joueur1 = ttk.Label(self, text = "Joueur1: ")
        self.lbl_joueur1.pack(**options)
        
        self.joueur1 = tk.Text(self, width=20, height=1, state="disabled")
        self.joueur1.pack(**options)
        
        self.lbl_joueur2 = ttk.Label(self, text = "Joueur2:")
        self.lbl_joueur2.pack(**options)
        
        self.joueur2 = tk.Text(self, width=20, height=1, state="disabled")
        self.joueur2.pack(**options)
        
        self.btn_sauvegarder = ttk.Button(self, text = "Sauvegarder la dernière partie", state="disabled")
        self.btn_sauvegarder["command"] = self.sauvegarder
        self.btn_sauvegarder.pack(**options)
        
        self.listeMesure = tk.Listbox(self, width=50, height=6, justify="center")
        self.listeMesure.pack(**options)
        
        self.pack(**options)
        
    def allumer(self):
        s.write(b"ACTIVE\n")
        self.btn_mesurer.config(state="normal")
        self.btn_allumer.config(state="disabled")
        
    def commencer(self):
        s.write(b"COMMENCER\n")
        self.btn_sauvegarder.config(state="normal")
        self.joueur1.config(state="normal")
        self.joueur2.config(state="normal")
    
    def sauvegarder(self):
        if self.joueur1.compare("end-1c", "==", "1.0") or self.joueur2.compare("end-1c", "==", "1.0"):
            s.write(b"NONSAUVEGARDER\n")
        else:
            s.write(b"SAUVEGARDER\n")
            data_in = s.readline()
            gagnant = str(data_in)[2:-5]
            if gagnant == "Joueur1" or gagnant == "Joueur2" or gagnant == "Egalite" :
                partie.joueur1 = self.joueur1.get("1.0",'end-1c')
                partie.joueur2 = self.joueur2.get("1.0",'end-1c')
                if gagnant == "Joueur1":
                    gagnant = partie.joueur1
                elif gagnant == "Joueur2":
                    gagnant = partie.joueur2
                partie.gagnant = str(gagnant)
                self.listeMesure.insert("end", partie)
                self.btn_sauvegarder.config(state="disabled")
                self.joueur1.config(state="disabled")
                self.joueur2.config(state="disabled")
            
if __name__ == "__main__":  
    app = Interface()
    fenetre = FenetrePrincipal(app)
    app.mainloop()