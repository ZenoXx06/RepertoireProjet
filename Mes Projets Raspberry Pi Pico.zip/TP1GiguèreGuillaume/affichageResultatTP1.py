from tkinter import *
import tkinter as tk
from tkinter import ttk
import json

class Fenetre():
    def __init__(self, principal):
        #Paramètre de la page
        self.principal = principal
        principal.title("Travail Pratique 1 - Guillaume Giguère")
        principal.geometry("370x360")
        
        #button
        self.btn_afficher = tk.Button(principal, text="Ajouter les données", command = self.btn_afficher_clicked, bg="#6eff86", font="Vani")

        #comboBox
        self.dateChoisi = tk.StringVar()
        self.dateCombo = ttk.Combobox(principal, width=25, textvariable=self.dateChoisi)
        self.dateCombo['values'] = " "
        self.dateCombo['state'] = "readonly"
        self.dateCombo.bind('<<ComboboxSelected>>', self.onSelectCombo)
        
        #listBox
        self.listeJoueur = tk.Listbox(principal, width=25, height=2)
        self.listeJoueur.bind('<<ListboxSelect>>', self.onSelectListe)
        
        #text
        self.listeReponse = tk.Text(principal, width=22, height=10)
        
        #label
        self.pointage = tk.Label(principal, text="Le pointage: ", font="Vani", bg="#dcdcdc")
        self.bonneRep = tk.Label(principal, text="Le nombre de bonne réponse: ", font="Vani", bg="#dcdcdc")

        #Mise des éléments dans la page
        self.dateCombo.pack()
        self.listeJoueur.pack()
        self.listeReponse.pack()
        self.btn_afficher.pack(side=BOTTOM)
        self.pointage.pack(side=BOTTOM)
        self.bonneRep.pack(side=BOTTOM)
        
    #Afficher les dates du fichier
    def btn_afficher_clicked(self):
        ctr = 0
        while len(listePartie) > ctr:
            self.dateCombo['values'] += (listePartie[ctr].datePartie,)
            ctr += 1
        self.btn_afficher['state'] = (DISABLED)
    
    #Afficher les joueurs correspondant à la date
    def onSelectCombo(self, evt):
        self.listeJoueur.delete(0, 2)
        self.listeReponse.delete("1.0", "end")
        self.listeJoueur.insert(END, listePartie[self.dateCombo.current()].nomJoueur1)
        self.listeJoueur.insert(END, listePartie[self.dateCombo.current()].nomJoueur2)
    
    #Afficher les infos correspondant au joueurs
    def onSelectListe(self, evt):
        self.listeReponse.delete("1.0", "end")
        self.pointage['text'] = ""
        self.bonneRep['text'] = ""
        ctr = 0
        if self.listeJoueur.curselection() == (0,):
            while len(listePartie[self.dateCombo.current()].listeReponsesJ1) > ctr:
                self.listeReponse.insert(END, str(listePartie[self.dateCombo.current()].listeReponsesJ1[ctr]))
                self.listeReponse.insert(END, "\n")
                ctr += 1
            self.pointage['text'] = "Le pointage: " + str(listePartie[self.dateCombo.current()].pointageJ1)
            self.bonneRep['text'] = "Le nombre de bonne réponse: " + str(listePartie[self.dateCombo.current()].nb_bonnesRepJ1)
        else:
            while len(listePartie[self.dateCombo.current()].listeReponsesJ2) > ctr:
                self.listeReponse.insert(END, str(listePartie[self.dateCombo.current()].listeReponsesJ2[ctr]))
                self.listeReponse.insert(END, "\n")
                ctr += 1
            self.pointage['text'] = "Le pointage: " + str(listePartie[self.dateCombo.current()].pointageJ2)
            self.bonneRep['text'] = "Le nombre de bonne réponse: " + str(listePartie[self.dateCombo.current()].nb_bonnesRepJ2)
    
#Création de la liste de partie
class Partie:
        def __init__(self, datePartie, nomJoueur1, nomJoueur2, listeReponsesJ1, listeReponsesJ2, nb_bonnesRepJ1, nb_bonnesRepJ2, pointageJ1, pointageJ2):
            self.datePartie = datePartie
            self.nomJoueur1 = nomJoueur1
            self.nomJoueur2 = nomJoueur2
            self.listeReponsesJ1 = listeReponsesJ1
            self.listeReponsesJ2 = listeReponsesJ2
            self.nb_bonnesRepJ1 = nb_bonnesRepJ1
            self.nb_bonnesRepJ2 = nb_bonnesRepJ2
            self.pointageJ1 = pointageJ1
            self.pointageJ2 = pointageJ2
        
        def __repr__(self):
            return self.datePartie + self.nomJoueur1 + self.nomJoueur2 + self.listeReponsesJ1 + self.listeReponsesJ2 + self.nb_bonnesRepJ1 + self.nb_bonnesRepJ2 + self.pointageJ1 + self.pointageJ2
    
        def afficherPartie(self):
            print("Date: " + self.datePartie 
              +"- Nom Joueur1: " + self.nomJoueur1 
              + "- Nom Joueur2: " + self.nomJoueur2
              + "- Liste des réponses du joueur1: " + self.listeReponsesJ1
              + "- Liste des réponses du joueur2: " + self.listeReponsesJ2
              + "- Nombre de bonne réponse du joueur1: " + self.nb_bonnesRepJ1
              + "- Nombre de bonne réponse du joueur2: " + self.nb_bonnesRepJ2
              + "- Pointage du joueur1: " + self.pointageJ1
              + "- Pointage du joueur2: " + self.pointageJ2)
            
#Création de la liste des objets du fichier JSON
listePartie = []
with open("historique.json", encoding='utf-8') as fichier:
        data = json.load(fichier)
        for val in data['partie']:
            partie = Partie((str(val['date'])).replace(" ", "-"), str(val['J1']), 
                            str(val['J2']), (val['RepJ1']), (val['RepJ2']),
                            str(val['NbBonneRepJ1']), str(val['NbBonneRepJ2']),
                            str(val['PointJ1']), str(val['PointJ2']))
            listePartie.append(partie)
            
#Création 
root = Tk()
app = Fenetre(root)
root.configure(bg="#dcdcdc")
root.mainloop()
