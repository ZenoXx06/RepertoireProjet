class Partie:
    'Classe pour lobjet partie'
    
    def __init__(self, datePartie, nomJoueur1, nomJoueur2, listeReponsesJ1, listeReponsesJ2, nb_bonnesRepJ1, nb_bonnesRepJ2, pointageJ1, pointageJ2):
        self.datePartie = datePartie
        self.nomJoueur1 = nomJoueur1
        self.nomJoueur2 = nomJoueur2
        self.listeReponsesJ1 = listeReponsesJ1
        self.listeReponsesJ2 = listeReponsesJ2
        self.nb_bonnesRepJ1 = nb_bonnesRepJ1
        self.nb_bonnesRepJ2 = nb_bonnesRepJ2
        self.pointageJ1 = pointageJ1
        self.pointageJ2 = pointageJ2
        
    def __repr__(self):
        return self.datePartie + self.nomJoueur1 + self.nomJoueur2
    
    def afficherPartie(self):
        print("Date: " + self.datePartie 
              +"- Nom Joueur1: " + self.nomJoueur1 
              + "- Nom Joueur2: " + self.nomJoueur2
              + "- Liste des réponses du joueur1: " + self.listeReponsesJ1
              + "- Liste des réponses du joueur2: " + self.listeReponsesJ2
              + "- Nombre de bonne réponse du joueur1: " + self.nb_bonnesRepJ1
              + "- Nombre de bonne réponse du joueur2: " + self.nb_bonnesRepJ2
              + "- Pointage du joueur1: " + self.pointageJ1
              + "- Pointage du joueur2: " + self.pointageJ2)
import time
import random
import json
import datetime
import codecs
import os

# Présentation et prise de nom
print("-------------------------------------------------------")        
print("  Travail Pratique 1 -- QUIZ 4B5 -- Guillaume Giguère")
print("-------------------------------------------------------")
print("    Choisissez les bonnes réponses avec les lettres")
print("            Vous avez un droit de réplique!")
print("-------------------------------------------------------")

nomJoueur1 = input("Entrez le nom du joueur1: ")
while nomJoueur1 == "":
    print("Ce n'est pas un nom valide")
    time.sleep(1)
    nomJoueur1 = input("Entrez le nom du joueur1: ")
nomJoueur2 = input("Entrez le nom du joueur2: ")
while nomJoueur2 == "":
    print("Ce n'est pas un nom valide")
    time.sleep(1)
    nomJoueur2 = input("Entrez le nom du joueur2: ")
chiffre = random.randint(1, 2)
if chiffre == 1:
    premier = nomJoueur1
    deuxieme = nomJoueur2
else:
    premier = nomJoueur2
    deuxieme = nomJoueur1
    
print("Chargement de l'ordre - ", end=" ",flush=True)
time.sleep(0.4)
for i in range(2):
   time.sleep(0.4)
   print(".",end=" ",flush=True)
   time.sleep(0.4)
time.sleep(0.4)
print(".")

print("-------------------------------------------------------")
print("            Ordre de réponse aux questions")
print("-------------------------------------------------------")
print("1- " + premier)
print("2- " + deuxieme)
print("-------------------------------------------------------")
time.sleep(1.5)

# Ouverture du Json
with open("questions.json", encoding='utf-8') as fichier:
    data = json.load(fichier)
i = 0
listeReponseJ1 = []
listeReponseJ2 = []
nb_bonnesRepJ1 = 0
nb_bonnesRepJ2 = 0
pointageJ1 = 0
pointageJ2 = 0
estcePremierJ1 = False
if premier == nomJoueur1:
    estcePremierJ1 = True
    
for val in data['liste de question']:
# Affichage de la question
    i += 1
    print(str(i) + ") " + str(val['q']))
    print("<a> " + str(val['a']))
    print("<b> " + str(val['b']))
    print("<c> " + str(val['c']))
    
# Si c'est une question pour le premier joueur
    if i % 2 != 0:
       rep = input(premier + ", entrez votre réponse (a/b/c): ")
       while rep != 'a' and rep != 'b' and rep != 'c':
         print("Ce n'est pas une réponse valide")
         time.sleep(1)
         rep = input(premier + ", entrez votre réponse (a/b/c): ")
       if estcePremierJ1:
          listeReponseJ1.append(val[rep])
       else:
          listeReponseJ2.append(val[rep])
       if rep == str(val['rep']):
          print("Bonne réponse!")
          if estcePremierJ1:
            nb_bonnesRepJ1 += 1
            pointageJ1 += val['pts']
          else:
            nb_bonnesRepJ2 += 1
            pointageJ2 += val['pts']
          time.sleep(0.5)
          print("-------------------------------------------------------")
          time.sleep(0.5)
       else:
          rep = input("Mauvaise réponse. Réplique à " + deuxieme + ", entrez votre réponse (a/b/c): ")
          while rep != 'a' and rep != 'b' and rep != 'c':
            print("Ce n'est pas une réponse valide")
            time.sleep(1)
            rep = input(deuxieme + " , entrez votre réponse (a/b/c): ")
          if estcePremierJ1:
             listeReponseJ2.append(val[rep])
          else:
             listeReponseJ1.append(val[rep])
          if rep == str(val['rep']):
            print("Bonne réponse!")
            if estcePremierJ1:
               nb_bonnesRepJ2 += 1
               pointageJ2 += val['pts']
            else:
               nb_bonnesRepJ1 += 1
               pointageJ1 += val['pts']
            time.sleep(0.5)
            print("-------------------------------------------------------")
            time.sleep(0.5)
          else:
              print("Dommage, aucun point n'a été gagné cet manche")
              time.sleep(0.5)
              print("La bonne réponse était: " + str(val['rep']))
              time.sleep(0.5)
              print("-------------------------------------------------------")
              time.sleep(0.5)
              
# Si c'est une question pour le deuxième joueur
    else:
       rep = input(deuxieme + ", entrez votre réponse (a/b/c): ")
       while rep != 'a' and rep != 'b' and rep != 'c':
         print("Ce n'est pas une réponse valide")
         time.sleep(1)
         rep = input(deuxieme + ", entrez votre réponse (a/b/c): ")
       if estcePremierJ1:
         listeReponseJ2.append(val[rep])
       else:
         listeReponseJ1.append(val[rep])
       if rep == str(val['rep']):
          print("Bonne réponse!")
          if estcePremierJ1:
            nb_bonnesRepJ2 += 1
            pointageJ2 += val['pts']
          else:
            nb_bonnesRepJ1 += 1
            pointageJ1 += val['pts']
          time.sleep(0.5)
          print("-------------------------------------------------------")
          time.sleep(0.5)
       else:
          rep = input("Mauvaise réponse. Réplique à " + premier + ", entrez votre réponse (a/b/c): ")
          while rep != 'a' and rep != 'b' and rep != 'c':
            print("Ce n'est pas une réponse valide")
            time.sleep(1)
            rep = input(premier + " , entrez votre réponse (a/b/c): ")
          if estcePremierJ1:
             listeReponseJ1.append(val[rep])
          else:
             listeReponseJ2.append(val[rep])
          if rep == str(val['rep']):
            print("Bonne réponse!")
            if estcePremierJ1:
              nb_bonnesRepJ1 += 1
              pointageJ1 += val['pts']
            else:
              nb_bonnesRepJ2 += 1
              pointageJ2 += val['pts']
            time.sleep(0.5)
            print("-------------------------------------------------------")
            time.sleep(0.5)
          else:
              print("Dommage, aucun point n'a été gagné cet manche")
              time.sleep(0.5)
              print("La bonne réponse était: " + str(val['rep']))
              time.sleep(0.5)
              print("-------------------------------------------------------")
              time.sleep(0.5)
              
# Affichage des résultats
print(nomJoueur1 + ":")
print("Nombre de bonne réponses: " + str(nb_bonnesRepJ1))
print("Nombre de points: " + str(pointageJ1))
time.sleep(0.8)
print("-------------------------------------------------------")
print("-------------------------------------------------------")
time.sleep(0.8)
print(nomJoueur2 + ":")
print("Nombre de bonne réponses: " + str(nb_bonnesRepJ2))
print("Nombre de points: " + str(pointageJ2))
print("-------------------------------------------------------")

# Création de l'objet, du dictionnaire et du tranfert dans le fichier JSON
partie = Partie(datetime.datetime.now(), nomJoueur1, nomJoueur2, listeReponseJ1, listeReponseJ2, nb_bonnesRepJ1, nb_bonnesRepJ2, pointageJ1, pointageJ2)
partieDict = {"date": str(partie.datePartie),
              "J1": partie.nomJoueur1,
              "J2": partie.nomJoueur2,
              "RepJ1": partie.listeReponsesJ1,
              "RepJ2": partie.listeReponsesJ2,
              "NbBonneRepJ1": partie.nb_bonnesRepJ1,
              "NbBonneRepJ2": partie.nb_bonnesRepJ2,
              "PointJ1": partie.pointageJ1,
              "PointJ2": partie.pointageJ2
              }
j = 0
if os.stat("historique.json").st_size != 0:
  with open("historique.json", encoding='utf-8') as f:
    data = json.load(f)
    for conteur in data['partie']:
      j += 1
with codecs.open("historique.json", "ab+", encoding='utf-8') as fichierPartie:
  if j == 0:
    fichierPartie.write("{\n")
    fichierPartie.write("   \"partie\": [ \n")
  else:
    fichierPartie.seek(-4, 2)
    fichierPartie.truncate()
    fichierPartie.write(",")
  json.dump(partieDict, fichierPartie, ensure_ascii=False, indent=4, sort_keys=True)
  fichierPartie.write("\n    ]")
  fichierPartie.write("\n}")