import tkinter as tk
from tkinter import ttk
import serial

s = serial.Serial("COM9")

class Mesure:
    'Classe pour l\'objet mesure'
    
    def __init__(self, description, dataMesure):
        self.description = description
        self.dataMesure = dataMesure
        
        
    def __repr__(self):
        return "Description: " + self.description + " - Mesure: " + self.dataMesure + " cm"
    
    def afficherMesure(self):
        print("Description: " + self.description 
              +" - Mesure: " + self.dataMesure + " cm" )

mesure = Mesure(description="", dataMesure="")

class Interface(tk.Tk):
    def __init__(self):
        super().__init__()
        #Paramètre de la page
        self.title("Graphique")
        self.geometry("400x400")
        
class FenetrePrincipal(ttk.Frame):
    def __init__(self, conteneur):
        super().__init__(conteneur)
        options = {"padx" : 2, "pady" : 2}
        self.lbl_texte = ttk.Label(self, text = "État")
        self.lbl_texte.pack(**options)
        
        self.btn_allumer = ttk.Button(self, text = "Démarrer le système")
        self.btn_allumer["command"] = self.allumer
        self.btn_allumer.pack(**options)
        
        self.description = tk.Text(self, width=30, height=8, state="disabled")
        self.description.pack(**options)
        
        self.btn_mesurer= ttk.Button(self, text = "Prendre mesure", state="disabled")
        self.btn_mesurer["command"] = self.mesurer
        self.btn_mesurer.pack(**options)
        
        self.listeMesure = tk.Listbox(self, width=40, height=4)
        self.listeMesure.pack(**options)
        
        self.pack(**options)
        
    def allumer(self):
        s.write(b"ON\n")
        self.lbl_texte["text"] = "Allumer"
        self.lbl_texte.config(foreground="green")
        self.description.config(state="normal")
        self.btn_mesurer.config(state="normal")
        
    def mesurer(self):
        if self.description.compare("end-1c", "==", "1.0"):
            s.write(b"NONMESURE\n")
            self.lbl_texte["text"] = "Éteint"
            self.lbl_texte.config(foreground="red")
            self.description.config(state="disabled")
            self.btn_mesurer.config(state="disabled")
            self.btn_allumer.config(state="disabled")
        else:
            s.write(b"MESURE\n")
            data_in = s.readline()
            distance = str(data_in)[2:-5]
            mesure.description = self.description.get("1.0",'end-1c')
            mesure.dataMesure = str(distance)
            self.listeMesure.insert("end", mesure)
        
if __name__ == "__main__":  
    app = Interface()
    fenetre = FenetrePrincipal(app)
    app.mainloop()