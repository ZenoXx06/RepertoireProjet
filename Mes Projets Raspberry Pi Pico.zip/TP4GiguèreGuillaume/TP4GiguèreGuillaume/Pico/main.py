import sys
from machine import Pin, I2C
import time
from I2C_LCD import I2CLcd
import _thread

distance = 0
velocite_son = 340
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
i2c_add = i2c.scan()[0]
lcd = I2CLcd(i2c, i2c_add, 2, 16) 
trigger = Pin(19, Pin.OUT)
echo = Pin(18, Pin.IN)
ledVerte = Pin(14, Pin.OUT)
ledRouge = Pin(15, Pin.OUT)
terminateThread = False
rep = ""

def lectureRep():
    global terminateThread, rep
    while True:
        if terminateThread:
            break
        rep = sys.stdin.readline().strip()
        
def led_verteOn():
    ledVerte.value(1)
def led_verteOff():
    ledVerte.value(0)
def led_rougeOn():
    ledRouge.value(1)
def led_rougeOff():
    ledRouge.value(0)

def lectureDistance():
            trigger.value(1)
            time.sleep_us(10)
            trigger.value(0)
            
            while not echo.value():
                pass
            ping_debut = time.ticks_us()
            
            while echo.value():
                pass
            ping_fin = time.ticks_us()
            
            distance_temps = time.ticks_diff(ping_fin, ping_debut) // 2
            distance = (velocite_son * distance_temps) // 10000
            return distance
        
while True:
    terminateThread = False
    rep = ""
    _thread.start_new_thread(lectureRep, ())
    try:
        while True:
            if rep.lower() == "mesure":
                print((distance))
                lcd.clear()
                lcd.putstr("La mesure")
                lcd.move_to(0,1)
                lcd.putstr("à ete prise") 
                led_rougeOff()
                led_verteOn()
                time.sleep(0.4)
                led_verteOff()
                time.sleep(0.4)
                led_verteOn()
                time.sleep(0.4)
                led_verteOff()
                time.sleep(0.4)
                led_verteOn()
                rep = "ON"
            elif rep.lower() == "nonmesure":
                lcd.clear()
                lcd.putstr("Manque")
                lcd.move_to(0,1)
                lcd.putstr("Description")
                led_verteOff()
                led_rougeOn()
                time.sleep(0.4)
                led_rougeOff()
                time.sleep(0.4)
                led_rougeOn()
                time.sleep(0.4)
                led_rougeOff()
                time.sleep(0.4)
                led_rougeOn()
                time.sleep(1)
                lcd.clear()
                lcd.putstr("Le systeme")
                lcd.move_to(0,1)
                lcd.putstr("s'est arreter")
                led_verteOff()
                led_rougeOn()
                raise Exception
            elif rep.lower() == "on":
                led_verteOn()
                led_rougeOff()
                while rep.lower() == "on":
                    distance = lectureDistance()
                    lcd.clear()
                    lcd.putstr("La distance est:")
                    lcd.move_to(0,1)
                    if distance <= 400:
                        lcd.putstr(str(distance) + " cm")
                    else:
                        distance = "400+"
                        lcd.putstr("Trop Loin")
                    ctr = 0
                    while ctr < 10:
                        if rep.lower() == "on":
                            time.sleep(0.5)
                        ctr = ctr + 1
    except KeyboardInterrupt:
        terminateThread = True