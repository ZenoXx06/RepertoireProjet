import time
import random
import json, os
from machine import Pin, I2C
from I2C_LCD import I2CLcd
ledVerte = Pin(18, Pin.OUT)
ledBleu = Pin(19, Pin.OUT)
ledRouge = Pin(20, Pin.OUT)
btnVert = Pin(4, Pin.IN, Pin.PULL_UP)
btnBleu = Pin(3, Pin.IN, Pin.PULL_UP)
btnRouge = Pin(2, Pin.IN, Pin.PULL_UP)
ledRouge.off()
ledBleu.off()
ledVerte.off()
btnVertprev=btnVert.value()
btnBleuprev=btnBleu.value()
btnRougeprev=btnRouge.value()
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
i2c_add = i2c.scan()[0]
lcd = I2CLcd(i2c, i2c_add, 2, 16) 

class Partie:
    'Classe pour lobjet partie'
    
    def __init__(self, premierJoueur, deuxiemeJoueur, nomJoueur1, nomJoueur2, nb_bonnesRepJ1, nb_bonnesRepJ2, pointageJ1, pointageJ2):
        self.premierJoueur = premierJoueur
        self.deuxiemeJoueur = deuxiemeJoueur
        self.nomJoueur1 = nomJoueur1
        self.nomJoueur2 = nomJoueur2
        self.nb_bonnesRepJ1 = nb_bonnesRepJ1
        self.nb_bonnesRepJ2 = nb_bonnesRepJ2
        self.pointageJ1 = pointageJ1
        self.pointageJ2 = pointageJ2
        
    def __repr__(self):
        return self.nomJoueur1 + self.nomJoueur2
    
    def afficherPartie(self):
        print("- Nom Joueur1: " + self.nomJoueur1 
              + "- Nom Joueur2: " + self.nomJoueur2
              + "- Nombre de bonne réponse du joueur1: " + self.nb_bonnesRepJ1
              + "- Nombre de bonne réponse du joueur2: " + self.nb_bonnesRepJ2
              + "- Pointage du joueur1: " + self.pointageJ1
              + "- Pointage du joueur2: " + self.pointageJ2)

# Présentation et prise de nom
def nom():
    print("-------------------------------------------------------")        
    print("  Travail Pratique 1 -- QUIZ 4B5 -- Guillaume Giguère")
    print("-------------------------------------------------------")
    print("    Choisissez les bonnes réponses avec les lettres")
    print("            Vous avez un droit de réplique!")
    print("-------------------------------------------------------")

    partie.nomJoueur1 = input("Entrez le nom du joueur1: ")
    while partie.nomJoueur1 == "" or len(partie.nomJoueur1) > 13:
        print("Ce n'est pas un nom valide (trop long)")
        time.sleep(1)
        partie.nomJoueur1 = input("Entrez le nom du joueur1: ")
    partie.nomJoueur2 = input("Entrez le nom du joueur2: ")
    while partie.nomJoueur2 == ""  or len(partie.nomJoueur2) > 13:
        print("Ce n'est pas un nom valide (trop long)")
        time.sleep(1)
        partie.nomJoueur2 = input("Entrez le nom du joueur2: ")
        
#Ordre de passage et affichage
def ordre():
    chiffre = random.randint(1, 2)
    if chiffre == 1:
        partie.premierJoueur = partie.nomJoueur1
        partie.deuxiemeJoueur = partie.nomJoueur2
    else:
        partie.premierJoueur = partie.nomJoueur2
        partie.deuxiemeJoueur = partie.nomJoueur1

    lcd.putstr("1: " + str(partie.premierJoueur))
    lcd.move_to(0,1)
    lcd.putstr("2: " + str(partie.deuxiemeJoueur))
    time.sleep(3)
    lcd.clear()

# Affichage des résultats
def resultat():
    lcd.putstr(partie.nomJoueur1)
    lcd.move_to(0,1)
    lcd.putstr(partie.nomJoueur2)
    time.sleep(1)
    lcd.move_to(13,0)
    lcd.putstr(".")
    lcd.move_to(13,1)
    lcd.putstr(".")
    time.sleep(1)
    lcd.move_to(14,0)
    lcd.putstr(".")
    lcd.move_to(14,1)
    lcd.putstr(".")
    time.sleep(1)
    lcd.move_to(15,0)
    lcd.putstr(".")
    lcd.move_to(15,1)
    lcd.putstr(".")
    time.sleep(1)
    lcd.clear()
    lcd.putstr(str(partie.pointageJ1))
    lcd.move_to(0,1)
    lcd.putstr(str(partie.pointageJ2))
    time.sleep(1)
    lcd.clear()
    lcd.putstr("Le gagnant est:")
    lcd.move_to(0,1)
    gagnant = ""
    if partie.pointageJ1 > partie.pointageJ2:
        lcd.putstr(partie.nomJoueur1)
    elif partie.pointageJ2 > partie.pointageJ1:
        lcd.putstr(partie.nomJoueur2)
    elif partie.pointageJ2 == partie.pointageJ1:
        lcd.putstr("Personne")

#Méthode qui gère le droit de réplique
def replique(rep, btnRougeprev, btnBleuprev, btnVertprev, nom):
    lcd.putstr("Replique:")
    lcd.move_to(0,1)
    lcd.putstr(nom)
    time.sleep(2)
    lcd.clear()
    lcd.putstr("Fait ton choix")
    lcd.move_to(0,1)
    lcd.putstr(nom)
    time.sleep(2)
    lcd.clear()
    press = False
    while press == False:
        if btnRouge.value() == 1 and btnRouge.value() != btnRougeprev:
                btnRougeprev = btnRouge.value()
                ledRouge.on()
                time.sleep(0.5)
                ledRouge.off()
                press = True
                lcd.putstr("La reponse <a> a ete choisi")
                time.sleep(2)
                lcd.clear()
                if rep == "a":
                    lcd.putstr("Bonne Reponse!")
                    time.sleep(2)
                    lcd.clear()
                    if nom != partie.nomJoueur1:
                        partie.nb_bonnesRepJ2 += 1
                        partie.pointageJ2 += val['pts']
                    else:
                        partie.nb_bonnesRepJ1 += 1
                        partie.pointageJ1 += val['pts']
                else:
                    lcd.putstr("Mauvaise Reponse")
                    time.sleep(2)
                    lcd.clear()
                    ctr = 0
                    if rep == "b":
                        while ctr < 5:
                            ledBleu.on()
                            time.sleep(0.2)
                            ledBleu.off()
                            time.sleep(0.2)
                            ctr += 1
                    elif rep == "c":
                        while ctr < 5:
                            ledVerte.on()
                            time.sleep(0.2)
                            ledVerte.off()
                            time.sleep(0.2)
                            ctr += 1
        elif btnBleu.value() == 1 and btnBleu.value() != btnBleuprev:
            btnBleuprev = btnBleu.value()
            ledBleu.on()
            time.sleep(0.5)
            ledBleu.off()
            press = True
            lcd.putstr("La reponse <b> a ete choisi")
            time.sleep(2)
            lcd.clear()
            if rep == "b":
                lcd.putstr("Bonne Reponse!")
                time.sleep(2)
                lcd.clear()
                if nom != partie.nomJoueur1:
                    partie.nb_bonnesRepJ2 += 1
                    partie.pointageJ2 += val['pts']
                else:
                    partie.nb_bonnesRepJ1 += 1
                    partie.pointageJ1 += val['pts']
            else:
                    lcd.putstr("Mauvaise Reponse")
                    time.sleep(2)
                    lcd.clear()
                    ctr = 0
                    if rep == "a":
                        while ctr < 5:
                            ledRouge.on()
                            time.sleep(0.2)
                            ledRouge.off()
                            time.sleep(0.2)
                            ctr += 1
                    elif rep == "c":
                        while ctr < 5:
                            ledVerte.on()
                            time.sleep(0.2)
                            ledVerte.off()
                            time.sleep(0.2)
                            ctr += 1
        elif btnVert.value() == 1 and btnVert.value() != btnVertprev:
            btnVertprev = btnVert.value()
            ledVerte.on()
            time.sleep(0.5)
            ledVerte.off()
            press = True
            lcd.putstr("La reponse <c> a ete choisi")
            time.sleep(2)
            lcd.clear()
            if rep == "c":
                lcd.putstr("Bonne Reponse!")
                time.sleep(2)
                lcd.clear()
                if nom != partie.nomJoueur1:
                    partie.nb_bonnesRepJ2 += 1
                    partie.pointageJ2 += val['pts']
                else:
                    partie.nb_bonnesRepJ1 += 1
                    partie.pointageJ1 += val['pts']
            else:
                    lcd.putstr("Mauvaise Reponse")
                    time.sleep(2)
                    lcd.clear()
                    ctr = 0
                    if rep == "a":
                        while ctr < 5:
                            ledRouge.on()
                            time.sleep(0.2)
                            ledRouge.off()
                            time.sleep(0.2)
                            ctr += 1
                    elif rep == "b":
                        while ctr < 5:
                            ledBleu.on()
                            time.sleep(0.2)
                            ledBleu.off()
                            time.sleep(0.2)
                            ctr += 1
        btnRougeprev = btnRouge.value()
        btnBleuprev = btnBleu.value()
        btnVertprev = btnVert.value()
        time.sleep(0.01)
    
#Méthode qui gère le choix de la réponse        
def reponse(rep, btnRougeprev, btnBleuprev, btnVertprev, nom):
    lcd.putstr("Fait ton choix")
    lcd.move_to(0,1)
    lcd.putstr(nom)
    time.sleep(2)
    lcd.clear()
    nom2 = partie.nomJoueur1
    if nom == partie.nomJoueur1:
        nom2 = partie.nomJoueur2
    press = False
    while press == False:
        if btnRouge.value() == 1 and btnRouge.value() != btnRougeprev:
            btnRougeprev = btnRouge.value()
            ledRouge.on()
            time.sleep(0.5)
            ledRouge.off()
            press = True
            lcd.putstr("La reponse <a> a ete choisi")
            time.sleep(2)
            lcd.clear()
            if rep == "a":
                lcd.putstr("Bonne Reponse!")
                time.sleep(2)
                lcd.clear()
                if nom == partie.nomJoueur1:
                    partie.nb_bonnesRepJ1 += 1
                    partie.pointageJ1 += val['pts']
                else:
                    partie.nb_bonnesRepJ2 += 1
                    partie.pointageJ2 += val['pts']
            else:
                lcd.putstr("Mauvaise Reponse")
                time.sleep(2)
                lcd.clear()
                replique(rep, btnRougeprev, btnBleuprev, btnVertprev, nom2)
        elif btnBleu.value() == 1 and btnBleu.value() != btnBleuprev:
            btnBleuprev = btnBleu.value()
            ledBleu.on()
            time.sleep(0.5)
            ledBleu.off()
            press = True
            lcd.putstr("La reponse <b> a ete choisi")
            time.sleep(2)
            lcd.clear()
            if rep == "b":
                lcd.putstr("Bonne Reponse!")
                time.sleep(2)
                lcd.clear()
                if nom == partie.nomJoueur1:
                    partie.nb_bonnesRepJ1 += 1
                    partie.pointageJ1 += val['pts']
                else:
                    partie.nb_bonnesRepJ2 += 1
                    partie.pointageJ2 += val['pts']
            else:
                lcd.putstr("Mauvaise Reponse")
                time.sleep(2)
                lcd.clear()
                replique(rep, btnRougeprev, btnBleuprev, btnVertprev, nom2)
        elif btnVert.value() == 1 and btnVert.value() != btnVertprev:
            btnVertprev = btnVert.value()
            ledVerte.on()
            time.sleep(0.5)
            ledVerte.off()
            press = True
            lcd.putstr("La reponse <c> a ete choisi")
            time.sleep(2)
            lcd.clear()
            if rep == "c":
                lcd.putstr("Bonne Reponse!")
                time.sleep(2)
                lcd.clear()
                if nom == partie.nomJoueur1:
                    partie.nb_bonnesRepJ1 += 1
                    partie.pointageJ1 += val['pts']
                else:
                    partie.nb_bonnesRepJ2 += 1
                    partie.pointageJ2 += val['pts']
            else:
                lcd.putstr("Mauvaise Reponse")
                time.sleep(2)
                lcd.clear()
                replique(rep, btnRougeprev, btnBleuprev, btnVertprev, nom2)
        btnRougeprev = btnRouge.value()
        btnBleuprev = btnBleu.value()
        btnVertprev = btnVert.value()
        time.sleep(0.01)

def fichierExiste():
    try:
        os.stat("./questions.json")
        return True
    except OSError:
        return False

partie = Partie("", "" ,"" ,"" ,0 ,0 ,0 ,0)
nom()
ordre()

# Ouverture du Json
if fichierExiste():
    with open("questions.json", encoding='utf-8') as fichier:
        data = json.load(fichier)
        
    i = 0
    for val in data['liste de question']:
    # Affichage de la question
        i += 1
        print(str(i) + ") " + str(val['q']))
        print("<1> " + str(val['a']))
        print("<2> " + str(val['b']))
        print("<3> " + str(val['c']))
    
    # Si c'est une question pour le premier joueur
        if i % 2 != 0:
            lcd.putstr(partie.premierJoueur)
            lcd.move_to(0,1)
            lcd.putstr("C'est ton tour!")
            time.sleep(2)
            lcd.clear()
            reponse(str(val['rep']), btnRougeprev, btnBleuprev, btnVertprev, partie.premierJoueur)
            
    # Si c'est une question pour le deuxième joueur
        else:
            lcd.putstr(partie.deuxiemeJoueur)
            lcd.move_to(0,1)
            lcd.putstr("C'est ton tour!")
            time.sleep(2)
            lcd.clear()
            reponse(str(val['rep']), btnRougeprev, btnBleuprev, btnVertprev, partie.deuxiemeJoueur)
            
        lcd.putstr("Pointage J1: " + str(partie.pointageJ1))
        lcd.move_to(0,1)
        lcd.putstr("Pointage J2: " + str(partie.pointageJ2))
        time.sleep(2)
        lcd.clear()
    resultat()
else:
    print("Le fichier n'existe pas")
    