from machine import Pin
import time
import random

ledVerte = Pin(18, Pin.OUT)
ledBleu = Pin(19, Pin.OUT)
ledRouge = Pin(20, Pin.OUT)
btnVert = Pin(4, Pin.IN, Pin.PULL_UP)
btnBleu = Pin(3, Pin.IN, Pin.PULL_UP)
btnRouge = Pin(2, Pin.IN, Pin.PULL_UP)
ledRouge.off()
ledBleu.off()
ledVerte.off()
btnVertprev=btnVert.value()
btnBleuprev=btnBleu.value()
btnRougeprev=btnRouge.value()
tabSuite = []
ctrNiveau = 0

#Classe partie
class Partie:
    def init(self, date, nomJoueur, niveau, sequance, points):
        self.date = date
        self.nomJoueur = nomJoueur
        self.niveau = niveau
        self.sequance = sequance
        self.points = points

    def repr(self):
        return self.nomJoueur + self.points

    def afficheResultats(self):
        print("---------------------")
        print(self.nomJoueur)
        print("Points: " + str(self.points))
        print("Niveau complété: " + str(self.niveau))
        print("---------------------")
        
#Méthode qui gère la difficulté facile 
def facile(ctr):
    if tabSuite[ctr] == 1:
        ledRouge.on()
        time.sleep(0.9)
        ledRouge.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.9)
    elif tabSuite[ctr] == 2:
        ledBleu.on()
        time.sleep(0.9)
        ledBleu.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.9)
    else:
        ledVerte.on()
        time.sleep(0.9)
        ledVerte.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.9)

#Méthode qui gère la difficulté moyenne         
def moyen(ctr):
    if tabSuite[ctr] == 1:
        ledRouge.on()
        time.sleep(0.5)
        ledRouge.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.5)
    elif tabSuite[ctr] == 2:
        ledBleu.on()
        time.sleep(0.5)
        ledBleu.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.5)
    else:
        ledVerte.on()
        time.sleep(0.5)
        ledVerte.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.5)

#Méthode qui gère la difficulté difficile          
def difficile(ctr):
    if tabSuite[ctr] == 1:
        ledRouge.on()
        time.sleep(0.2)
        ledRouge.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.2)
    elif tabSuite[ctr] == 2:
        ledBleu.on()
        time.sleep(0.2)
        ledBleu.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.2)
    else:
        ledVerte.on()
        time.sleep(0.2)
        ledVerte.off()
        if len(tabSuite) != ctr + 1:
            time.sleep(0.2)
            
#Méthode qui écrit la description
def description():
    print("-------------------------------------------------------------------")
    print("--- Le Jeux de SIMON -- Guillaume Giguère TP 2 d'objet connecté ---")
    print("-------------------------------------------------------------------")
    print("Le jeux consiste à redonner la suite de couleurs donnée au paravant")
    print("          Vous avez le choix de 3 difficultés pour le jeu")
    print("      La difficulté change le temps d'apparition des couleurs")
    print("                Rouge = 1 --- Bleu = 2 --- Vert = 3")
    print("-------------------------------------------------------------------")
    time.sleep(1)
    
#Méthode qui gère le choix de la difficulté
def choixDifficulte(difficulte, btnRougeprev, btnBleuprev, btnVertprev):
    rep = ""
    while rep != "o":
        print("Choisissez une difficulté avec les boutons (1/2/3)")
        difficulte = 0
        while difficulte == 0:
            if btnRouge.value() == 1 and btnRouge.value() != btnRougeprev:
                btnRougeprev = btnRouge.value()
                ledRouge.on()
                difficulte = 1
                time.sleep(0.4)
                ledRouge.off()
            elif btnBleu.value() == 1 and btnBleu.value() != btnBleuprev:
                btnBleuprev = btnBleu.value()
                ledBleu.on()
                difficulte = 2
                time.sleep(0.4)
                ledBleu.off()
            elif btnVert.value() == 1 and btnVert.value() != btnVertprev:
                btnVertprev = btnVert.value()
                ledVerte.on()
                difficulte = 3
                time.sleep(0.4)
                ledVerte.off()
            btnRougeprev = btnRouge.value()
            btnBleuprev = btnBleu.value()
            btnVertprev = btnVert.value()
            time.sleep(0.01)
        if difficulte != 0:
            strDifficulte = ""
            if difficulte == 1:
                strDifficulte = "Facile"
            elif difficulte == 2:
                strDifficulte = "Moyen"
            else:
                strDifficulte = "Difficile"
            rep = input("Êtes vous sur d'avoir choisi la difficulté: " + strDifficulte + " \no/n: ")
            while rep != 'o' and rep != 'n':
                print("Ce n'est pas une réponse valide")
                rep = input("Êtes vous sur d'avoir choisi la difficulté: " + strDifficulte + " \no/n: ")
    time.sleep(0.5)
    print("La partie va commencer, Soyez prêt \n")
    time.sleep(1.5)
    return difficulte

#Méthode qui gère une erreur
def erreur():
    tempI = 0
    while tempI <= 5:
        ledVerte.on()
        ledBleu.on()
        ledRouge.on()
        time.sleep(0.1)
        ledVerte.off()
        ledBleu.off()
        ledRouge.off()
        time.sleep(0.1)
        tempI += 1
        
#Méthode qui gère le choix de la réponse        
def reponse(tabSuite, btnRougeprev, btnBleuprev, btnVertprev):
    ctr = 0
    echec = False
    while len(tabSuite) > ctr and echec == False:
        press = False
        while press == False:
            if btnRouge.value() == 1 and btnRouge.value() != btnRougeprev and tabSuite[ctr] == 1:
                btnRougeprev = btnRouge.value()
                ledRouge.on()
                time.sleep(0.2)
                ledRouge.off()
                press = True
            elif btnBleu.value() == 1 and btnBleu.value() != btnBleuprev and tabSuite[ctr] == 2:
                btnBleuprev = btnBleu.value()
                ledBleu.on()
                time.sleep(0.2)
                ledBleu.off()
                press = True
            elif btnVert.value() == 1 and btnVert.value() != btnVertprev and tabSuite[ctr] == 3:
                btnVertprev = btnVert.value()
                ledVerte.on()
                time.sleep(0.2)
                ledVerte.off()
                press = True
            if btnRouge.value() == 1 and btnRouge.value() != btnRougeprev and tabSuite[ctr] != 1:
                erreur()
                btnRougeprev = btnRouge.value()
                press = True
                echec = True
            if btnBleu.value() == 1 and btnBleu.value() != btnBleuprev and tabSuite[ctr] != 2:
                erreur()
                btnBleuprev = btnBleu.value()
                press = True
                echec = True
            if btnVert.value() == 1 and btnVert.value() != btnVertprev and tabSuite[ctr] != 3:
                erreur()
                btnVertprev = btnVert.value()
                press = True
                echec = True
            btnRougeprev = btnRouge.value()
            btnBleuprev = btnBleu.value()
            btnVertprev = btnVert.value()
            time.sleep(0.01)
        ctr += 1
    return echec

#Méthode qui gère une partie gagante
def gagne():
    tempI = 0
    while tempI <= 5:
        ledRouge.on()
        time.sleep(0.05)
        ledRouge.off()
        time.sleep(0.05)
        ledBleu.on()
        time.sleep(0.05)
        ledBleu.off()
        time.sleep(0.05)
        ledVerte.on()
        time.sleep(0.05)
        ledVerte.off()
        time.sleep(0.05)
        tempI += 1

#Méthode qui affiche la description
description()
nom = input("Entrez votre nom: ")
while nom == "":
    print("Ce n'est pas un nom valide")
    nom = input("Entrez votre nom: ")
#Boucle principal du jeu
recommencer = ""
while recommencer != "n":
    ctrNiveau = 0
    tabSuite = []
    difficulte = 0
    rate = False
    points = 0
    partie = Partie()
    partie.nomJoueur = nom
    #Méthode qui fait la selection de la difficulté
    difficulte = choixDifficulte(difficulte, btnRougeprev, btnBleuprev, btnVertprev)
    #Boucle pour la séquance actuelle
    while ctrNiveau < 20 and rate == False:
        chiffre = random.randint(1, 3)
        tabSuite.append(chiffre)
        ctr = 0
        #Renvoit à la méthode de la difficulté choisi (le temps d'intervalle)
        while len(tabSuite) > ctr:
            if difficulte == 1:
                facile(ctr)
            elif difficulte == 2:
                moyen(ctr)
            elif difficulte == 3:
                difficile(ctr)
            ctr += 1
        #Méthode qui regarde si la réponse est bonne ou non
        echec = reponse(tabSuite, btnRougeprev, btnBleuprev, btnVertprev)
        if echec:
            rate = True
            time.sleep(2)
        else:
            ctrNiveau += 1
            points += 1
            if ctrNiveau >= 10:
                points += 1
            print("Bravo, vous avez fini le niveau " + str(ctrNiveau) + "\n")
            time.sleep(2)
    #On regarde si le jeu est gagné ou perdu
    if ctrNiveau >= 20:
        gagne()
        print("Bravo vous avez fini tout les niveaux")
        max = " (max)"
        time.sleep(0.5)
    else:
        print("Vous avez perdu au niveau: " + str(ctrNiveau + 1))
        max = ""
        time.sleep(0.5)
    #On met les données restante dans l'objet
    partie.date = str(time.localtime()) #La date d'aujourd'hui ne peut pas être prise
    partie.sequance = tabSuite
    partie.points = points
    partie.niveau = ctrNiveau
    #Méthode qui affiche les résultats de partie
    partie.afficheResultats()
    #On demende si on recommence une partie
    time.sleep(2)
    recommencer = input("Voulez vous rejouez (o/n): ")
    while recommencer != 'o' and recommencer != 'n':
        print("Ce n'est pas une réponse valide")
        recommencer = input("Voulez vous rejouez (o/n): ")
        