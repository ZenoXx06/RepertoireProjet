<?php
require 'Controleur/Controleur.php';
try {
    if (isset($_GET["action"])){
        //Ancien commande.php, affiche les commandes
        if ($_GET["action"] == "commande") {
            if (isset($_GET["id"])){
                $id = intval($_GET['id']);
                if ($id != 0) {
                    $erreur = isset($_GET['erreur']) ? $_GET['erreur'] : '';
                    commande($id, $erreur);
                } else 
                    throw new Exception("Identifiant de commande incorrect");
            } else
                throw new Exception("Aucun identifiant de commande");
        //Ancien article.php, ajoute un article
        } else if ($_GET["action"] == "article") {
            if (isset($_POST['commande_id'])) {
                $id = intval($_POST['commande_id']);
                if ($id != 0) {
                    $commande = getCommande($id);
                    $article = $_POST;
                    article($article);
                } else
                    throw new Exception("Identifiant de commande incorrect");
            } else
                throw new Exception("Aucun identifiant de commande");
        //Confirme la suppression
        } else if ($_GET['action'] == 'confirmer') {
            if (isset($_GET['id'])) {
                $id = intval($_GET['id']);
                if ($id != 0) {
                    confirmer($id);
                } else
                    throw new Exception("Identifiant de l'article incorrect");
            } else
                throw new Exception("Aucun identifiant d'article");
        // Supprimer un commentaire
        } else if ($_GET['action'] == 'supprimer') {
            if (isset($_POST['id'])) {
                $id = intval($_POST['id']);
                if ($id != 0) {
                    supprimer($id);
                } else
                    throw new Exception("Identifiant de l'article incorrect");
            } else
                throw new Exception("Aucun identifiant de l'article");
        } else if ($_GET['action'] == "nouvelleCommande") {
            nouvelleCommande();
        } else if ($_GET['action'] == "ajouter"){
            $commande = $_POST;
            ajouter($commande);
        } else {
            // Action mal définie
            throw new Exception("Action non valide");
        }
    } else {
        accueil();
    }
} catch (Exception $e) {
    erreur($e->getMessage());
}