<?php $titre = "Nike - " . $commande['detail']; ?>

<?php ob_start(); ?>
<header>
    <h1 id="titreCommande">Ajouter une commande de l'utilisateur 1 :</h1>
</header>
<form action="index.php?action=ajouter" method="post">
    <h2>Ajouter une commande</h2>
    <p>
        <label for="detail">Detail</label> : <input type="text" name="detail" id="detail" /> <br />
        <label for="prix">Prix</label> :  <input type="number" name="prix" id="prix" /><br />
        <input type="hidden" name="utilisateur_id" value="1" /><br />
        <input type="submit" value="Envoyer" />
    </p>
</form>

<?php $contenu = ob_get_clean(); ?>

<?php require 'Vue/gabarit.php'; ?>
