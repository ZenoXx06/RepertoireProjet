<?php $titre = "Nike " . $commande['detail']; ?>

<?php ob_start(); ?>
<article>
    <header>
        <h1 class="titreCommande"><?= $commande['detail'] ?></h1>
        Commande de l'utilisateur #<?= $commande['utilisateur_id'] ?>
    </header>
    <p><?= $commande['prix'] ?> $</p>
</article>
<hr />
<header>
    <h1 id="titreCommande"><?= $commande['detail'] ?> :</h1>
</header>
<?php foreach ($articles as $article): ?>
    <a href="index.php?action=confirmer&id=<?= $article['id'] ?>" >
            [Supprimer]
    </a>
    <p><?= $article['nom'] ?>: <?= $article['prix'] ?> $</p>
<?php endforeach; ?>

<form action="index.php?action=article" method="post">
    <h2>Ajouter un article</h2>
    <p>
        <label for="nom">Nom de l'article</label> : <input type="text" name="nom" id="nom" /><br />
        <label for="prix">Prix de l'article</label> :  <input type="number" name="prix" id="prix" /><br />
        <input type="hidden" name="commande_id" value="<?= $commande['id'] ?>" /><br />
        <input type="submit" value="Envoyer" />
    </p>
</form>

<?php $contenu = ob_get_clean(); ?>

<?php require 'gabarit.php'; ?>

