<?php $titre = "Supprimer - " . $article['nom']; ?>
<?php ob_start(); ?>
<article>
    <header>
        <p><h1>
            Supprimer?
        </h1>
        <strong><?= $article['nom'] ?></strong><br/>
        <?= $article['prix'] . "$" ?>
        </p>
    </header>
</article>

<form action="index.php?action=supprimer" method="post">
    <input type="hidden" name="id" value="<?= $article['id'] ?>" /><br />
    <input type="submit" value="Oui" />
</form>
<form action="index.php" method="get" >
    <input type="hidden" name="action" value="commande" />
    <input type="hidden" name="id" value="<?= $article['commande_id'] ?>" />
    <input type="submit" value="Annuler" />
</form>
<?php $contenu = ob_get_clean(); ?>

<?php require 'gabarit.php'; ?>

