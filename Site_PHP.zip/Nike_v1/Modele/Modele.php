<?php

// Effectue la connexion à la BDD
function getBdd() {
    $bdd = new PDO('mysql:host=localhost;dbname=nike_v1;charset=utf8', 'root', 'mysql', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    return $bdd;
}

// Renvoie la liste de tous les articles, triés par identifiant décroissant
function getCommandes() {
    $bdd = getBdd();
    $commandes = $bdd->query('select * from commande'
            . ' order by ID desc');
    return $commandes;
}

// Renvoie les infos d'une commande
function getCommande($idCommande) {
    $bdd = getBdd();
    $commande = $bdd->prepare('select * from commande'
            . ' where ID=?');
    $commande->execute(array($idCommande));
    if ($commande->rowCount() == 1)
        return $commande->fetch();
    else
        throw new Exception("Aucune commande ne correspond à l'identifiant '$idCommande'");
}

// Enregistre une nouvelle commande
function setCommande($commande) {
    $bdd = getBdd();
    $result = $bdd->prepare('INSERT INTO commande (detail, prix, utilisateur_id) VALUES(?, ?, ?)');
    $result->execute(array($commande['detail'], $commande['prix'], $commande['utilisateur_id']));
    return $result;
}

//Renvoit la liste des articles
function getArticles($idCommande) {
    $bdd = getBdd();
    $articles = $bdd->prepare('select * from article'
            . ' where commande_id = ?');
    $articles->execute(array($idCommande));
    return $articles;
} 

//Renvoit un article spécifique
function getArticle($id) {
    $bdd = getBdd();
    $article = $bdd->prepare('select * from article'
            . ' where id = ?');
    $article->execute(array($id));
    if ($article->rowCount() == 1)
        return $article->fetch();
    else
        throw new Exception("Aucun article ne correspond à l'identifiant '$id'");
    return $article;
}

//Ajoute un article
function setArticle($article) {
    $bdd = getBdd();
    $articles = $bdd->prepare('INSERT INTO article (commande_id, nom, prix) VALUES(?, ?, ?)');
    $articles->execute(array($article['commande_id'], $article['nom'], $article['prix']));
    return $articles;
}

// Supprime un article
function deleteArticle($id) {
    $bdd = getBdd();
    $result = $bdd->prepare('DELETE FROM article'
            . ' WHERE id = ?');
    $result->execute(array($id));
    return $result;
}