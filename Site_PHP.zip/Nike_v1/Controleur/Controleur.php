<?php

require "Modele/Modele.php";

//Affiche la liste des commandes
function accueil(){
    $commandes = getCommandes();
    require "Vue/vueCommande.php";
}

//Affiche les articles d'une commande
function commande($id, $erreur) {
    $commande = getCommande($id);
    $articles = getArticles($id);
    require "Vue/vueArticle.php";
}

//Affiche le form pour ajouter une commande
function nouvelleCommande() {
    require "Vue/vueAjouter.php";
}

//Enregistre la nouvelle commande et retourne a l'acceuil
function ajouter($commande) {
    setCommande($commande);
    header("Location: index.php");
}
//Ajoute un article à une commande
function article($article) {
    setArticle($article);
    header('Location: index.php?action=commande&id=' . $article['commande_id']);
}

// Confirmer la suppression d'un article
function confirmer($id) {
    $article = getArticle($id);
    require 'Vue/vueConfirmer.php';
}

// Supprimer un article
function supprimer($id) {
    $article = getArticle($id);
    deleteArticle($id);
    header('Location: index.php?action=commande&id=' . $article['commande_id']);
}

//Affiche l'erreur
function erreur($msgErreur) {
    require "Vue/vueErreur.php";
}