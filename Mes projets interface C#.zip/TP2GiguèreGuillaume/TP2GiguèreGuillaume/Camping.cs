﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2GiguèreGuillaume
{
    internal class Camping
    {
        private int _numeroCamping;
        public int numeroCamping { get { return _numeroCamping; } set { _numeroCamping = value; } }

        private string _nomCamping;
        public string nomCamping { get { return _nomCamping; } set { _nomCamping = value; } }

        private int _nbTerrain;
        public int nbTerrain { get { return _nbTerrain; } set { _nbTerrain = value; } }

        public string _cheminImage;
        public string cheminImage { get { return _cheminImage; } set { _cheminImage = value; } }

        public string _nomFichier;
        public string nomFichier { get { return _nomFichier; } set { _nomFichier = value; } }


        public Camping()
        {
            _numeroCamping = 0;
            _nomCamping = null;
            _nbTerrain = 0;
            _cheminImage = null;
            _nomFichier = null;
        }

        public Camping(int pNumeroCamping, string pNomCamping, int pNbTerrain, string pCheminImage, string pNomFichier)
        {
            _numeroCamping = pNumeroCamping;
            _nomCamping = pNomCamping;
            _nbTerrain = pNbTerrain;
            _cheminImage = pCheminImage;
            _nomFichier = pNomFichier;
        }

        public override string ToString()
        {
            return _nomCamping;
        }
    }
}
