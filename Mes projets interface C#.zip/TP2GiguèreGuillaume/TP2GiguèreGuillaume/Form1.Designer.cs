﻿namespace TP2GiguèreGuillaume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBoxCampingAcceuil = new System.Windows.Forms.PictureBox();
            this.pictureBoxVilleAcceuil = new System.Windows.Forms.PictureBox();
            this.labelQC = new System.Windows.Forms.Label();
            this.labelDescription = new System.Windows.Forms.Label();
            this.comboBoxChoixCamping = new System.Windows.Forms.ComboBox();
            this.labelArrivee = new System.Windows.Forms.Label();
            this.labelDepart = new System.Windows.Forms.Label();
            this.dateTimePickerArrivee = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerDepart = new System.Windows.Forms.DateTimePicker();
            this.buttonReservation = new System.Windows.Forms.Button();
            this.buttonQuitter = new System.Windows.Forms.Button();
            this.errorProviderDateArrivee = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderDateDepart = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCampingAcceuil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVilleAcceuil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDateArrivee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDateDepart)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxCampingAcceuil
            // 
            this.pictureBoxCampingAcceuil.Image = global::TP2GiguèreGuillaume.Properties.Resources.camping_icon;
            this.pictureBoxCampingAcceuil.Location = new System.Drawing.Point(12, 25);
            this.pictureBoxCampingAcceuil.Name = "pictureBoxCampingAcceuil";
            this.pictureBoxCampingAcceuil.Size = new System.Drawing.Size(91, 88);
            this.pictureBoxCampingAcceuil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCampingAcceuil.TabIndex = 0;
            this.pictureBoxCampingAcceuil.TabStop = false;
            // 
            // pictureBoxVilleAcceuil
            // 
            this.pictureBoxVilleAcceuil.Location = new System.Drawing.Point(54, 119);
            this.pictureBoxVilleAcceuil.Name = "pictureBoxVilleAcceuil";
            this.pictureBoxVilleAcceuil.Size = new System.Drawing.Size(337, 211);
            this.pictureBoxVilleAcceuil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxVilleAcceuil.TabIndex = 1;
            this.pictureBoxVilleAcceuil.TabStop = false;
            // 
            // labelQC
            // 
            this.labelQC.AutoSize = true;
            this.labelQC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelQC.Location = new System.Drawing.Point(109, 25);
            this.labelQC.Name = "labelQC";
            this.labelQC.Size = new System.Drawing.Size(150, 32);
            this.labelQC.TabIndex = 2;
            this.labelQC.Text = "Camping QC";
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.Location = new System.Drawing.Point(109, 74);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(321, 25);
            this.labelDescription.TabIndex = 3;
            this.labelDescription.Text = "Système de réservation - Hébergement";
            // 
            // comboBoxChoixCamping
            // 
            this.comboBoxChoixCamping.FormattingEnabled = true;
            this.comboBoxChoixCamping.Location = new System.Drawing.Point(33, 336);
            this.comboBoxChoixCamping.Name = "comboBoxChoixCamping";
            this.comboBoxChoixCamping.Size = new System.Drawing.Size(377, 33);
            this.comboBoxChoixCamping.TabIndex = 4;
            this.comboBoxChoixCamping.SelectedIndexChanged += new System.EventHandler(this.comboBoxChoixCamping_SelectedIndexChanged);
            // 
            // labelArrivee
            // 
            this.labelArrivee.AutoSize = true;
            this.labelArrivee.Location = new System.Drawing.Point(33, 383);
            this.labelArrivee.Name = "labelArrivee";
            this.labelArrivee.Size = new System.Drawing.Size(121, 25);
            this.labelArrivee.TabIndex = 5;
            this.labelArrivee.Text = "Date d\'arrivée";
            // 
            // labelDepart
            // 
            this.labelDepart.AutoSize = true;
            this.labelDepart.Location = new System.Drawing.Point(289, 383);
            this.labelDepart.Name = "labelDepart";
            this.labelDepart.Size = new System.Drawing.Size(131, 25);
            this.labelDepart.TabIndex = 6;
            this.labelDepart.Text = "Date de départ";
            // 
            // dateTimePickerArrivee
            // 
            this.dateTimePickerArrivee.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerArrivee.Location = new System.Drawing.Point(33, 420);
            this.dateTimePickerArrivee.Name = "dateTimePickerArrivee";
            this.dateTimePickerArrivee.Size = new System.Drawing.Size(158, 31);
            this.dateTimePickerArrivee.TabIndex = 7;
            this.dateTimePickerArrivee.ValueChanged += new System.EventHandler(this.dateTimePickerArrivee_ValueChanged);
            // 
            // dateTimePickerDepart
            // 
            this.dateTimePickerDepart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerDepart.Location = new System.Drawing.Point(255, 420);
            this.dateTimePickerDepart.Name = "dateTimePickerDepart";
            this.dateTimePickerDepart.Size = new System.Drawing.Size(155, 31);
            this.dateTimePickerDepart.TabIndex = 8;
            this.dateTimePickerDepart.ValueChanged += new System.EventHandler(this.dateTimePickerDepart_ValueChanged);
            // 
            // buttonReservation
            // 
            this.buttonReservation.Location = new System.Drawing.Point(33, 470);
            this.buttonReservation.Name = "buttonReservation";
            this.buttonReservation.Size = new System.Drawing.Size(158, 40);
            this.buttonReservation.TabIndex = 9;
            this.buttonReservation.Text = "Réservation";
            this.buttonReservation.UseVisualStyleBackColor = true;
            this.buttonReservation.Click += new System.EventHandler(this.buttonReservation_Click);
            // 
            // buttonQuitter
            // 
            this.buttonQuitter.Location = new System.Drawing.Point(255, 470);
            this.buttonQuitter.Name = "buttonQuitter";
            this.buttonQuitter.Size = new System.Drawing.Size(155, 40);
            this.buttonQuitter.TabIndex = 10;
            this.buttonQuitter.Text = "Quitter";
            this.buttonQuitter.UseVisualStyleBackColor = true;
            this.buttonQuitter.Click += new System.EventHandler(this.buttonQuitter_Click);
            // 
            // errorProviderDateArrivee
            // 
            this.errorProviderDateArrivee.ContainerControl = this;
            // 
            // errorProviderDateDepart
            // 
            this.errorProviderDateDepart.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 522);
            this.Controls.Add(this.buttonQuitter);
            this.Controls.Add(this.buttonReservation);
            this.Controls.Add(this.dateTimePickerDepart);
            this.Controls.Add(this.dateTimePickerArrivee);
            this.Controls.Add(this.labelDepart);
            this.Controls.Add(this.labelArrivee);
            this.Controls.Add(this.comboBoxChoixCamping);
            this.Controls.Add(this.labelDescription);
            this.Controls.Add(this.labelQC);
            this.Controls.Add(this.pictureBoxVilleAcceuil);
            this.Controls.Add(this.pictureBoxCampingAcceuil);
            this.Name = "Form1";
            this.Text = "TP2 - Guillaume Giguère";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCampingAcceuil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVilleAcceuil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDateArrivee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDateDepart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBoxCampingAcceuil;
        private PictureBox pictureBoxVilleAcceuil;
        private Label labelQC;
        private Label labelDescription;
        private ComboBox comboBoxChoixCamping;
        private Label labelArrivee;
        private Label labelDepart;
        private DateTimePicker dateTimePickerArrivee;
        private DateTimePicker dateTimePickerDepart;
        private Button buttonReservation;
        private Button buttonQuitter;
        private ErrorProvider errorProviderDateArrivee;
        private ErrorProvider errorProviderDateDepart;
    }
}