﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2GiguèreGuillaume
{
    public partial class FormAffichageReservation : Form
    {
        private String nomCamping;
        private String cheminImage;
        private Reservation[] tabReservation = new Reservation[10000];
        private int nbReservation;

        public FormAffichageReservation(string pNomCamping, string pCheminImage, Reservation[] pTabReservation, int pNbReservation)
        {
            InitializeComponent();
            nomCamping = pNomCamping;
            cheminImage = pCheminImage;
            tabReservation = pTabReservation;
            nbReservation = pNbReservation;
        }

        private void FormAffichageReservation_Load(object sender, EventArgs e)
        {
            textBoxAffichageCamping.Text = nomCamping;
            pictureBoxAffichageReservation.ImageLocation = cheminImage;
            for (int i = 0; i < nbReservation; i++)
            {
                comboBoxReservation.Items.Add(tabReservation[i]);
            }
        }

        private void comboBoxReservation_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxInformation.Text = "Terrain: " + tabReservation[comboBoxReservation.SelectedIndex].terrain.Substring(tabReservation[comboBoxReservation.SelectedIndex].terrain.Length - 1) + "\r\n" +
                "Adultes: " + tabReservation[comboBoxReservation.SelectedIndex].nbAdulte + " & Enfants: " + tabReservation[comboBoxReservation.SelectedIndex].nbEnfant + "\r\n" +
                "Nombre de nuit: " + (tabReservation[comboBoxReservation.SelectedIndex].dateFin - tabReservation[comboBoxReservation.SelectedIndex].dateDebut) + "\r\n" +
                "Méthode de paiement: " + tabReservation[comboBoxReservation.SelectedIndex].paiement + "\r\n" +
                "Coût total: " + tabReservation[comboBoxReservation.SelectedIndex].coutTotal + "$";
        }
    }
}