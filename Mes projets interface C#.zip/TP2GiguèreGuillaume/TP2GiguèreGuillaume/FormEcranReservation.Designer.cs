﻿namespace TP2GiguèreGuillaume
{
    partial class FormEcranReservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxNomCamping = new System.Windows.Forms.TextBox();
            this.pictureBoxCampingChoisi = new System.Windows.Forms.PictureBox();
            this.textBoxTerrain1 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain10 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain9 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain8 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain7 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain6 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain5 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain4 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain3 = new System.Windows.Forms.TextBox();
            this.textBoxTerrain2 = new System.Windows.Forms.TextBox();
            this.labelDisponibilitéCamping = new System.Windows.Forms.Label();
            this.comboBoxSelectionTerrain = new System.Windows.Forms.ComboBox();
            this.labelChoixTerrain = new System.Windows.Forms.Label();
            this.numericUpDownNombreAdulte = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNombreEnfant = new System.Windows.Forms.NumericUpDown();
            this.labelNombrePersonne = new System.Windows.Forms.Label();
            this.labelNombreAdulte = new System.Windows.Forms.Label();
            this.labelNombreEnfant = new System.Windows.Forms.Label();
            this.labelInformation = new System.Windows.Forms.Label();
            this.labelNom = new System.Windows.Forms.Label();
            this.labelPaiement = new System.Windows.Forms.Label();
            this.labelCourriel = new System.Windows.Forms.Label();
            this.comboBoxPaiement = new System.Windows.Forms.ComboBox();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxCourriel = new System.Windows.Forms.TextBox();
            this.buttonFaireReservation = new System.Windows.Forms.Button();
            this.menuStripReservation = new System.Windows.Forms.MenuStrip();
            this.réservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nouvelleRéservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faireLaRéservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.afficherUneRéservationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.retourAuMenuPrincipalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelFacture = new System.Windows.Forms.Label();
            this.labelFactureAdulte = new System.Windows.Forms.Label();
            this.labelFactureEnfants = new System.Windows.Forms.Label();
            this.labelFacturePersonne = new System.Windows.Forms.Label();
            this.labelFactureNuit = new System.Windows.Forms.Label();
            this.labelFactureCout = new System.Windows.Forms.Label();
            this.textBoxFactureAdultes = new System.Windows.Forms.TextBox();
            this.textBoxFactureEnfants = new System.Windows.Forms.TextBox();
            this.textBoxFacturePersonnes = new System.Windows.Forms.TextBox();
            this.textBoxFactureNuits = new System.Windows.Forms.TextBox();
            this.textBoxFactureCout = new System.Windows.Forms.TextBox();
            this.statusStripSauvegarde = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelSauvegarde = new System.Windows.Forms.ToolStripStatusLabel();
            this.pictureBoxCamping = new System.Windows.Forms.PictureBox();
            this.errorProviderNom = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderTotalPersonne = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderCourriel = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderTerrain = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderPaiement = new System.Windows.Forms.ErrorProvider(this.components);
            this.saveFileDialogReserver = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialogReservation = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCampingChoisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNombreAdulte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNombreEnfant)).BeginInit();
            this.menuStripReservation.SuspendLayout();
            this.statusStripSauvegarde.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCamping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderNom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTotalPersonne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCourriel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTerrain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderPaiement)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxNomCamping
            // 
            this.textBoxNomCamping.Enabled = false;
            this.textBoxNomCamping.Location = new System.Drawing.Point(292, 36);
            this.textBoxNomCamping.Name = "textBoxNomCamping";
            this.textBoxNomCamping.Size = new System.Drawing.Size(305, 31);
            this.textBoxNomCamping.TabIndex = 0;
            // 
            // pictureBoxCampingChoisi
            // 
            this.pictureBoxCampingChoisi.Location = new System.Drawing.Point(512, 71);
            this.pictureBoxCampingChoisi.Name = "pictureBoxCampingChoisi";
            this.pictureBoxCampingChoisi.Size = new System.Drawing.Size(315, 191);
            this.pictureBoxCampingChoisi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCampingChoisi.TabIndex = 2;
            this.pictureBoxCampingChoisi.TabStop = false;
            // 
            // textBoxTerrain1
            // 
            this.textBoxTerrain1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain1.Enabled = false;
            this.textBoxTerrain1.Location = new System.Drawing.Point(19, 75);
            this.textBoxTerrain1.Name = "textBoxTerrain1";
            this.textBoxTerrain1.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain1.TabIndex = 3;
            this.textBoxTerrain1.Text = "1";
            this.textBoxTerrain1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTerrain10
            // 
            this.textBoxTerrain10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain10.Enabled = false;
            this.textBoxTerrain10.Location = new System.Drawing.Point(343, 75);
            this.textBoxTerrain10.Name = "textBoxTerrain10";
            this.textBoxTerrain10.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain10.TabIndex = 4;
            this.textBoxTerrain10.Text = "10";
            this.textBoxTerrain10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxTerrain10.Visible = false;
            // 
            // textBoxTerrain9
            // 
            this.textBoxTerrain9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain9.Enabled = false;
            this.textBoxTerrain9.Location = new System.Drawing.Point(307, 75);
            this.textBoxTerrain9.Name = "textBoxTerrain9";
            this.textBoxTerrain9.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain9.TabIndex = 5;
            this.textBoxTerrain9.Text = "9";
            this.textBoxTerrain9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxTerrain9.Visible = false;
            // 
            // textBoxTerrain8
            // 
            this.textBoxTerrain8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain8.Enabled = false;
            this.textBoxTerrain8.Location = new System.Drawing.Point(271, 75);
            this.textBoxTerrain8.Name = "textBoxTerrain8";
            this.textBoxTerrain8.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain8.TabIndex = 6;
            this.textBoxTerrain8.Text = "8";
            this.textBoxTerrain8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxTerrain8.Visible = false;
            // 
            // textBoxTerrain7
            // 
            this.textBoxTerrain7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain7.Enabled = false;
            this.textBoxTerrain7.Location = new System.Drawing.Point(235, 75);
            this.textBoxTerrain7.Name = "textBoxTerrain7";
            this.textBoxTerrain7.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain7.TabIndex = 7;
            this.textBoxTerrain7.Text = "7";
            this.textBoxTerrain7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxTerrain7.Visible = false;
            // 
            // textBoxTerrain6
            // 
            this.textBoxTerrain6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain6.Enabled = false;
            this.textBoxTerrain6.Location = new System.Drawing.Point(199, 75);
            this.textBoxTerrain6.Name = "textBoxTerrain6";
            this.textBoxTerrain6.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain6.TabIndex = 8;
            this.textBoxTerrain6.Text = "6";
            this.textBoxTerrain6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxTerrain6.Visible = false;
            // 
            // textBoxTerrain5
            // 
            this.textBoxTerrain5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain5.Enabled = false;
            this.textBoxTerrain5.Location = new System.Drawing.Point(163, 76);
            this.textBoxTerrain5.Name = "textBoxTerrain5";
            this.textBoxTerrain5.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain5.TabIndex = 9;
            this.textBoxTerrain5.Text = "5";
            this.textBoxTerrain5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTerrain4
            // 
            this.textBoxTerrain4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain4.Enabled = false;
            this.textBoxTerrain4.Location = new System.Drawing.Point(127, 75);
            this.textBoxTerrain4.Name = "textBoxTerrain4";
            this.textBoxTerrain4.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain4.TabIndex = 10;
            this.textBoxTerrain4.Text = "4";
            this.textBoxTerrain4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTerrain3
            // 
            this.textBoxTerrain3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain3.Enabled = false;
            this.textBoxTerrain3.Location = new System.Drawing.Point(91, 75);
            this.textBoxTerrain3.Name = "textBoxTerrain3";
            this.textBoxTerrain3.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain3.TabIndex = 11;
            this.textBoxTerrain3.Text = "3";
            this.textBoxTerrain3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTerrain2
            // 
            this.textBoxTerrain2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBoxTerrain2.Enabled = false;
            this.textBoxTerrain2.Location = new System.Drawing.Point(55, 75);
            this.textBoxTerrain2.Name = "textBoxTerrain2";
            this.textBoxTerrain2.Size = new System.Drawing.Size(30, 31);
            this.textBoxTerrain2.TabIndex = 12;
            this.textBoxTerrain2.Text = "2";
            this.textBoxTerrain2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelDisponibilitéCamping
            // 
            this.labelDisponibilitéCamping.AutoSize = true;
            this.labelDisponibilitéCamping.Location = new System.Drawing.Point(14, 36);
            this.labelDisponibilitéCamping.Name = "labelDisponibilitéCamping";
            this.labelDisponibilitéCamping.Size = new System.Drawing.Size(272, 25);
            this.labelDisponibilitéCamping.TabIndex = 13;
            this.labelDisponibilitéCamping.Text = "Disponibilité des terrains pour le:";
            // 
            // comboBoxSelectionTerrain
            // 
            this.comboBoxSelectionTerrain.FormattingEnabled = true;
            this.comboBoxSelectionTerrain.Location = new System.Drawing.Point(223, 118);
            this.comboBoxSelectionTerrain.Name = "comboBoxSelectionTerrain";
            this.comboBoxSelectionTerrain.Size = new System.Drawing.Size(182, 33);
            this.comboBoxSelectionTerrain.TabIndex = 14;
            this.comboBoxSelectionTerrain.SelectedIndexChanged += new System.EventHandler(this.comboBoxSelectionTerrain_SelectedIndexChanged);
            // 
            // labelChoixTerrain
            // 
            this.labelChoixTerrain.AutoSize = true;
            this.labelChoixTerrain.Location = new System.Drawing.Point(14, 121);
            this.labelChoixTerrain.Name = "labelChoixTerrain";
            this.labelChoixTerrain.Size = new System.Drawing.Size(203, 25);
            this.labelChoixTerrain.TabIndex = 15;
            this.labelChoixTerrain.Text = "Choisissez votre terrain: ";
            // 
            // numericUpDownNombreAdulte
            // 
            this.numericUpDownNombreAdulte.Location = new System.Drawing.Point(378, 186);
            this.numericUpDownNombreAdulte.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownNombreAdulte.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownNombreAdulte.Name = "numericUpDownNombreAdulte";
            this.numericUpDownNombreAdulte.Size = new System.Drawing.Size(58, 31);
            this.numericUpDownNombreAdulte.TabIndex = 16;
            this.numericUpDownNombreAdulte.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownNombreAdulte.ValueChanged += new System.EventHandler(this.numericUpDownNombreAdulte_ValueChanged);
            // 
            // numericUpDownNombreEnfant
            // 
            this.numericUpDownNombreEnfant.Location = new System.Drawing.Point(378, 223);
            this.numericUpDownNombreEnfant.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownNombreEnfant.Name = "numericUpDownNombreEnfant";
            this.numericUpDownNombreEnfant.Size = new System.Drawing.Size(58, 31);
            this.numericUpDownNombreEnfant.TabIndex = 17;
            this.numericUpDownNombreEnfant.ValueChanged += new System.EventHandler(this.numericUpDownNombreEnfant_ValueChanged);
            // 
            // labelNombrePersonne
            // 
            this.labelNombrePersonne.AutoSize = true;
            this.labelNombrePersonne.Location = new System.Drawing.Point(14, 186);
            this.labelNombrePersonne.Name = "labelNombrePersonne";
            this.labelNombrePersonne.Size = new System.Drawing.Size(358, 25);
            this.labelNombrePersonne.TabIndex = 18;
            this.labelNombrePersonne.Text = "Choisissez le nombre de personnes (8 max):";
            // 
            // labelNombreAdulte
            // 
            this.labelNombreAdulte.AutoSize = true;
            this.labelNombreAdulte.Location = new System.Drawing.Point(442, 188);
            this.labelNombreAdulte.Name = "labelNombreAdulte";
            this.labelNombreAdulte.Size = new System.Drawing.Size(64, 25);
            this.labelNombreAdulte.TabIndex = 19;
            this.labelNombreAdulte.Text = "Adulte";
            // 
            // labelNombreEnfant
            // 
            this.labelNombreEnfant.AutoSize = true;
            this.labelNombreEnfant.Location = new System.Drawing.Point(442, 225);
            this.labelNombreEnfant.Name = "labelNombreEnfant";
            this.labelNombreEnfant.Size = new System.Drawing.Size(62, 25);
            this.labelNombreEnfant.TabIndex = 20;
            this.labelNombreEnfant.Text = "Enfant";
            // 
            // labelInformation
            // 
            this.labelInformation.AutoSize = true;
            this.labelInformation.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelInformation.Location = new System.Drawing.Point(13, 277);
            this.labelInformation.Name = "labelInformation";
            this.labelInformation.Size = new System.Drawing.Size(232, 28);
            this.labelInformation.TabIndex = 21;
            this.labelInformation.Text = "Rentrez vos informations:";
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.Location = new System.Drawing.Point(17, 317);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(56, 25);
            this.labelNom.TabIndex = 22;
            this.labelNom.Text = "Nom:";
            // 
            // labelPaiement
            // 
            this.labelPaiement.AutoSize = true;
            this.labelPaiement.Location = new System.Drawing.Point(19, 391);
            this.labelPaiement.Name = "labelPaiement";
            this.labelPaiement.Size = new System.Drawing.Size(157, 25);
            this.labelPaiement.TabIndex = 23;
            this.labelPaiement.Text = "Type de paiement:";
            // 
            // labelCourriel
            // 
            this.labelCourriel.AutoSize = true;
            this.labelCourriel.Location = new System.Drawing.Point(17, 354);
            this.labelCourriel.Name = "labelCourriel";
            this.labelCourriel.Size = new System.Drawing.Size(77, 25);
            this.labelCourriel.TabIndex = 24;
            this.labelCourriel.Text = "Courriel:";
            // 
            // comboBoxPaiement
            // 
            this.comboBoxPaiement.FormattingEnabled = true;
            this.comboBoxPaiement.Items.AddRange(new object[] {
            "Interact",
            "Crédit-Visa",
            "Crédit-Mastercard"});
            this.comboBoxPaiement.Location = new System.Drawing.Point(182, 388);
            this.comboBoxPaiement.Name = "comboBoxPaiement";
            this.comboBoxPaiement.Size = new System.Drawing.Size(199, 33);
            this.comboBoxPaiement.TabIndex = 25;
            this.comboBoxPaiement.SelectedIndexChanged += new System.EventHandler(this.comboBoxPaiement_SelectedIndexChanged);
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(79, 314);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(221, 31);
            this.textBoxNom.TabIndex = 26;
            this.textBoxNom.TextChanged += new System.EventHandler(this.textBoxNom_TextChanged);
            this.textBoxNom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNom_KeyPress);
            // 
            // textBoxCourriel
            // 
            this.textBoxCourriel.Location = new System.Drawing.Point(100, 351);
            this.textBoxCourriel.Name = "textBoxCourriel";
            this.textBoxCourriel.Size = new System.Drawing.Size(227, 31);
            this.textBoxCourriel.TabIndex = 27;
            this.textBoxCourriel.TextChanged += new System.EventHandler(this.textBoxCourriel_TextChanged);
            // 
            // buttonFaireReservation
            // 
            this.buttonFaireReservation.Location = new System.Drawing.Point(17, 440);
            this.buttonFaireReservation.Name = "buttonFaireReservation";
            this.buttonFaireReservation.Size = new System.Drawing.Size(239, 40);
            this.buttonFaireReservation.TabIndex = 28;
            this.buttonFaireReservation.Text = "Faire la réservation";
            this.buttonFaireReservation.UseVisualStyleBackColor = true;
            this.buttonFaireReservation.Click += new System.EventHandler(this.buttonFaireReservation_Click);
            // 
            // menuStripReservation
            // 
            this.menuStripReservation.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripReservation.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.réservationToolStripMenuItem});
            this.menuStripReservation.Location = new System.Drawing.Point(0, 0);
            this.menuStripReservation.Name = "menuStripReservation";
            this.menuStripReservation.Size = new System.Drawing.Size(841, 33);
            this.menuStripReservation.TabIndex = 29;
            this.menuStripReservation.Text = "menuStripReservation";
            // 
            // réservationToolStripMenuItem
            // 
            this.réservationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nouvelleRéservationToolStripMenuItem,
            this.faireLaRéservationToolStripMenuItem,
            this.toolStripSeparator1,
            this.afficherUneRéservationToolStripMenuItem,
            this.toolStripSeparator2,
            this.retourAuMenuPrincipalToolStripMenuItem});
            this.réservationToolStripMenuItem.Name = "réservationToolStripMenuItem";
            this.réservationToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.réservationToolStripMenuItem.Text = "Réservation";
            // 
            // nouvelleRéservationToolStripMenuItem
            // 
            this.nouvelleRéservationToolStripMenuItem.Name = "nouvelleRéservationToolStripMenuItem";
            this.nouvelleRéservationToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.nouvelleRéservationToolStripMenuItem.Size = new System.Drawing.Size(377, 34);
            this.nouvelleRéservationToolStripMenuItem.Text = "Nouvelle réservation";
            this.nouvelleRéservationToolStripMenuItem.Click += new System.EventHandler(this.nouvelleRéservationToolStripMenuItem_Click);
            // 
            // faireLaRéservationToolStripMenuItem
            // 
            this.faireLaRéservationToolStripMenuItem.Name = "faireLaRéservationToolStripMenuItem";
            this.faireLaRéservationToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.faireLaRéservationToolStripMenuItem.Size = new System.Drawing.Size(377, 34);
            this.faireLaRéservationToolStripMenuItem.Text = "Faire la réservation";
            this.faireLaRéservationToolStripMenuItem.Click += new System.EventHandler(this.faireLaRéservationToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(374, 6);
            // 
            // afficherUneRéservationToolStripMenuItem
            // 
            this.afficherUneRéservationToolStripMenuItem.Name = "afficherUneRéservationToolStripMenuItem";
            this.afficherUneRéservationToolStripMenuItem.Size = new System.Drawing.Size(377, 34);
            this.afficherUneRéservationToolStripMenuItem.Text = "Afficher une réservation";
            this.afficherUneRéservationToolStripMenuItem.Click += new System.EventHandler(this.afficherUneRéservationToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(374, 6);
            // 
            // retourAuMenuPrincipalToolStripMenuItem
            // 
            this.retourAuMenuPrincipalToolStripMenuItem.Name = "retourAuMenuPrincipalToolStripMenuItem";
            this.retourAuMenuPrincipalToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.retourAuMenuPrincipalToolStripMenuItem.Size = new System.Drawing.Size(377, 34);
            this.retourAuMenuPrincipalToolStripMenuItem.Text = "Retour au menu principal";
            this.retourAuMenuPrincipalToolStripMenuItem.Click += new System.EventHandler(this.retourAuMenuPrincipalToolStripMenuItem_Click);
            // 
            // labelFacture
            // 
            this.labelFacture.AutoSize = true;
            this.labelFacture.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelFacture.Location = new System.Drawing.Point(502, 265);
            this.labelFacture.Name = "labelFacture";
            this.labelFacture.Size = new System.Drawing.Size(75, 28);
            this.labelFacture.TabIndex = 30;
            this.labelFacture.Text = "Facture";
            // 
            // labelFactureAdulte
            // 
            this.labelFactureAdulte.AutoSize = true;
            this.labelFactureAdulte.Location = new System.Drawing.Point(502, 305);
            this.labelFactureAdulte.Name = "labelFactureAdulte";
            this.labelFactureAdulte.Size = new System.Drawing.Size(76, 25);
            this.labelFactureAdulte.TabIndex = 31;
            this.labelFactureAdulte.Text = "Adultes:";
            // 
            // labelFactureEnfants
            // 
            this.labelFactureEnfants.AutoSize = true;
            this.labelFactureEnfants.Location = new System.Drawing.Point(502, 342);
            this.labelFactureEnfants.Name = "labelFactureEnfants";
            this.labelFactureEnfants.Size = new System.Drawing.Size(74, 25);
            this.labelFactureEnfants.TabIndex = 32;
            this.labelFactureEnfants.Text = "Enfants:";
            // 
            // labelFacturePersonne
            // 
            this.labelFacturePersonne.AutoSize = true;
            this.labelFacturePersonne.Location = new System.Drawing.Point(502, 379);
            this.labelFacturePersonne.Name = "labelFacturePersonne";
            this.labelFacturePersonne.Size = new System.Drawing.Size(165, 25);
            this.labelFacturePersonne.TabIndex = 33;
            this.labelFacturePersonne.Text = "Total de personnes:";
            // 
            // labelFactureNuit
            // 
            this.labelFactureNuit.AutoSize = true;
            this.labelFactureNuit.Location = new System.Drawing.Point(502, 416);
            this.labelFactureNuit.Name = "labelFactureNuit";
            this.labelFactureNuit.Size = new System.Drawing.Size(150, 25);
            this.labelFactureNuit.TabIndex = 34;
            this.labelFactureNuit.Text = "Nombre de nuits:";
            // 
            // labelFactureCout
            // 
            this.labelFactureCout.AutoSize = true;
            this.labelFactureCout.Location = new System.Drawing.Point(502, 453);
            this.labelFactureCout.Name = "labelFactureCout";
            this.labelFactureCout.Size = new System.Drawing.Size(95, 25);
            this.labelFactureCout.TabIndex = 35;
            this.labelFactureCout.Text = "Coût total:";
            // 
            // textBoxFactureAdultes
            // 
            this.textBoxFactureAdultes.Enabled = false;
            this.textBoxFactureAdultes.Location = new System.Drawing.Point(584, 302);
            this.textBoxFactureAdultes.Name = "textBoxFactureAdultes";
            this.textBoxFactureAdultes.Size = new System.Drawing.Size(54, 31);
            this.textBoxFactureAdultes.TabIndex = 36;
            // 
            // textBoxFactureEnfants
            // 
            this.textBoxFactureEnfants.Enabled = false;
            this.textBoxFactureEnfants.Location = new System.Drawing.Point(584, 339);
            this.textBoxFactureEnfants.Name = "textBoxFactureEnfants";
            this.textBoxFactureEnfants.Size = new System.Drawing.Size(54, 31);
            this.textBoxFactureEnfants.TabIndex = 37;
            // 
            // textBoxFacturePersonnes
            // 
            this.textBoxFacturePersonnes.Enabled = false;
            this.textBoxFacturePersonnes.Location = new System.Drawing.Point(673, 376);
            this.textBoxFacturePersonnes.Name = "textBoxFacturePersonnes";
            this.textBoxFacturePersonnes.Size = new System.Drawing.Size(54, 31);
            this.textBoxFacturePersonnes.TabIndex = 38;
            // 
            // textBoxFactureNuits
            // 
            this.textBoxFactureNuits.Enabled = false;
            this.textBoxFactureNuits.Location = new System.Drawing.Point(658, 413);
            this.textBoxFactureNuits.Name = "textBoxFactureNuits";
            this.textBoxFactureNuits.Size = new System.Drawing.Size(54, 31);
            this.textBoxFactureNuits.TabIndex = 39;
            // 
            // textBoxFactureCout
            // 
            this.textBoxFactureCout.Enabled = false;
            this.textBoxFactureCout.Location = new System.Drawing.Point(603, 450);
            this.textBoxFactureCout.Name = "textBoxFactureCout";
            this.textBoxFactureCout.Size = new System.Drawing.Size(72, 31);
            this.textBoxFactureCout.TabIndex = 40;
            // 
            // statusStripSauvegarde
            // 
            this.statusStripSauvegarde.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStripSauvegarde.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelSauvegarde});
            this.statusStripSauvegarde.Location = new System.Drawing.Point(0, 491);
            this.statusStripSauvegarde.Name = "statusStripSauvegarde";
            this.statusStripSauvegarde.Size = new System.Drawing.Size(841, 22);
            this.statusStripSauvegarde.TabIndex = 41;
            this.statusStripSauvegarde.Text = "statusStripSauvegarde";
            // 
            // toolStripStatusLabelSauvegarde
            // 
            this.toolStripStatusLabelSauvegarde.Name = "toolStripStatusLabelSauvegarde";
            this.toolStripStatusLabelSauvegarde.Size = new System.Drawing.Size(0, 15);
            // 
            // pictureBoxCamping
            // 
            this.pictureBoxCamping.Image = global::TP2GiguèreGuillaume.Properties.Resources.camping_icon;
            this.pictureBoxCamping.Location = new System.Drawing.Point(731, 277);
            this.pictureBoxCamping.Name = "pictureBoxCamping";
            this.pictureBoxCamping.Size = new System.Drawing.Size(96, 90);
            this.pictureBoxCamping.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCamping.TabIndex = 42;
            this.pictureBoxCamping.TabStop = false;
            // 
            // errorProviderNom
            // 
            this.errorProviderNom.ContainerControl = this;
            // 
            // errorProviderTotalPersonne
            // 
            this.errorProviderTotalPersonne.ContainerControl = this;
            // 
            // errorProviderCourriel
            // 
            this.errorProviderCourriel.ContainerControl = this;
            // 
            // errorProviderTerrain
            // 
            this.errorProviderTerrain.ContainerControl = this;
            // 
            // errorProviderPaiement
            // 
            this.errorProviderPaiement.ContainerControl = this;
            // 
            // openFileDialogReservation
            // 
            this.openFileDialogReservation.FileName = "openFileDialog1";
            // 
            // FormEcranReservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 513);
            this.Controls.Add(this.pictureBoxCamping);
            this.Controls.Add(this.statusStripSauvegarde);
            this.Controls.Add(this.textBoxFactureCout);
            this.Controls.Add(this.textBoxFactureNuits);
            this.Controls.Add(this.textBoxFacturePersonnes);
            this.Controls.Add(this.textBoxFactureEnfants);
            this.Controls.Add(this.textBoxFactureAdultes);
            this.Controls.Add(this.labelFactureCout);
            this.Controls.Add(this.labelFactureNuit);
            this.Controls.Add(this.labelFacturePersonne);
            this.Controls.Add(this.labelFactureEnfants);
            this.Controls.Add(this.labelFactureAdulte);
            this.Controls.Add(this.labelFacture);
            this.Controls.Add(this.buttonFaireReservation);
            this.Controls.Add(this.textBoxCourriel);
            this.Controls.Add(this.textBoxNom);
            this.Controls.Add(this.comboBoxPaiement);
            this.Controls.Add(this.labelCourriel);
            this.Controls.Add(this.labelPaiement);
            this.Controls.Add(this.labelNom);
            this.Controls.Add(this.labelInformation);
            this.Controls.Add(this.labelNombreEnfant);
            this.Controls.Add(this.labelNombreAdulte);
            this.Controls.Add(this.labelNombrePersonne);
            this.Controls.Add(this.numericUpDownNombreEnfant);
            this.Controls.Add(this.numericUpDownNombreAdulte);
            this.Controls.Add(this.labelChoixTerrain);
            this.Controls.Add(this.comboBoxSelectionTerrain);
            this.Controls.Add(this.labelDisponibilitéCamping);
            this.Controls.Add(this.textBoxTerrain2);
            this.Controls.Add(this.textBoxTerrain3);
            this.Controls.Add(this.textBoxTerrain4);
            this.Controls.Add(this.textBoxTerrain5);
            this.Controls.Add(this.textBoxTerrain6);
            this.Controls.Add(this.textBoxTerrain7);
            this.Controls.Add(this.textBoxTerrain8);
            this.Controls.Add(this.textBoxTerrain9);
            this.Controls.Add(this.textBoxTerrain10);
            this.Controls.Add(this.textBoxTerrain1);
            this.Controls.Add(this.pictureBoxCampingChoisi);
            this.Controls.Add(this.textBoxNomCamping);
            this.Controls.Add(this.menuStripReservation);
            this.MainMenuStrip = this.menuStripReservation;
            this.Name = "FormEcranReservation";
            this.Text = "FormEcranReservation";
            this.Load += new System.EventHandler(this.FormEcranReservation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCampingChoisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNombreAdulte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNombreEnfant)).EndInit();
            this.menuStripReservation.ResumeLayout(false);
            this.menuStripReservation.PerformLayout();
            this.statusStripSauvegarde.ResumeLayout(false);
            this.statusStripSauvegarde.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCamping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderNom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTotalPersonne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCourriel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTerrain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderPaiement)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBoxNomCamping;
        private PictureBox pictureBoxCampingChoisi;
        private TextBox textBoxTerrain1;
        private TextBox textBoxTerrain10;
        private TextBox textBoxTerrain9;
        private TextBox textBoxTerrain8;
        private TextBox textBoxTerrain7;
        private TextBox textBoxTerrain6;
        private TextBox textBoxTerrain5;
        private TextBox textBoxTerrain4;
        private TextBox textBoxTerrain3;
        private TextBox textBoxTerrain2;
        private Label labelDisponibilitéCamping;
        private ComboBox comboBoxSelectionTerrain;
        private Label labelChoixTerrain;
        private NumericUpDown numericUpDownNombreAdulte;
        private NumericUpDown numericUpDownNombreEnfant;
        private Label labelNombrePersonne;
        private Label labelNombreAdulte;
        private Label labelNombreEnfant;
        private Label labelInformation;
        private Label labelNom;
        private Label labelPaiement;
        private Label labelCourriel;
        private ComboBox comboBoxPaiement;
        private TextBox textBoxNom;
        private TextBox textBoxCourriel;
        private Button buttonFaireReservation;
        private MenuStrip menuStripReservation;
        private ToolStripMenuItem réservationToolStripMenuItem;
        private ToolStripMenuItem nouvelleRéservationToolStripMenuItem;
        private ToolStripMenuItem faireLaRéservationToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem afficherUneRéservationToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem retourAuMenuPrincipalToolStripMenuItem;
        private Label labelFacture;
        private Label labelFactureAdulte;
        private Label labelFactureEnfants;
        private Label labelFacturePersonne;
        private Label labelFactureNuit;
        private Label labelFactureCout;
        private TextBox textBoxFactureAdultes;
        private TextBox textBoxFactureEnfants;
        private TextBox textBoxFacturePersonnes;
        private TextBox textBoxFactureNuits;
        private TextBox textBoxFactureCout;
        private StatusStrip statusStripSauvegarde;
        private PictureBox pictureBoxCamping;
        private ErrorProvider errorProviderNom;
        private ErrorProvider errorProviderTotalPersonne;
        private ErrorProvider errorProviderCourriel;
        private ErrorProvider errorProviderTerrain;
        private ErrorProvider errorProviderPaiement;
        private SaveFileDialog saveFileDialogReserver;
        private ToolStripStatusLabel toolStripStatusLabelSauvegarde;
        private OpenFileDialog openFileDialogReservation;
    }
}