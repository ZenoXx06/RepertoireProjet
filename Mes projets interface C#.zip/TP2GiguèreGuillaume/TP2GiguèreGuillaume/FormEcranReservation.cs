﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TP2GiguèreGuillaume
{
    public partial class FormEcranReservation : Form
    {
        private string nomCamping;
        private int nbTerrain;
        private string cheminImage;
        private string nomFichier;
        private int dateArrivee;
        private int dateDepart;
        const int nbJours = 365;
        Boolean nombrePersonnesBon = false;
        Boolean nomBon = false;
        Boolean courrielBon = false;
        Boolean terrainBon = false;
        Boolean paiementBon = false;
        private Reservation[] tabReservation = new Reservation[10000];
        int nombreReservation = 0;
        public FormEcranReservation(string pNomCamping, int pNbTerrain, string pCheminImage, string pNomFichier, int pDateArrivee, int pDateDepart)
        {
            InitializeComponent();
            nomCamping = pNomCamping;
            nbTerrain = pNbTerrain;
            cheminImage = pCheminImage;
            nomFichier = pNomFichier;
            dateArrivee = pDateArrivee;
            dateDepart = pDateDepart;
            Boolean[,] ReservationDispo = new Boolean[nbTerrain, nbJours];
        }

        private void afficherUneRéservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAffichageReservation formSelection2 = new FormAffichageReservation(nomCamping, cheminImage, tabReservation, nombreReservation);
            formSelection2.ShowDialog();
        }

        private void FormEcranReservation_Load(object sender, EventArgs e)
        {
            string chemin = Application.StartupPath + "\\";
            if (File.Exists(chemin + nomFichier + ".txt"))
            {
                try
                {
                    StreamReader lecture = new StreamReader(chemin + nomFichier + ".txt");
                    int conteur = 0;
                    do
                    {
                        string sLigne = lecture.ReadLine();
                        if (sLigne != null)
                        {
                            if (sLigne.Contains(';'))
                            {
                                string[] ligne = sLigne.Split(';');
                                tabReservation[conteur] = new Reservation(Int32.Parse(ligne[0]), ligne[1], ligne[2], ligne[3], ligne[4], Int32.Parse(ligne[5]), Int32.Parse(ligne[6]), ligne[7], Int32.Parse(ligne[8]), Int32.Parse(ligne[9]), Int32.Parse(ligne[10].Substring(0, ligne[10].Length - 2)));
                                conteur++;
                                nombreReservation = Int32.Parse(ligne[0]);
                            }
                        }
                    } while (!lecture.EndOfStream);
                    lecture.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur de fichier : " + ex.Message, "Lecture de fichier pour les réservations",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Erreur dans l'ouverture du form pour la gestion de reservation: le fichier n'existe pas", "Ouverture des réservations",
                      MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            textBoxNomCamping.Text = nomCamping;
            pictureBoxCampingChoisi.ImageLocation = cheminImage;
            if (nbTerrain > 5)
            {
                textBoxTerrain6.Visible = true;
                textBoxTerrain7.Visible = true;
                textBoxTerrain8.Visible = true;
                if (nbTerrain > 8)
                {
                    textBoxTerrain9.Visible = true;
                    textBoxTerrain10.Visible = true;
                }
            }
            Boolean[,] ReservationDispo = new Boolean[nbTerrain, nbJours];
            for (int i = 0; i < nbTerrain; i++)
            {
                for (int j = 0; j < nbJours; j++)
                {
                    ReservationDispo[i, j] = false;
                }
            }
            for (int i = 0; i < nombreReservation; i++)
            {
                    for (int j = tabReservation[i].dateDebut; j < tabReservation[i].dateFin; j++)
                    {
                        int terrain = Int32.Parse(tabReservation[i].terrain.Substring(tabReservation[i].terrain.Length - 1));
                        if (terrain == 0) {
                            terrain = 10;
                        }
                        terrain--;
                        ReservationDispo[terrain, j] = true;
                    }
            }
            Boolean reserve1 = false;
            Boolean reserve2 = false;
            Boolean reserve3 = false;
            Boolean reserve4 = false;
            Boolean reserve5 = false;
            Boolean reserve6 = false;
            Boolean reserve7 = false;
            Boolean reserve8 = false;
            Boolean reserve9 = false;
            Boolean reserve10 = false;
            for (int ctr = dateArrivee; ctr < dateDepart; ctr++)
            {
                if (ReservationDispo[0, ctr] == true)
                {
                    textBoxTerrain1.BackColor = Color.DeepPink;
                    reserve1 = true;
                }
                if (ReservationDispo[1, ctr] == true)
                {
                    textBoxTerrain2.BackColor = Color.DeepPink;
                    reserve2 = true;
                }
                if (ReservationDispo[2, ctr] == true)
                {
                    textBoxTerrain3.BackColor = Color.DeepPink;
                    reserve3 = true;
                }
                if (ReservationDispo[3, ctr] == true)
                {
                    textBoxTerrain4.BackColor = Color.DeepPink;
                    reserve4 = true;
                }
                if (ReservationDispo[4, ctr] == true)
                {
                    textBoxTerrain5.BackColor = Color.DeepPink;
                    reserve5 = true;
                }
                if (nbTerrain > 5)
                {
                    if (ReservationDispo[5, ctr] == true)
                    {
                        textBoxTerrain6.BackColor = Color.DeepPink;
                        reserve6 = true;
                    }
                    if (ReservationDispo[6, ctr] == true)
                    {
                        textBoxTerrain7.BackColor = Color.DeepPink;
                        reserve7 = true;
                    }
                    if (ReservationDispo[7, ctr] == true)
                    {
                        textBoxTerrain8.BackColor = Color.DeepPink;
                        reserve8 = true;
                    }
                    if (nbTerrain > 8)
                    {
                        if (ReservationDispo[8, ctr] == true)
                        {
                            textBoxTerrain9.BackColor = Color.DeepPink;
                            reserve9 = true;
                        }
                        if (ReservationDispo[9, ctr] == true)
                        {
                            textBoxTerrain10.BackColor = Color.DeepPink;
                            reserve10 = true;
                        }
                    }
                }
            }
            if (reserve1)
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 1 - Réservé");
            }
            else
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 1");
            }
            if (reserve2)
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 2 - Réservé");
            }
            else
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 2");
            }
            if (reserve3)
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 3 - Réservé");
            }
            else
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 3");
            }
            if (reserve4)
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 4 - Réservé");
            }
            else
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 4");
            }
            if (reserve5)
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 5 - Réservé");
            }
            else
            {
                comboBoxSelectionTerrain.Items.Add("Terrain 5");
            }
            if (nbTerrain > 5)
            {
                if (reserve6)
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 6 - Réservé");
                }
                else
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 6");
                }
                if (reserve7)
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 7 - Réservé");
                }
                else
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 7");
                }
                if (reserve8)
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 8 - Réservé");
                }
                else
                {
                    comboBoxSelectionTerrain.Items.Add("Terrain 8");
                }
                if (nbTerrain > 8)
                {
                    if (reserve9)
                    {
                        comboBoxSelectionTerrain.Items.Add("Terrain 9 - Réservé");
                    }
                    else
                    {
                        comboBoxSelectionTerrain.Items.Add("Terrain 9");
                    }
                    if (reserve10)
                    {
                        comboBoxSelectionTerrain.Items.Add("Terrain 10 - Réservé");
                    }
                    else
                    {
                        comboBoxSelectionTerrain.Items.Add("Terrain 10");
                    }
                }
            }
            textBoxFactureNuits.Text = (dateDepart - dateArrivee).ToString();
            textBoxFactureAdultes.Text = numericUpDownNombreAdulte.Value.ToString();
            textBoxFactureEnfants.Text = numericUpDownNombreEnfant.Value.ToString();
            errorProviderTotalPersonne.SetError(textBoxFacturePersonnes, "Choisissez votre nombre de personnes");
            errorProviderNom.SetError(textBoxNom, "Choisissez votre nom");
            errorProviderCourriel.SetError(textBoxCourriel, "Choisissez votre courriel");
            errorProviderTerrain.SetError(comboBoxSelectionTerrain, "Choisissez votre terrain");
            errorProviderPaiement.SetError(comboBoxPaiement, "Choisissez votre Paiement");
        }

        private void numericUpDownNombreAdulte_ValueChanged(object sender, EventArgs e)
        {
            textBoxFactureAdultes.Text = numericUpDownNombreAdulte.Value.ToString();
            textBoxFacturePersonnes.Text = (numericUpDownNombreAdulte.Value + numericUpDownNombreEnfant.Value).ToString();
            if (numericUpDownNombreAdulte.Value + numericUpDownNombreEnfant.Value > 8)
            {
                errorProviderTotalPersonne.SetError(textBoxFacturePersonnes, "Il y a trop de personne");
                nombrePersonnesBon = false;
            } else
            {
                errorProviderTotalPersonne.Clear();
                nombrePersonnesBon = true;
            }
            if (nomCamping == "Parc du Bic")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 20 + numericUpDownNombreEnfant.Value * 5) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            }
            else if (nomCamping == "Parc du Mont-Orford")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 15 + numericUpDownNombreEnfant.Value * 5) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            }
            else if (nomCamping == "Camping du Rocher Percé")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 30 + numericUpDownNombreEnfant.Value * 10) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            }
            else if (nomCamping == "Camping de la plage de St-Siméon")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 25 + numericUpDownNombreEnfant.Value * 0) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            }
        }

        private void numericUpDownNombreEnfant_ValueChanged(object sender, EventArgs e)
        {
            textBoxFactureEnfants.Text = numericUpDownNombreEnfant.Value.ToString();
            textBoxFacturePersonnes.Text = (numericUpDownNombreAdulte.Value + numericUpDownNombreEnfant.Value).ToString();
            if (numericUpDownNombreAdulte.Value + numericUpDownNombreEnfant.Value > 8)
            {
                errorProviderTotalPersonne.SetError(textBoxFacturePersonnes, "Il y a trop de personne");
                nombrePersonnesBon = false;
            }
            else
            {
                errorProviderTotalPersonne.Clear();
                nombrePersonnesBon = true;
            }
            if (nomCamping == "Parc du Bic")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 20 + numericUpDownNombreEnfant.Value * 5) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            } else if (nomCamping == "Parc du Mont-Orford")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 15 + numericUpDownNombreEnfant.Value * 5) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            } else if (nomCamping == "Camping du Rocher Percé")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 30 + numericUpDownNombreEnfant.Value * 10) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            } else if (nomCamping == "Camping de la plage de St-Siméon")
            {
                textBoxFactureCout.Text = ((numericUpDownNombreAdulte.Value * 25 + numericUpDownNombreEnfant.Value * 0) * Int32.Parse(textBoxFactureNuits.Text)).ToString() + " $";
            }
        }

        private void comboBoxSelectionTerrain_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxSelectionTerrain.SelectedIndex == -1)
            {
                errorProviderTerrain.SetError(comboBoxSelectionTerrain, "Aucun terrain choisi");
                terrainBon = false;
            }
            else if (comboBoxSelectionTerrain.Text.Contains("Réservé"))
            {
                errorProviderTerrain.SetError(comboBoxSelectionTerrain, "Le terrain est déja réservé");
                terrainBon = false;
            } else
            {
                errorProviderTerrain.Clear();
                terrainBon = true;
            }
        }

        private void textBoxNom_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char touche = e.KeyChar;
            if (Char.IsLetter(touche) || Char.IsControl(touche) || Char.IsSeparator(touche) || touche == '\'' || touche == '-')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBoxNom_TextChanged(object sender, EventArgs e)
        {
            string texte = textBoxNom.Text;
            bool bon = true;

            foreach (char c in texte)
            {
                if (!char.IsLetter(c) && !char.IsSeparator(c) && c != '\'' && c != '-')
                {
                    bon = false;
                }
            }
            if (!bon || texte == "")
            {
                errorProviderNom.SetError(textBoxNom, "Le nom n'est pas bon");
                nomBon = false;
            }
            else
            {
                errorProviderNom.Clear();
                nomBon = true;
            }
        }

        private void textBoxCourriel_TextChanged(object sender, EventArgs e)
        {
            string texte = textBoxCourriel.Text;
            bool bon = false;

            foreach (char c in texte)
            {
                if (c == '@')
                {
                    bon = true;
                }
            }
            if (!bon || texte == "")
            {
                errorProviderCourriel.SetError(textBoxCourriel, "Le courriel n'est pas bon");
                courrielBon = false;

            }
            else
            {
                errorProviderCourriel.Clear();
                courrielBon = true;
            }
        }

        private void comboBoxPaiement_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxPaiement.SelectedIndex == -1)
            {
                errorProviderPaiement.SetError(comboBoxPaiement, "Aucun mode de paiement choisi");
                paiementBon = false;
            }
            else
            {
                errorProviderPaiement.Clear();
                paiementBon = true;
            }
        }

        private void retourAuMenuPrincipalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void nouvelleRéservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            comboBoxSelectionTerrain.SelectedIndex = -1;
            textBoxNom.Text = "";
            textBoxCourriel.Text = "";
            comboBoxPaiement.SelectedIndex = -1;
            numericUpDownNombreAdulte.Value = 1;
            numericUpDownNombreEnfant.Value = 0;
            toolStripStatusLabelSauvegarde.Text = "";
            textBoxFacturePersonnes.Text = "";
            textBoxFactureCout.Text = "";
            textBoxFactureAdultes.Text = numericUpDownNombreAdulte.Value.ToString();
            textBoxFactureEnfants.Text = numericUpDownNombreEnfant.Value.ToString();
            errorProviderTotalPersonne.SetError(textBoxFacturePersonnes, "Choisissez votre nombre de personnes");
            errorProviderNom.SetError(textBoxNom, "Choisissez votre nom");
            errorProviderCourriel.SetError(textBoxCourriel, "Choisissez votre courriel");
            errorProviderTerrain.SetError(comboBoxSelectionTerrain, "Choisissez votre terrain");
            errorProviderPaiement.SetError(comboBoxPaiement, "Choisissez votre Paiement");
            courrielBon = false;
            nomBon = false;
            nombrePersonnesBon = false;
            paiementBon = false;
            terrainBon = false;
        }

        private void buttonFaireReservation_Click(object sender, EventArgs e)
        {
            if (courrielBon && nomBon && nombrePersonnesBon && paiementBon && terrainBon){
                saveFileDialogReserver.InitialDirectory = Application.StartupPath + "\\";
                saveFileDialogReserver.Title = "Sauvegarde du fichier";
                saveFileDialogReserver.FileName = nomFichier;
                saveFileDialogReserver.Filter = "Fichier texte|*.txt";
                saveFileDialogReserver.FilterIndex = 1;
                if (saveFileDialogReserver.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StreamWriter ecriture = new StreamWriter(saveFileDialogReserver.FileName, true);
                        string ligne = nombreReservation + 1 + ";" + nomCamping + ";" + textBoxNom.Text + ";" + textBoxCourriel.Text + ";" + comboBoxPaiement.Text + ";" + dateArrivee + ";" + dateDepart + ";" + comboBoxSelectionTerrain.Text + ";" + textBoxFactureAdultes.Text + ";" + textBoxFactureEnfants.Text + ";" + textBoxFactureCout.Text;
                        ecriture.WriteLine(ligne);
                        ecriture.Close();
                        tabReservation[nombreReservation] = new Reservation(nombreReservation + 1, nomCamping, textBoxNom.Text, textBoxCourriel.Text, comboBoxPaiement.Text, dateArrivee, dateDepart, comboBoxSelectionTerrain.Text, Int32.Parse(textBoxFactureAdultes.Text), Int32.Parse(textBoxFactureEnfants.Text), Int32.Parse(textBoxFactureCout.Text.Substring(0, textBoxFactureCout.TextLength - 2)));
                        toolStripStatusLabelSauvegarde.Text = "La sauvegarde a été affectuée";
                        nombreReservation++;
                        switch (comboBoxSelectionTerrain.SelectedIndex)
                        {
                            case 0:
                                textBoxTerrain1.BackColor = Color.DeepPink;
                                break;
                            case 1:
                                textBoxTerrain2.BackColor = Color.DeepPink;
                                break;
                            case 2:
                                textBoxTerrain3.BackColor = Color.DeepPink;
                                break;
                            case 3:
                                textBoxTerrain4.BackColor = Color.DeepPink;
                                break;
                            case 4:
                                textBoxTerrain5.BackColor = Color.DeepPink;
                                break;
                            case 5:
                                textBoxTerrain6.BackColor = Color.DeepPink;
                                break;
                            case 6:
                                textBoxTerrain7.BackColor = Color.DeepPink;
                                break;
                            case 7:
                                textBoxTerrain8.BackColor = Color.DeepPink;
                                break;
                            case 8:
                                textBoxTerrain9.BackColor = Color.DeepPink;
                                break;
                            case 9:
                                textBoxTerrain10.BackColor = Color.DeepPink;
                                break;
                        }
                        comboBoxSelectionTerrain.Items[comboBoxSelectionTerrain.SelectedIndex] = "Terrain " + (comboBoxSelectionTerrain.SelectedIndex + 1) + " - Réservé";
                        comboBoxSelectionTerrain.SelectedIndex = -1;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur de fichier : " + ex.Message, "Sauvegarde de fichier", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            } else
            {
                MessageBox.Show("Une entrée n'est pas bonne", "ERREUR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void faireLaRéservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            buttonFaireReservation_Click(sender, e);
        }
    }
}