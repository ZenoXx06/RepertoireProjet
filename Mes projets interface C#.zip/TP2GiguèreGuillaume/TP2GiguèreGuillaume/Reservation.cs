﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2GiguèreGuillaume
{
    public class Reservation
    {
        private int _noReservation;
        public int noReservation { get { return _noReservation; } set { _noReservation = value; } }

        private string _nomCamping;
        public string nomCamping { get { return _nomCamping; } set { _nomCamping = value; } }

        private string _nom;
        public string nom { get { return _nom; } set { _nom = value; } }

        private string _courriel;
        public string courriel { get { return _courriel; } set { _courriel = value; } }

        private string _paiement;
        public string paiement { get { return _paiement; } set { _paiement = value; } }

        private int _dateDebut;
        public int dateDebut { get { return _dateDebut; } set { _dateDebut = value; } }

        private int _dateFin;
        public int dateFin { get { return _dateFin; } set { _dateFin = value; } }

        private string _terrain;
        public string terrain { get { return _terrain; } set { _terrain = value; } }

        private int _nbAdulte;
        public int nbAdulte { get { return _nbAdulte; } set { _nbAdulte = value; } }

        private int _nbEnfant;
        public int nbEnfant { get { return _nbEnfant; } set { _nbEnfant = value; } }

        private int _coutTotal;
        public int coutTotal { get { return _coutTotal; } set { _coutTotal = value; } }

        public Reservation()
        {
            _noReservation = 0;
            _nomCamping = null;
            _nom = null;
            _courriel = null;
            _paiement = null;
            _dateDebut = 0;
            _dateFin = 0;
            _terrain = null;
            _nbAdulte = 0;
            _nbEnfant = 0;
            _coutTotal = 0;
        }

        public Reservation(int pNoReservation, string pNomCamping, string pNom, string pCourriel, string pPaiement, int pDateDebut, int pDateFin, string pTerrain, int pNbAdulte, int pNbEnfant, int pCoutTotal)
        {
            _noReservation = pNoReservation;
            _nomCamping = pNomCamping;
            _nom = pNom;
            _courriel = pCourriel;
            _paiement = pPaiement;
            _dateDebut = pDateDebut;
            _dateFin = pDateFin;
            _terrain = pTerrain;
            _nbAdulte = pNbAdulte;
            _nbEnfant = pNbEnfant;
            _coutTotal = pCoutTotal;
        }

        public override string ToString()
        {
            return _noReservation + " - " + _nom;
        }
    }
}
