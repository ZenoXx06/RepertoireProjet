namespace TP2GiguèreGuillaume
{
    public partial class Form1 : Form
    {
        private string chemin = Application.StartupPath + "\\";
        Boolean dateArriveeBon = false;
        Boolean dateDepartBon = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonReservation_Click(object sender, EventArgs e)
        {
            if (comboBoxChoixCamping.SelectedIndex != -1)
            {
                if (dateArriveeBon && dateDepartBon)
                {
                    int dateArrivee = dateTimePickerArrivee.Value.DayOfYear;
                    int dateDepart = dateTimePickerDepart.Value.DayOfYear;
                    Camping camp = (Camping)comboBoxChoixCamping.SelectedItem;
                    string nomCamping = camp.nomCamping;
                    int nbTerrain = camp.nbTerrain;
                    string cheminImage = camp.cheminImage;
                    string nomFichier = camp.nomFichier;
                        FormEcranReservation formSelection = new FormEcranReservation(nomCamping, nbTerrain, cheminImage, nomFichier, dateArrivee, dateDepart);
                        formSelection.ShowDialog();
                } else
                {
                    MessageBox.Show("Une date n'est pas bonne", "Erreur de date",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } else
            {
                MessageBox.Show("Vous n'avez pas sélectionné de Camping", "Erreur de date", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Camping camping1 = new Camping(1, "Parc du Bic", 10, chemin + "campingBic.jpg", "RESERV_BIC");
            comboBoxChoixCamping.Items.Add(camping1);
            Camping camping2 = new Camping(2, "Parc du Mont-Orford", 8, chemin + "campingOrford.jpg", "RESERV_ORFORD");
            comboBoxChoixCamping.Items.Add(camping2);
            Camping camping3 = new Camping(3, "Camping du Rocher Percé", 5, chemin + "campingPerce.jpg", "RESERV_PERCE");
            comboBoxChoixCamping.Items.Add(camping3);
            Camping camping4 = new Camping(4, "Camping de la plage de St-Siméon", 10, chemin + "campingStSimeon.jpg", "RESERV_SIMEON");
            comboBoxChoixCamping.Items.Add(camping4);
            errorProviderDateArrivee.SetError(dateTimePickerArrivee, "Choisissez votre date");
            errorProviderDateDepart.SetError(dateTimePickerDepart, "Choisissez votre date");
        }

        private void dateTimePickerArrivee_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePickerDepart.Value < dateTimePickerArrivee.Value)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "La date est plus grande que le départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "La date est plus petite que l'arrivée");
                dateArriveeBon = false;
                dateDepartBon = false;
            } else if (dateTimePickerDepart.Value == dateTimePickerArrivee.Value)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "La date est la même que le départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "La date est la même que l'arrivée");
                dateArriveeBon = false;
                dateDepartBon = false;
            } else if (dateTimePickerArrivee.Value.DayOfYear < 121 || dateTimePickerArrivee.Value.DayOfYear > 304) {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "La date n'est pas dans la période d'ouverture des campings");
                dateArriveeBon = false;
            } else if (dateTimePickerArrivee.Value.Year != dateTimePickerDepart.Value.Year)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "L'année n'est pas la même que l'année de départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "L'année n'est pas la même que l'année d'arrivée");
                dateArriveeBon = false;
                dateDepartBon = false;
            } else
            {
                errorProviderDateArrivee.Clear();
                dateArriveeBon = true;
                if (dateDepartBon == false)
                {
                    dateTimePickerDepart_ValueChanged(sender, e);
                }
            }
        }

        private void dateTimePickerDepart_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePickerDepart.Value < dateTimePickerArrivee.Value)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "La date est plus grande que le départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "La date est plus petite que l'arrivée");
                dateDepartBon = false;
                dateArriveeBon = false;
            }
            else if (dateTimePickerDepart.Value == dateTimePickerArrivee.Value)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "La date est la même que le départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "La date est la même que l'arrivée");
                dateDepartBon = false;
                dateArriveeBon = false;
            }
            else if (dateTimePickerDepart.Value.DayOfYear < 121 || dateTimePickerDepart.Value.DayOfYear > 304)
            {
                errorProviderDateDepart.SetError(dateTimePickerDepart, "La date n'est pas dans la période d'ouverture des campings");
                dateDepartBon = false;
            }
            else if (dateTimePickerArrivee.Value.Year != dateTimePickerDepart.Value.Year)
            {
                errorProviderDateArrivee.SetError(dateTimePickerArrivee, "L'année n'est pas la même que l'année de départ");
                errorProviderDateDepart.SetError(dateTimePickerDepart, "L'année n'est pas la même que l'année d'arrivée");
                dateDepartBon = false;
                dateArriveeBon = false;
            }
            else
            {
                errorProviderDateDepart.Clear();
                dateDepartBon = true;
                if (dateArriveeBon == false)
                {
                    dateTimePickerArrivee_ValueChanged(sender, e);
                }
            }
        }

        private void comboBoxChoixCamping_SelectedIndexChanged(object sender, EventArgs e)
        {
            Camping camp = (Camping) comboBoxChoixCamping.SelectedItem;
            pictureBoxVilleAcceuil.ImageLocation = camp.cheminImage;
        }
    }
}