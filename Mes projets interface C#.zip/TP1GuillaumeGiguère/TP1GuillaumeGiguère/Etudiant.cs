﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1GuillaumeGiguère
{
    internal class Etudiant
    {
        private int _noEtudiant;
        public int noEtudiant { get { return _noEtudiant; } set { _noEtudiant = value; } }

        private string _prenom;
        public string prenom { get { return _prenom; } set { _prenom = value; } }

        private string _nom;
        public string nom { get { return _nom; } set { _nom = value; } }

        private string _codePermanent;
        public string codePermanent { get { return _codePermanent; } set { _codePermanent = value; } }

        private string _groupe;
        public string groupe { get { return _groupe; } set { _groupe = value; } }

        private string[] _matiere;
        public string[] matiere { get { return _matiere; } set { _matiere = value; } }

        public int[] _note;
        public int[] note { get { return _note; } set { _note = value; } }

        public Etudiant()
        {
            _noEtudiant = 0;
            _prenom = null;
            _nom = null;
            _codePermanent = null;
            _groupe = null;
            _matiere = null;
            _note = null;
        }

        public Etudiant(int pNoEtudiant, string pPrenom, string pNom, string pCodePermanent, string pGroupe, string[] pMatiere, int[] pNote)
        {
            _noEtudiant = pNoEtudiant;
            _prenom = pPrenom;
            _nom = pNom;
            _codePermanent = pCodePermanent;
            _groupe = pGroupe;
            _matiere = pMatiere;
            _note = pNote;
        }

        public override string ToString()
        {
            return _prenom + " " + _nom;
        }
    }
}
