﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1GuillaumeGiguère
{
    internal class Constante
    {
        public const int maximum = 10;

        public const string matiere1 = "Base de données";
        public const string matiere2 = "Interface utilisateur";
        public const string matiere3 = "Interface Web";
        public const string matiere4 = "Sécurité et éthique";
        public const string matiere5 = "Structure de données";

        public const string messageErreurPrenom = "Il faut seulement des lettres dans le champ";
        public const string messageErreurNom = "Il faut seulement des lettres dans le champ";
        public const string messageErreurCode1 = "Les lettres 1-2 ne sont pas bonne (Vérifier les MAJ)";
        public const string messageErreurCode2 = "Les lettres 3-4 ne sont pas bonne (Vérifier les MAJ)";
        public const string messageErreurCode3 = "Le format de chiffre n'est pas bon ";
        public const string messageErreurCode4 = "Il n'a pas le bon nombre de caractère";
        public const string messageSauvegarder = "Les donnée on été sauvegarder";
        public const string messageNonSauvegarder = "Les donnée ne sont pas bonne et ne sont pas sauvegarder";
        public const string messageTropEtudiant = "Il y a trop d'étudiant";
    }
}
