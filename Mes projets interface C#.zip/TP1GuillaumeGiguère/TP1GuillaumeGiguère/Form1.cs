namespace TP1GuillaumeGiguère
{
    public partial class Form1 : Form
    {
        private Etudiant[] tabEtudiant = new Etudiant[Constante.maximum];
        bool prenomBon = false;
        bool nomBon = false;
        bool codeBon = false;
        public Form1()
        {
            InitializeComponent();
            textBoxCours1.Text = Constante.matiere1;
            textBoxMatiere1.Text = Constante.matiere1;
            textBoxCours2.Text = Constante.matiere2;
            textBoxMatiere2.Text = Constante.matiere2;
            textBoxCours3.Text = Constante.matiere3;
            textBoxMatiere3.Text = Constante.matiere3;
            textBoxCours4.Text = Constante.matiere4;
            textBoxMatiere4.Text = Constante.matiere4;
            textBoxCours5.Text = Constante.matiere5;
            textBoxMatiere5.Text = Constante.matiere5;
        }

        private void buttonQuitter_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBoxPrenom_KeyPress(object sender, KeyPressEventArgs e)
        {
           Char touche = e.KeyChar;
            if (Char.IsLetter(touche) || Char.IsControl(touche))
            {
                e.Handled = false;
            } else
            {
                e.Handled = true;
            }
        }

        private void textBoxNom_KeyPress(object sender, KeyPressEventArgs e)
      {
            Char touche = e.KeyChar;
            if (Char.IsLetter(touche) || Char.IsControl(touche))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void buttonEffacer_Click(object sender, EventArgs e)
        {
            textBoxPrenom.Text = "";
            textBoxNom.Text = "";
            textBoxCodePermanent.Text = "";
            comboBoxGroupe.Text = "";
            numericUpDownNote1.Value = 0;
            numericUpDownNote2.Value = 0;
            numericUpDownNote3.Value = 0;
            numericUpDownNote4.Value = 0;
            numericUpDownNote5.Value = 0;
        }

        private void textBoxPrenom_TextChanged(object sender, EventArgs e)
        {
            string texte = textBoxPrenom.Text;
            bool lettre = true;

            foreach (char c in texte)
            {
                if (!char.IsLetter(c))
                {
                    lettre = false;
                }
            }
            if (!lettre || texte == "")
            {
                errorProviderPrenomNom.SetError(textBoxPrenom, Constante.messageErreurPrenom);
                prenomBon = false;
            } else
            {
                errorProviderPrenomNom.Clear();
                prenomBon = true;
            }
        }

        private void textBoxNom_TextChanged(object sender, EventArgs e)
        {
            string texte = textBoxNom.Text;
            bool lettre = true;

            foreach (char c in texte)
            {
                if (!char.IsLetter(c))
                {
                    lettre = false;
                }
            }
            if (!lettre || texte == "")
            {
                errorProviderPrenomNom.SetError(textBoxNom, Constante.messageErreurNom);
                nomBon = false;
            }
            else
            {
                errorProviderPrenomNom.Clear();
                nomBon = true;
            }
        }

        private void textBoxCodePermanent_TextChanged(object sender, EventArgs e)
        {
            string texte = textBoxCodePermanent.Text;
            if (texte.Length == 10) {
                string texte1Et2 = texte.Substring(0, 2);
                string texte3Et4 = texte.Substring(2, 2);
                string texteChiffre = texte.Substring(4, 6);
                string prenomTexte = textBoxPrenom.Text.Substring(0, 2).ToUpper();
                string nomTexte = textBoxNom.Text.Substring(0, 2).ToUpper();
                bool chiffreFin = true;

                foreach (char c in texteChiffre)
                {
                    if (!char.IsDigit(c))
                    {
                        chiffreFin = false;
                    }
                }
                if (texte1Et2 != prenomTexte)
                {
                    errorProviderPrenomNom.SetError(textBoxCodePermanent, Constante.messageErreurCode1);
                    codeBon = false;
                }
                else if (texte3Et4 != nomTexte)
                {
                    errorProviderPrenomNom.SetError(textBoxCodePermanent, Constante.messageErreurCode2);
                    codeBon = false;
                }
                else if (texteChiffre.Length != 6 || !chiffreFin)
                {
                    errorProviderPrenomNom.SetError(textBoxCodePermanent, Constante.messageErreurCode3);
                    codeBon = false;
                }
                else
                {
                    errorProviderPrenomNom.Clear();
                    codeBon = true;
                }
            }
            else
            {
                errorProviderPrenomNom.SetError(textBoxCodePermanent, Constante.messageErreurCode4);
                codeBon = false;
            }
        }
        int numEtu = 0;
        private void buttonSauvegarder_Click(object sender, EventArgs e)
        {
            if (numEtu < 10)
            {
                if (prenomBon && nomBon && codeBon && comboBoxGroupe.Text != "")
                {
                    string[] matiere = { textBoxCours1.Text, textBoxCours2.Text, textBoxCours3.Text, textBoxCours4.Text, textBoxCours5.Text };
                    int[] note = { (int)numericUpDownNote1.Value, (int)numericUpDownNote2.Value, (int)numericUpDownNote3.Value, (int)numericUpDownNote4.Value, (int)numericUpDownNote5.Value };
                    tabEtudiant[numEtu] = new Etudiant(numEtu + 1, textBoxPrenom.Text, textBoxNom.Text, textBoxCodePermanent.Text, comboBoxGroupe.Text, matiere, note);
                    MessageBox.Show(Constante.messageSauvegarder);
                    numEtu++;
                } else
                {
                    MessageBox.Show(Constante.messageNonSauvegarder);
                }
            } else
            {
                MessageBox.Show(Constante.messageTropEtudiant);
            }
                
        }

        private void comboBoxGroupeNote_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxEtudiant.Items.Clear();
            if(comboBoxGroupeNote.Text == "Groupe 50")
            {
                for (int i = 0; i < numEtu; i++)
                {
                    if (tabEtudiant[i].groupe == "Groupe 50") 
                    { 
                         listBoxEtudiant.Items.Add(tabEtudiant[i]);
                    }
                }
            } else if (comboBoxGroupeNote.Text == "Groupe 51"){
                for (int i = 0; i < numEtu; i++)
                {
                    if (tabEtudiant[i].groupe == "Groupe 51")
                    {
                        listBoxEtudiant.Items.Add(tabEtudiant[i]);
                    }
                }
            }
        }

        private void listBoxEtudiant_SelectedIndexChanged(object sender, EventArgs e)
        {
            Etudiant etu = (Etudiant) listBoxEtudiant.SelectedItem;
            if (etu != null) {
                textBoxNote1.Text = etu.note[0].ToString();
                textBoxNote2.Text = etu.note[1].ToString();
                textBoxNote3.Text = etu.note[2].ToString();
                textBoxNote4.Text = etu.note[3].ToString();
                textBoxNote5.Text = etu.note[4].ToString();
                int somme1 = 0;
                int somme2 = 0;
                int somme3 = 0;
                int somme4 = 0;
                int somme5 = 0;
                int nombreGroupe = 0;
                for (int i = 0; i < numEtu; i++)
                {
                    if (etu.groupe == tabEtudiant[i].groupe)
                    {
                        somme1 += tabEtudiant[i].note[0];
                        somme2 += tabEtudiant[i].note[1];
                        somme3 += tabEtudiant[i].note[2];
                        somme4 += tabEtudiant[i].note[3];
                        somme5 += tabEtudiant[i].note[4];
                        nombreGroupe++;
                    }
                }
                textBoxMoyenne1.Text = Math.Round((double)somme1 / nombreGroupe, 1).ToString() + "%";
                textBoxMoyenne2.Text = Math.Round((double)somme2 / nombreGroupe, 1).ToString() + "%";
                textBoxMoyenne3.Text = Math.Round((double)somme3 / nombreGroupe, 1).ToString() + "%";
                textBoxMoyenne4.Text = Math.Round((double)somme4 / nombreGroupe, 1).ToString() + "%";
                textBoxMoyenne5.Text = Math.Round((double)somme5 / nombreGroupe, 1).ToString() + "%";
                double moyenne = Math.Round((etu.note[0] + etu.note[1] + etu.note[2] + etu.note[3] + etu.note[4]) / 5.0, 1);
                textBoxMoyenneGenerale.Text = (moyenne).ToString() + "%";
                if (moyenne <= 60)
                {
                    textBoxMoyenneGenerale.BackColor = Color.Pink;
                    //Rouge pâle
                } else
                {
                    textBoxMoyenneGenerale.BackColor = Color.LightGreen;
                    //Vert pâle
                }

            } else
            {
                /*Empeche les erreurs lorsqu'on séléctionne pas d'étu
                après un changement de groupe et supprime les entrèes à la place*/
                textBoxNote1.Text = "";
                textBoxNote2.Text = "";
                textBoxNote3.Text = "";
                textBoxNote4.Text = "";
                textBoxNote5.Text = "";
                textBoxMoyenneGenerale.Text = "";
                textBoxMoyenne1.Text = "";
                textBoxMoyenne2.Text = "";
                textBoxMoyenne3.Text = "";
                textBoxMoyenne4.Text = "";
                textBoxMoyenne5.Text = "";
            }
        }

        private void buttonSupprimer_Click(object sender, EventArgs e)
        {
            DialogResult resultat;
            resultat = MessageBox.Show("Voulez-vous supprimer l'étudiant",
              "Confirmation",
               MessageBoxButtons.OKCancel,
               MessageBoxIcon.Question);
            if (resultat == DialogResult.OK)
            {
                textBoxNote1.Text = "";
                textBoxNote2.Text = "";
                textBoxNote3.Text = "";
                textBoxNote4.Text = "";
                textBoxNote5.Text = "";
                textBoxMoyenneGenerale.Text = "";
                textBoxMoyenneGenerale.BackColor = SystemColors.Window;
                if (listBoxEtudiant.SelectedItem != null)
                {
                    Etudiant[] nouvTabEtudiant = new Etudiant[Constante.maximum];
                    int index = -1;
                    for (int i = 0; i < numEtu; i++)
                    {
                        string texte = (tabEtudiant[i].prenom + " " + tabEtudiant[i].nom);
                        if (texte.Equals(listBoxEtudiant.Text))
                        {
                            index = i;
                        }
                    }
                    int j = 0;
                    for (int i = 0; i < numEtu; i++)
                    {
                        if (i != index)
                        {
                            nouvTabEtudiant[j] = tabEtudiant[i];
                            j++;
                        }
                    }
                    tabEtudiant = nouvTabEtudiant;
                    listBoxEtudiant.Items.Remove(listBoxEtudiant.SelectedItem);
                    numEtu--;
                }
            }
        }
    }
}