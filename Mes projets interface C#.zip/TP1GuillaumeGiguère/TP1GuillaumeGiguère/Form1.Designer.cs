﻿namespace TP1GuillaumeGiguère
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControlOnglet = new System.Windows.Forms.TabControl();
            this.tabPageAccueil = new System.Windows.Forms.TabPage();
            this.labelGestion = new System.Windows.Forms.Label();
            this.pictureBoxAccueil = new System.Windows.Forms.PictureBox();
            this.tabPageDossier = new System.Windows.Forms.TabPage();
            this.pictureBoxDossier = new System.Windows.Forms.PictureBox();
            this.numericUpDownNote5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNote4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNote3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNote2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNote1 = new System.Windows.Forms.NumericUpDown();
            this.textBoxMatiere5 = new System.Windows.Forms.TextBox();
            this.textBoxMatiere4 = new System.Windows.Forms.TextBox();
            this.textBoxMatiere3 = new System.Windows.Forms.TextBox();
            this.textBoxMatiere2 = new System.Windows.Forms.TextBox();
            this.comboBoxGroupe = new System.Windows.Forms.ComboBox();
            this.textBoxMatiere1 = new System.Windows.Forms.TextBox();
            this.textBoxCodePermanent = new System.Windows.Forms.TextBox();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxPrenom = new System.Windows.Forms.TextBox();
            this.buttonEffacer = new System.Windows.Forms.Button();
            this.buttonSauvegarder = new System.Windows.Forms.Button();
            this.labelResultat = new System.Windows.Forms.Label();
            this.labelMatière = new System.Windows.Forms.Label();
            this.labelGroupe = new System.Windows.Forms.Label();
            this.labelCode = new System.Windows.Forms.Label();
            this.labelNom = new System.Windows.Forms.Label();
            this.labelPrénom = new System.Windows.Forms.Label();
            this.labelDossier = new System.Windows.Forms.Label();
            this.tabPageCahierDeNotes = new System.Windows.Forms.TabPage();
            this.textBoxMoyenneGenerale = new System.Windows.Forms.TextBox();
            this.labelMoyenneGeneral = new System.Windows.Forms.Label();
            this.textBoxMoyenne5 = new System.Windows.Forms.TextBox();
            this.textBoxMoyenne4 = new System.Windows.Forms.TextBox();
            this.textBoxMoyenne3 = new System.Windows.Forms.TextBox();
            this.textBoxNote5 = new System.Windows.Forms.TextBox();
            this.textBoxNote4 = new System.Windows.Forms.TextBox();
            this.textBoxNote3 = new System.Windows.Forms.TextBox();
            this.textBoxMoyenne2 = new System.Windows.Forms.TextBox();
            this.textBoxMoyenne1 = new System.Windows.Forms.TextBox();
            this.textBoxNote2 = new System.Windows.Forms.TextBox();
            this.textBoxNote1 = new System.Windows.Forms.TextBox();
            this.textBoxCours5 = new System.Windows.Forms.TextBox();
            this.textBoxCours4 = new System.Windows.Forms.TextBox();
            this.textBoxCours3 = new System.Windows.Forms.TextBox();
            this.textBoxCours2 = new System.Windows.Forms.TextBox();
            this.textBoxCours1 = new System.Windows.Forms.TextBox();
            this.labelMoyenne = new System.Windows.Forms.Label();
            this.labelNote = new System.Windows.Forms.Label();
            this.labelCours = new System.Windows.Forms.Label();
            this.buttonSupprimer = new System.Windows.Forms.Button();
            this.pictureBoxCahier = new System.Windows.Forms.PictureBox();
            this.listBoxEtudiant = new System.Windows.Forms.ListBox();
            this.comboBoxGroupeNote = new System.Windows.Forms.ComboBox();
            this.buttonQuitter = new System.Windows.Forms.Button();
            this.errorProviderPrenomNom = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderCodePermanent = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabControlOnglet.SuspendLayout();
            this.tabPageAccueil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAccueil)).BeginInit();
            this.tabPageDossier.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDossier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote1)).BeginInit();
            this.tabPageCahierDeNotes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCahier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderPrenomNom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCodePermanent)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlOnglet
            // 
            this.tabControlOnglet.Controls.Add(this.tabPageAccueil);
            this.tabControlOnglet.Controls.Add(this.tabPageDossier);
            this.tabControlOnglet.Controls.Add(this.tabPageCahierDeNotes);
            this.tabControlOnglet.Location = new System.Drawing.Point(12, 12);
            this.tabControlOnglet.Name = "tabControlOnglet";
            this.tabControlOnglet.SelectedIndex = 0;
            this.tabControlOnglet.Size = new System.Drawing.Size(827, 485);
            this.tabControlOnglet.TabIndex = 0;
            // 
            // tabPageAccueil
            // 
            this.tabPageAccueil.Controls.Add(this.labelGestion);
            this.tabPageAccueil.Controls.Add(this.pictureBoxAccueil);
            this.tabPageAccueil.Location = new System.Drawing.Point(4, 34);
            this.tabPageAccueil.Name = "tabPageAccueil";
            this.tabPageAccueil.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAccueil.Size = new System.Drawing.Size(819, 447);
            this.tabPageAccueil.TabIndex = 0;
            this.tabPageAccueil.Text = "Accueil";
            this.tabPageAccueil.UseVisualStyleBackColor = true;
            // 
            // labelGestion
            // 
            this.labelGestion.AutoSize = true;
            this.labelGestion.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelGestion.Location = new System.Drawing.Point(296, 257);
            this.labelGestion.Name = "labelGestion";
            this.labelGestion.Size = new System.Drawing.Size(220, 30);
            this.labelGestion.TabIndex = 1;
            this.labelGestion.Text = "Gestion des étudiants";
            // 
            // pictureBoxAccueil
            // 
            this.pictureBoxAccueil.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAccueil.Image")));
            this.pictureBoxAccueil.Location = new System.Drawing.Point(20, 33);
            this.pictureBoxAccueil.Name = "pictureBoxAccueil";
            this.pictureBoxAccueil.Size = new System.Drawing.Size(780, 221);
            this.pictureBoxAccueil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAccueil.TabIndex = 0;
            this.pictureBoxAccueil.TabStop = false;
            // 
            // tabPageDossier
            // 
            this.tabPageDossier.Controls.Add(this.pictureBoxDossier);
            this.tabPageDossier.Controls.Add(this.numericUpDownNote5);
            this.tabPageDossier.Controls.Add(this.numericUpDownNote4);
            this.tabPageDossier.Controls.Add(this.numericUpDownNote3);
            this.tabPageDossier.Controls.Add(this.numericUpDownNote2);
            this.tabPageDossier.Controls.Add(this.numericUpDownNote1);
            this.tabPageDossier.Controls.Add(this.textBoxMatiere5);
            this.tabPageDossier.Controls.Add(this.textBoxMatiere4);
            this.tabPageDossier.Controls.Add(this.textBoxMatiere3);
            this.tabPageDossier.Controls.Add(this.textBoxMatiere2);
            this.tabPageDossier.Controls.Add(this.comboBoxGroupe);
            this.tabPageDossier.Controls.Add(this.textBoxMatiere1);
            this.tabPageDossier.Controls.Add(this.textBoxCodePermanent);
            this.tabPageDossier.Controls.Add(this.textBoxNom);
            this.tabPageDossier.Controls.Add(this.textBoxPrenom);
            this.tabPageDossier.Controls.Add(this.buttonEffacer);
            this.tabPageDossier.Controls.Add(this.buttonSauvegarder);
            this.tabPageDossier.Controls.Add(this.labelResultat);
            this.tabPageDossier.Controls.Add(this.labelMatière);
            this.tabPageDossier.Controls.Add(this.labelGroupe);
            this.tabPageDossier.Controls.Add(this.labelCode);
            this.tabPageDossier.Controls.Add(this.labelNom);
            this.tabPageDossier.Controls.Add(this.labelPrénom);
            this.tabPageDossier.Controls.Add(this.labelDossier);
            this.tabPageDossier.Location = new System.Drawing.Point(4, 34);
            this.tabPageDossier.Name = "tabPageDossier";
            this.tabPageDossier.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDossier.Size = new System.Drawing.Size(819, 447);
            this.tabPageDossier.TabIndex = 1;
            this.tabPageDossier.Text = "Dossier";
            this.tabPageDossier.UseVisualStyleBackColor = true;
            // 
            // pictureBoxDossier
            // 
            this.pictureBoxDossier.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxDossier.Image")));
            this.pictureBoxDossier.Location = new System.Drawing.Point(442, 14);
            this.pictureBoxDossier.Name = "pictureBoxDossier";
            this.pictureBoxDossier.Size = new System.Drawing.Size(363, 361);
            this.pictureBoxDossier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDossier.TabIndex = 24;
            this.pictureBoxDossier.TabStop = false;
            // 
            // numericUpDownNote5
            // 
            this.numericUpDownNote5.Location = new System.Drawing.Point(299, 398);
            this.numericUpDownNote5.Name = "numericUpDownNote5";
            this.numericUpDownNote5.Size = new System.Drawing.Size(97, 31);
            this.numericUpDownNote5.TabIndex = 100;
            // 
            // numericUpDownNote4
            // 
            this.numericUpDownNote4.Location = new System.Drawing.Point(299, 361);
            this.numericUpDownNote4.Name = "numericUpDownNote4";
            this.numericUpDownNote4.Size = new System.Drawing.Size(97, 31);
            this.numericUpDownNote4.TabIndex = 90;
            // 
            // numericUpDownNote3
            // 
            this.numericUpDownNote3.Location = new System.Drawing.Point(299, 324);
            this.numericUpDownNote3.Name = "numericUpDownNote3";
            this.numericUpDownNote3.Size = new System.Drawing.Size(97, 31);
            this.numericUpDownNote3.TabIndex = 80;
            // 
            // numericUpDownNote2
            // 
            this.numericUpDownNote2.Location = new System.Drawing.Point(299, 287);
            this.numericUpDownNote2.Name = "numericUpDownNote2";
            this.numericUpDownNote2.Size = new System.Drawing.Size(97, 31);
            this.numericUpDownNote2.TabIndex = 70;
            // 
            // numericUpDownNote1
            // 
            this.numericUpDownNote1.Location = new System.Drawing.Point(299, 250);
            this.numericUpDownNote1.Name = "numericUpDownNote1";
            this.numericUpDownNote1.Size = new System.Drawing.Size(97, 31);
            this.numericUpDownNote1.TabIndex = 60;
            // 
            // textBoxMatiere5
            // 
            this.textBoxMatiere5.Enabled = false;
            this.textBoxMatiere5.Location = new System.Drawing.Point(16, 398);
            this.textBoxMatiere5.Name = "textBoxMatiere5";
            this.textBoxMatiere5.Size = new System.Drawing.Size(277, 31);
            this.textBoxMatiere5.TabIndex = 95;
            this.textBoxMatiere5.Text = "Structure de données";
            // 
            // textBoxMatiere4
            // 
            this.textBoxMatiere4.Enabled = false;
            this.textBoxMatiere4.Location = new System.Drawing.Point(16, 361);
            this.textBoxMatiere4.Name = "textBoxMatiere4";
            this.textBoxMatiere4.Size = new System.Drawing.Size(277, 31);
            this.textBoxMatiere4.TabIndex = 85;
            this.textBoxMatiere4.Text = "Sécurité et éthique";
            // 
            // textBoxMatiere3
            // 
            this.textBoxMatiere3.Enabled = false;
            this.textBoxMatiere3.Location = new System.Drawing.Point(16, 324);
            this.textBoxMatiere3.Name = "textBoxMatiere3";
            this.textBoxMatiere3.Size = new System.Drawing.Size(277, 31);
            this.textBoxMatiere3.TabIndex = 75;
            this.textBoxMatiere3.Text = "Interface Web";
            // 
            // textBoxMatiere2
            // 
            this.textBoxMatiere2.Enabled = false;
            this.textBoxMatiere2.Location = new System.Drawing.Point(16, 287);
            this.textBoxMatiere2.Name = "textBoxMatiere2";
            this.textBoxMatiere2.Size = new System.Drawing.Size(277, 31);
            this.textBoxMatiere2.TabIndex = 65;
            this.textBoxMatiere2.Text = "Interface utilisateur";
            // 
            // comboBoxGroupe
            // 
            this.comboBoxGroupe.FormattingEnabled = true;
            this.comboBoxGroupe.Items.AddRange(new object[] {
            "Groupe 50",
            "Groupe 51"});
            this.comboBoxGroupe.Location = new System.Drawing.Point(190, 162);
            this.comboBoxGroupe.Name = "comboBoxGroupe";
            this.comboBoxGroupe.Size = new System.Drawing.Size(206, 33);
            this.comboBoxGroupe.TabIndex = 40;
            // 
            // textBoxMatiere1
            // 
            this.textBoxMatiere1.Enabled = false;
            this.textBoxMatiere1.Location = new System.Drawing.Point(16, 250);
            this.textBoxMatiere1.Name = "textBoxMatiere1";
            this.textBoxMatiere1.Size = new System.Drawing.Size(277, 31);
            this.textBoxMatiere1.TabIndex = 55;
            this.textBoxMatiere1.Text = "Bases de données";
            // 
            // textBoxCodePermanent
            // 
            this.textBoxCodePermanent.Location = new System.Drawing.Point(190, 125);
            this.textBoxCodePermanent.Name = "textBoxCodePermanent";
            this.textBoxCodePermanent.Size = new System.Drawing.Size(206, 31);
            this.textBoxCodePermanent.TabIndex = 30;
            this.textBoxCodePermanent.TextChanged += new System.EventHandler(this.textBoxCodePermanent_TextChanged);
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(190, 88);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(206, 31);
            this.textBoxNom.TabIndex = 20;
            this.textBoxNom.TextChanged += new System.EventHandler(this.textBoxNom_TextChanged);
            this.textBoxNom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxNom_KeyPress);
            // 
            // textBoxPrenom
            // 
            this.textBoxPrenom.Location = new System.Drawing.Point(190, 51);
            this.textBoxPrenom.Name = "textBoxPrenom";
            this.textBoxPrenom.Size = new System.Drawing.Size(206, 31);
            this.textBoxPrenom.TabIndex = 10;
            this.textBoxPrenom.TextChanged += new System.EventHandler(this.textBoxPrenom_TextChanged);
            this.textBoxPrenom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPrenom_KeyPress);
            // 
            // buttonEffacer
            // 
            this.buttonEffacer.Location = new System.Drawing.Point(652, 381);
            this.buttonEffacer.Name = "buttonEffacer";
            this.buttonEffacer.Size = new System.Drawing.Size(153, 48);
            this.buttonEffacer.TabIndex = 110;
            this.buttonEffacer.Text = "Effacer";
            this.buttonEffacer.UseVisualStyleBackColor = true;
            this.buttonEffacer.Click += new System.EventHandler(this.buttonEffacer_Click);
            // 
            // buttonSauvegarder
            // 
            this.buttonSauvegarder.Location = new System.Drawing.Point(442, 381);
            this.buttonSauvegarder.Name = "buttonSauvegarder";
            this.buttonSauvegarder.Size = new System.Drawing.Size(153, 48);
            this.buttonSauvegarder.TabIndex = 105;
            this.buttonSauvegarder.Text = "Sauvegarder";
            this.buttonSauvegarder.UseVisualStyleBackColor = true;
            this.buttonSauvegarder.Click += new System.EventHandler(this.buttonSauvegarder_Click);
            // 
            // labelResultat
            // 
            this.labelResultat.AutoSize = true;
            this.labelResultat.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelResultat.Location = new System.Drawing.Point(299, 217);
            this.labelResultat.Name = "labelResultat";
            this.labelResultat.Size = new System.Drawing.Size(97, 30);
            this.labelResultat.TabIndex = 50;
            this.labelResultat.Text = "Résultat";
            // 
            // labelMatière
            // 
            this.labelMatière.AutoSize = true;
            this.labelMatière.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelMatière.Location = new System.Drawing.Point(16, 217);
            this.labelMatière.Name = "labelMatière";
            this.labelMatière.Size = new System.Drawing.Size(94, 30);
            this.labelMatière.TabIndex = 45;
            this.labelMatière.Text = "Matière";
            // 
            // labelGroupe
            // 
            this.labelGroupe.AutoSize = true;
            this.labelGroupe.Location = new System.Drawing.Point(16, 165);
            this.labelGroupe.Name = "labelGroupe";
            this.labelGroupe.Size = new System.Drawing.Size(75, 25);
            this.labelGroupe.TabIndex = 35;
            this.labelGroupe.Text = "Groupe:";
            // 
            // labelCode
            // 
            this.labelCode.AutoSize = true;
            this.labelCode.Location = new System.Drawing.Point(16, 128);
            this.labelCode.Name = "labelCode";
            this.labelCode.Size = new System.Drawing.Size(147, 25);
            this.labelCode.TabIndex = 25;
            this.labelCode.Text = "Code Permanent:";
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.Location = new System.Drawing.Point(16, 91);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(61, 25);
            this.labelNom.TabIndex = 15;
            this.labelNom.Text = "Nom :";
            // 
            // labelPrénom
            // 
            this.labelPrénom.AutoSize = true;
            this.labelPrénom.Location = new System.Drawing.Point(16, 54);
            this.labelPrénom.Name = "labelPrénom";
            this.labelPrénom.Size = new System.Drawing.Size(83, 25);
            this.labelPrénom.TabIndex = 5;
            this.labelPrénom.Text = "Prénom :";
            // 
            // labelDossier
            // 
            this.labelDossier.AutoSize = true;
            this.labelDossier.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelDossier.Location = new System.Drawing.Point(16, 14);
            this.labelDossier.Name = "labelDossier";
            this.labelDossier.Size = new System.Drawing.Size(227, 30);
            this.labelDossier.TabIndex = 1;
            this.labelDossier.Text = "Dossier de l\'étudiant";
            // 
            // tabPageCahierDeNotes
            // 
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenneGenerale);
            this.tabPageCahierDeNotes.Controls.Add(this.labelMoyenneGeneral);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenne5);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenne4);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenne3);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxNote5);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxNote4);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxNote3);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenne2);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxMoyenne1);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxNote2);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxNote1);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxCours5);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxCours4);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxCours3);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxCours2);
            this.tabPageCahierDeNotes.Controls.Add(this.textBoxCours1);
            this.tabPageCahierDeNotes.Controls.Add(this.labelMoyenne);
            this.tabPageCahierDeNotes.Controls.Add(this.labelNote);
            this.tabPageCahierDeNotes.Controls.Add(this.labelCours);
            this.tabPageCahierDeNotes.Controls.Add(this.buttonSupprimer);
            this.tabPageCahierDeNotes.Controls.Add(this.pictureBoxCahier);
            this.tabPageCahierDeNotes.Controls.Add(this.listBoxEtudiant);
            this.tabPageCahierDeNotes.Controls.Add(this.comboBoxGroupeNote);
            this.tabPageCahierDeNotes.Location = new System.Drawing.Point(4, 34);
            this.tabPageCahierDeNotes.Name = "tabPageCahierDeNotes";
            this.tabPageCahierDeNotes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCahierDeNotes.Size = new System.Drawing.Size(819, 447);
            this.tabPageCahierDeNotes.TabIndex = 2;
            this.tabPageCahierDeNotes.Text = "Cahier de notes";
            this.tabPageCahierDeNotes.UseVisualStyleBackColor = true;
            // 
            // textBoxMoyenneGenerale
            // 
            this.textBoxMoyenneGenerale.Enabled = false;
            this.textBoxMoyenneGenerale.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxMoyenneGenerale.Location = new System.Drawing.Point(474, 410);
            this.textBoxMoyenneGenerale.Name = "textBoxMoyenneGenerale";
            this.textBoxMoyenneGenerale.Size = new System.Drawing.Size(129, 32);
            this.textBoxMoyenneGenerale.TabIndex = 110;
            // 
            // labelMoyenneGeneral
            // 
            this.labelMoyenneGeneral.AutoSize = true;
            this.labelMoyenneGeneral.Location = new System.Drawing.Point(303, 413);
            this.labelMoyenneGeneral.Name = "labelMoyenneGeneral";
            this.labelMoyenneGeneral.Size = new System.Drawing.Size(158, 25);
            this.labelMoyenneGeneral.TabIndex = 105;
            this.labelMoyenneGeneral.Text = "Moyenne gérérale:";
            // 
            // textBoxMoyenne5
            // 
            this.textBoxMoyenne5.Enabled = false;
            this.textBoxMoyenne5.Location = new System.Drawing.Point(643, 369);
            this.textBoxMoyenne5.Name = "textBoxMoyenne5";
            this.textBoxMoyenne5.Size = new System.Drawing.Size(129, 31);
            this.textBoxMoyenne5.TabIndex = 100;
            // 
            // textBoxMoyenne4
            // 
            this.textBoxMoyenne4.Enabled = false;
            this.textBoxMoyenne4.Location = new System.Drawing.Point(643, 332);
            this.textBoxMoyenne4.Name = "textBoxMoyenne4";
            this.textBoxMoyenne4.Size = new System.Drawing.Size(129, 31);
            this.textBoxMoyenne4.TabIndex = 85;
            // 
            // textBoxMoyenne3
            // 
            this.textBoxMoyenne3.Enabled = false;
            this.textBoxMoyenne3.Location = new System.Drawing.Point(643, 295);
            this.textBoxMoyenne3.Name = "textBoxMoyenne3";
            this.textBoxMoyenne3.Size = new System.Drawing.Size(129, 31);
            this.textBoxMoyenne3.TabIndex = 70;
            // 
            // textBoxNote5
            // 
            this.textBoxNote5.Enabled = false;
            this.textBoxNote5.Location = new System.Drawing.Point(474, 369);
            this.textBoxNote5.Name = "textBoxNote5";
            this.textBoxNote5.Size = new System.Drawing.Size(129, 31);
            this.textBoxNote5.TabIndex = 95;
            // 
            // textBoxNote4
            // 
            this.textBoxNote4.Enabled = false;
            this.textBoxNote4.Location = new System.Drawing.Point(474, 332);
            this.textBoxNote4.Name = "textBoxNote4";
            this.textBoxNote4.Size = new System.Drawing.Size(129, 31);
            this.textBoxNote4.TabIndex = 80;
            // 
            // textBoxNote3
            // 
            this.textBoxNote3.Enabled = false;
            this.textBoxNote3.Location = new System.Drawing.Point(474, 295);
            this.textBoxNote3.Name = "textBoxNote3";
            this.textBoxNote3.Size = new System.Drawing.Size(129, 31);
            this.textBoxNote3.TabIndex = 65;
            // 
            // textBoxMoyenne2
            // 
            this.textBoxMoyenne2.Enabled = false;
            this.textBoxMoyenne2.Location = new System.Drawing.Point(643, 258);
            this.textBoxMoyenne2.Name = "textBoxMoyenne2";
            this.textBoxMoyenne2.Size = new System.Drawing.Size(129, 31);
            this.textBoxMoyenne2.TabIndex = 55;
            // 
            // textBoxMoyenne1
            // 
            this.textBoxMoyenne1.Enabled = false;
            this.textBoxMoyenne1.Location = new System.Drawing.Point(643, 221);
            this.textBoxMoyenne1.Name = "textBoxMoyenne1";
            this.textBoxMoyenne1.Size = new System.Drawing.Size(129, 31);
            this.textBoxMoyenne1.TabIndex = 40;
            // 
            // textBoxNote2
            // 
            this.textBoxNote2.Enabled = false;
            this.textBoxNote2.Location = new System.Drawing.Point(474, 258);
            this.textBoxNote2.Name = "textBoxNote2";
            this.textBoxNote2.Size = new System.Drawing.Size(129, 31);
            this.textBoxNote2.TabIndex = 50;
            // 
            // textBoxNote1
            // 
            this.textBoxNote1.Enabled = false;
            this.textBoxNote1.Location = new System.Drawing.Point(474, 221);
            this.textBoxNote1.Name = "textBoxNote1";
            this.textBoxNote1.Size = new System.Drawing.Size(129, 31);
            this.textBoxNote1.TabIndex = 35;
            // 
            // textBoxCours5
            // 
            this.textBoxCours5.Enabled = false;
            this.textBoxCours5.Location = new System.Drawing.Point(20, 369);
            this.textBoxCours5.Name = "textBoxCours5";
            this.textBoxCours5.Size = new System.Drawing.Size(441, 31);
            this.textBoxCours5.TabIndex = 90;
            this.textBoxCours5.Text = "Structure de données";
            // 
            // textBoxCours4
            // 
            this.textBoxCours4.Enabled = false;
            this.textBoxCours4.Location = new System.Drawing.Point(20, 332);
            this.textBoxCours4.Name = "textBoxCours4";
            this.textBoxCours4.Size = new System.Drawing.Size(441, 31);
            this.textBoxCours4.TabIndex = 75;
            this.textBoxCours4.Text = "Sécurité et éthique";
            // 
            // textBoxCours3
            // 
            this.textBoxCours3.Enabled = false;
            this.textBoxCours3.Location = new System.Drawing.Point(20, 295);
            this.textBoxCours3.Name = "textBoxCours3";
            this.textBoxCours3.Size = new System.Drawing.Size(441, 31);
            this.textBoxCours3.TabIndex = 60;
            this.textBoxCours3.Text = "Interface Web";
            // 
            // textBoxCours2
            // 
            this.textBoxCours2.Enabled = false;
            this.textBoxCours2.Location = new System.Drawing.Point(20, 258);
            this.textBoxCours2.Name = "textBoxCours2";
            this.textBoxCours2.Size = new System.Drawing.Size(441, 31);
            this.textBoxCours2.TabIndex = 45;
            this.textBoxCours2.Text = "Interface utilisateur";
            // 
            // textBoxCours1
            // 
            this.textBoxCours1.Enabled = false;
            this.textBoxCours1.Location = new System.Drawing.Point(20, 221);
            this.textBoxCours1.Name = "textBoxCours1";
            this.textBoxCours1.Size = new System.Drawing.Size(441, 31);
            this.textBoxCours1.TabIndex = 30;
            this.textBoxCours1.Text = "Bases de données";
            // 
            // labelMoyenne
            // 
            this.labelMoyenne.AutoSize = true;
            this.labelMoyenne.Location = new System.Drawing.Point(666, 193);
            this.labelMoyenne.Name = "labelMoyenne";
            this.labelMoyenne.Size = new System.Drawing.Size(86, 25);
            this.labelMoyenne.TabIndex = 25;
            this.labelMoyenne.Text = "Moyenne";
            // 
            // labelNote
            // 
            this.labelNote.AutoSize = true;
            this.labelNote.Location = new System.Drawing.Point(512, 193);
            this.labelNote.Name = "labelNote";
            this.labelNote.Size = new System.Drawing.Size(51, 25);
            this.labelNote.TabIndex = 20;
            this.labelNote.Text = "Note";
            // 
            // labelCours
            // 
            this.labelCours.AutoSize = true;
            this.labelCours.Location = new System.Drawing.Point(20, 193);
            this.labelCours.Name = "labelCours";
            this.labelCours.Size = new System.Drawing.Size(58, 25);
            this.labelCours.TabIndex = 15;
            this.labelCours.Text = "Cours";
            // 
            // buttonSupprimer
            // 
            this.buttonSupprimer.Location = new System.Drawing.Point(354, 139);
            this.buttonSupprimer.Name = "buttonSupprimer";
            this.buttonSupprimer.Size = new System.Drawing.Size(449, 44);
            this.buttonSupprimer.TabIndex = 10;
            this.buttonSupprimer.Text = "Supprimer l\'étudiant sélectionné";
            this.buttonSupprimer.UseVisualStyleBackColor = true;
            this.buttonSupprimer.Click += new System.EventHandler(this.buttonSupprimer_Click);
            // 
            // pictureBoxCahier
            // 
            this.pictureBoxCahier.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCahier.Image")));
            this.pictureBoxCahier.Location = new System.Drawing.Point(3, 0);
            this.pictureBoxCahier.Name = "pictureBoxCahier";
            this.pictureBoxCahier.Size = new System.Drawing.Size(180, 183);
            this.pictureBoxCahier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCahier.TabIndex = 2;
            this.pictureBoxCahier.TabStop = false;
            // 
            // listBoxEtudiant
            // 
            this.listBoxEtudiant.FormattingEnabled = true;
            this.listBoxEtudiant.ItemHeight = 25;
            this.listBoxEtudiant.Location = new System.Drawing.Point(354, 54);
            this.listBoxEtudiant.Name = "listBoxEtudiant";
            this.listBoxEtudiant.Size = new System.Drawing.Size(449, 79);
            this.listBoxEtudiant.TabIndex = 5;
            this.listBoxEtudiant.SelectedIndexChanged += new System.EventHandler(this.listBoxEtudiant_SelectedIndexChanged);
            // 
            // comboBoxGroupeNote
            // 
            this.comboBoxGroupeNote.FormattingEnabled = true;
            this.comboBoxGroupeNote.Items.AddRange(new object[] {
            "Groupe 50",
            "Groupe 51"});
            this.comboBoxGroupeNote.Location = new System.Drawing.Point(354, 15);
            this.comboBoxGroupeNote.Name = "comboBoxGroupeNote";
            this.comboBoxGroupeNote.Size = new System.Drawing.Size(449, 33);
            this.comboBoxGroupeNote.TabIndex = 1;
            this.comboBoxGroupeNote.SelectedIndexChanged += new System.EventHandler(this.comboBoxGroupeNote_SelectedIndexChanged);
            // 
            // buttonQuitter
            // 
            this.buttonQuitter.Location = new System.Drawing.Point(659, 503);
            this.buttonQuitter.Name = "buttonQuitter";
            this.buttonQuitter.Size = new System.Drawing.Size(176, 56);
            this.buttonQuitter.TabIndex = 0;
            this.buttonQuitter.Text = "Quitter";
            this.buttonQuitter.UseVisualStyleBackColor = true;
            this.buttonQuitter.Click += new System.EventHandler(this.buttonQuitter_Click);
            // 
            // errorProviderPrenomNom
            // 
            this.errorProviderPrenomNom.ContainerControl = this;
            // 
            // errorProviderCodePermanent
            // 
            this.errorProviderCodePermanent.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 566);
            this.Controls.Add(this.buttonQuitter);
            this.Controls.Add(this.tabControlOnglet);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Collège de Guillaume Giguère";
            this.tabControlOnglet.ResumeLayout(false);
            this.tabPageAccueil.ResumeLayout(false);
            this.tabPageAccueil.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAccueil)).EndInit();
            this.tabPageDossier.ResumeLayout(false);
            this.tabPageDossier.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDossier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNote1)).EndInit();
            this.tabPageCahierDeNotes.ResumeLayout(false);
            this.tabPageCahierDeNotes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCahier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderPrenomNom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCodePermanent)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControlOnglet;
        private TabPage tabPageAccueil;
        private Label labelGestion;
        private PictureBox pictureBoxAccueil;
        private TabPage tabPageDossier;
        private TabPage tabPageCahierDeNotes;
        private Button buttonQuitter;
        private PictureBox pictureBoxDossier;
        private NumericUpDown numericUpDownNote5;
        private NumericUpDown numericUpDownNote4;
        private NumericUpDown numericUpDownNote3;
        private NumericUpDown numericUpDownNote2;
        private NumericUpDown numericUpDownNote1;
        private TextBox textBoxMatiere5;
        private TextBox textBoxMatiere4;
        private TextBox textBoxMatiere3;
        private TextBox textBoxMatiere2;
        private ComboBox comboBoxGroupe;
        private TextBox textBoxMatiere1;
        private TextBox textBoxCodePermanent;
        private TextBox textBoxNom;
        private TextBox textBoxPrenom;
        private Button buttonEffacer;
        private Button buttonSauvegarder;
        private Label labelResultat;
        private Label labelMatière;
        private Label labelGroupe;
        private Label labelCode;
        private Label labelNom;
        private Label labelPrénom;
        private Label labelDossier;
        private TextBox textBoxMoyenneGenerale;
        private Label labelMoyenneGeneral;
        private TextBox textBoxMoyenne5;
        private TextBox textBoxMoyenne4;
        private TextBox textBoxMoyenne3;
        private TextBox textBoxNote5;
        private TextBox textBoxNote4;
        private TextBox textBoxNote3;
        private TextBox textBoxMoyenne2;
        private TextBox textBoxMoyenne1;
        private TextBox textBoxNote2;
        private TextBox textBoxNote1;
        private TextBox textBoxCours5;
        private TextBox textBoxCours4;
        private TextBox textBoxCours3;
        private TextBox textBoxCours2;
        private TextBox textBoxCours1;
        private Label labelMoyenne;
        private Label labelNote;
        private Label labelCours;
        private Button buttonSupprimer;
        private PictureBox pictureBoxCahier;
        private ListBox listBoxEtudiant;
        private ComboBox comboBoxGroupeNote;
        private ErrorProvider errorProviderPrenomNom;
        private ErrorProvider errorProviderCodePermanent;
    }
}