package roche_papier_ciseaux.dorsal;

import ca.ntro.app.ServerRegistrar;
import ca.ntro.app.backend.RemoteBackendNtro;
import roche_papier_ciseaux.commun.Declarations;

public class DorsalRochePapierCiseauxDistant extends RemoteBackendNtro{
	public void registerServer(ServerRegistrar registrar) {
        Declarations.declarerServeur(registrar);
    }
}
