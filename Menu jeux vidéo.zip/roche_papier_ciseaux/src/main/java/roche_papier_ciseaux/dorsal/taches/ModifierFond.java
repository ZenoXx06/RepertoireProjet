package roche_papier_ciseaux.dorsal.taches;

import static ca.ntro.app.tasks.backend.BackendTasks.message;
import static ca.ntro.app.tasks.backend.BackendTasks.model;
import static ca.ntro.app.tasks.frontend.FrontendTasks.created;

import ca.ntro.app.tasks.backend.BackendTasks;
import roche_papier_ciseaux.commun.message.MsgMettreCouleur;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class ModifierFond {

	public static void creerTaches(BackendTasks tasks, String idParametre) {
        tasks.taskGroup("ModifierFond" + "/" + idParametre)
             .waitsFor(model(ModeleCouleurs.class, idParametre))
             .andContains(subTasks -> {
            	 aleatoireCouleur(subTasks, idParametre);
              });
    }
        
        private static void aleatoireCouleur(BackendTasks subTasks, String idParametre) {
        	subTasks.task("aleatoireCouleur" + "/" + idParametre)
                 .waitsFor(message(MsgMettreCouleur.class, idParametre))
                 .thenExecutes(inputs -> {
                	 MsgMettreCouleur msgMettreCouleur = inputs.get(message(MsgMettreCouleur.class, idParametre));
                     ModeleCouleurs couleur = inputs.get(model(ModeleCouleurs.class, idParametre));
                     VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
                     msgMettreCouleur.mettreCouleur(vueCouleurParametre, couleur);
                 });
        }
}
