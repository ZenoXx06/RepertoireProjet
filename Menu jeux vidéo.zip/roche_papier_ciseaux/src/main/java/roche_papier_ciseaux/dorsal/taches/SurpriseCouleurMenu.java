package roche_papier_ciseaux.dorsal.taches;

import static ca.ntro.app.tasks.backend.BackendTasks.message;
import static ca.ntro.app.tasks.backend.BackendTasks.model;
import static ca.ntro.app.tasks.frontend.FrontendTasks.created;

import ca.ntro.app.tasks.backend.BackendTasks;
import roche_papier_ciseaux.commun.message.MsgSurpriseMenu;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;
import roche_papier_ciseaux.frontal.vues.VueMenu;

public class SurpriseCouleurMenu {

	public static void creerTaches(BackendTasks tasks, String idParametre) {
        tasks.taskGroup("SurpriseCouleursMenu" + "/" + idParametre)
             .waitsFor(model(ModeleCouleurs.class, idParametre))
             .andContains(subTasks -> {
                 surpriseCouleurMenu(subTasks, idParametre);
              });
    }
        
        private static void surpriseCouleurMenu(BackendTasks subTasks, String idParametre) {
        	subTasks.task("surpriseCouleurMenu" + "/" + idParametre)
                 .waitsFor(message(MsgSurpriseMenu.class, idParametre))
                 .thenExecutes(inputs -> {
                	 MsgSurpriseMenu msgSurpriseMenu = inputs.get(message(MsgSurpriseMenu.class, idParametre));
                     ModeleCouleurs couleur = inputs.get(model(ModeleCouleurs.class, idParametre));
                     VueMenu vueMenu = inputs.get(created(VueMenu.class));
                     msgSurpriseMenu.surpriseCouleurMenu(vueMenu, couleur);
                 });
        }
}
