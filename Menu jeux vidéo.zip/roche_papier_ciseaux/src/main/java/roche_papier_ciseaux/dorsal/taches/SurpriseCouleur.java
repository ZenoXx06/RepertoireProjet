package roche_papier_ciseaux.dorsal.taches;

import static ca.ntro.app.tasks.backend.BackendTasks.message;
import static ca.ntro.app.tasks.backend.BackendTasks.model;
import static ca.ntro.app.tasks.frontend.FrontendTasks.created;

import ca.ntro.app.tasks.backend.BackendTasks;
import roche_papier_ciseaux.commun.message.MsgSurprise;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class SurpriseCouleur {

	public static void creerTaches(BackendTasks tasks, String idParametre) {
        tasks.taskGroup("SurpriseCouleurs" + "/" + idParametre)
             .waitsFor(model(ModeleCouleurs.class, idParametre))
             .andContains(subTasks -> {
                 surpriseCouleur(subTasks, idParametre);
              });
    }
        
        private static void surpriseCouleur(BackendTasks subTasks, String idParametre) {
        	subTasks.task("surpriseCouleurs" + "/" + idParametre)
                 .waitsFor(message(MsgSurprise.class, idParametre))
                 .thenExecutes(inputs -> {
                	 MsgSurprise msgSurprise = inputs.get(message(MsgSurprise.class, idParametre));
                     ModeleCouleurs couleur = inputs.get(model(ModeleCouleurs.class, idParametre));
                     VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
                     msgSurprise.modifierCouleur(vueCouleurParametre, couleur);
                 });
        }
}
