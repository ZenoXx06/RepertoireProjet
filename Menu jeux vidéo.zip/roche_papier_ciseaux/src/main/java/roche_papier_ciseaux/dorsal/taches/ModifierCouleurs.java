package roche_papier_ciseaux.dorsal.taches;

import static ca.ntro.app.tasks.backend.BackendTasks.*;

import ca.ntro.app.tasks.backend.BackendTasks;
import roche_papier_ciseaux.commun.message.MsgAjouterCouleur;
import roche_papier_ciseaux.commun.message.MsgRetirerCouleur;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;

public class ModifierCouleurs {

    public static void creerTaches(BackendTasks tasks, String idParametre) {
        tasks.taskGroup("ModifierCouleurs" + "/" + idParametre)
             .waitsFor(model(ModeleCouleurs.class, idParametre))
             .andContains(subTasks -> {
                  ajouterCouleurs(subTasks, idParametre);
                  retirerCouleurs(subTasks, idParametre);
             });
    }
        
    private static void ajouterCouleurs(BackendTasks subTasks, String idParametre) {
        subTasks.task("ajouterCouleurs" + "/" + idParametre)
             .waitsFor(message(MsgAjouterCouleur.class, idParametre))
             .thenExecutes(inputs -> {
            	 MsgAjouterCouleur msgAjouterCouleur = inputs.get(message(MsgAjouterCouleur.class, idParametre));
                 ModeleCouleurs couleur = inputs.get(model(ModeleCouleurs.class, idParametre));

                 msgAjouterCouleur.ajouterA(couleur);
             });
    }
        
    private static void retirerCouleurs(BackendTasks subTasks, String idParametre) {
        subTasks.task("retirerCouleurs" + "/" + idParametre)
             .waitsFor(message(MsgRetirerCouleur.class, idParametre))
             .thenExecutes(inputs -> {
            	 MsgRetirerCouleur msgRetirerCouleur = inputs.get(message(MsgRetirerCouleur.class, idParametre));
            	 ModeleCouleurs couleur = inputs.get(model(ModeleCouleurs.class, idParametre));

            	 msgRetirerCouleur.retirerDe(couleur);
             });
    }
}