package roche_papier_ciseaux.dorsal;

import ca.ntro.app.backend.LocalBackendNtro;
import ca.ntro.app.tasks.backend.BackendTasks;
import roche_papier_ciseaux.dorsal.taches.ModifierCouleurs;
import roche_papier_ciseaux.dorsal.taches.ModifierFond;
import roche_papier_ciseaux.dorsal.taches.SurpriseCouleur;
import roche_papier_ciseaux.dorsal.taches.SurpriseCouleurMenu;
import roche_papier_ciseaux.maquette.MaquetteParametre;

public class DorsalRochePapierCiseaux extends LocalBackendNtro{

	@Override
	public void createTasks(BackendTasks tasks) {
		for (String idParametre : MaquetteParametre.parametreEnCours()) {
			ModifierCouleurs.creerTaches(tasks, idParametre);
			SurpriseCouleur.creerTaches(tasks, idParametre);
			ModifierFond.creerTaches(tasks, idParametre);
			SurpriseCouleurMenu.creerTaches(tasks, idParametre);
		}
	}

	@Override
	public void execute() {

	}

}
