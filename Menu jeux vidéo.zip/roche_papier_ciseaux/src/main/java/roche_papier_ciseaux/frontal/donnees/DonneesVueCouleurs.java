package roche_papier_ciseaux.frontal.donnees;

import ca.ntro.app.frontend.ViewData;
import roche_papier_ciseaux.commun.monde2d.MondeLogo2d;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class DonneesVueCouleurs implements ViewData{
	private MondeLogo2d mondeLogo2d = new MondeLogo2d();

	public void afficherSur(VueCouleurParametre vueCouleurParametre) {
		vueCouleurParametre.viderCanvas();
        vueCouleurParametre.afficherLogo2d(mondeLogo2d);
	}

	public void reagirTempsQuiPasse(double elapsedTime) {
		mondeLogo2d.onTimePasses(elapsedTime);
	}
}
