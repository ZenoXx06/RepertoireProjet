package roche_papier_ciseaux.frontal.vues;

import ca.ntro.app.NtroApp;
import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.views.ViewFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import roche_papier_ciseaux.commun.message.MsgAjouterCouleur;
import roche_papier_ciseaux.commun.message.MsgMettreCouleur;
import roche_papier_ciseaux.commun.message.MsgSurprise;
import roche_papier_ciseaux.commun.monde2d.MondeLogo2d;
import roche_papier_ciseaux.commun.valeurs.Couleurs;
import roche_papier_ciseaux.frontal.controles.CanvasLogo;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherMenu;
import roche_papier_ciseaux.frontal.fragments.FragmentCouleurs;
import roche_papier_ciseaux.maquette.MaquetteCouleurs;
import roche_papier_ciseaux.maquette.MaquetteSession;

public class VueCouleurParametre extends ViewFx {

	@FXML
	private VBox page;
	
	@FXML
    private Button boutonMettre;
	
	@FXML
    private Button boutonQuitterParametre;
	
	@FXML
    private Button boutonAjouterCouleur;
	
	@FXML
	private Button boutonSurprise;
	
	@FXML
    private CanvasLogo canvasLogo;
	
	@FXML
    private ComboBox<Couleurs> comboCouleurs;
	
	private ViewLoader<FragmentCouleurs> viewLoaderCouleurs;

	public ViewLoader<FragmentCouleurs> getViewLoaderCouleurs() {
		return viewLoaderCouleurs;
	}

	public void setViewLoaderCouleurs(ViewLoader<FragmentCouleurs> viewLoaderCouleurs) {
		this.viewLoaderCouleurs = viewLoaderCouleurs;
	}

	private class ListCellCouleurs extends ListCell<Couleurs> {

        @Override
        protected void updateItem(Couleurs couleurs, boolean empty) {
            super.updateItem(couleurs, empty);
            
            if(couleurs == null || empty) {

                setGraphic(null);

            }else {
                
                FragmentCouleurs fragment = couleurs.creerFragment(viewLoaderCouleurs);
                
            	couleurs.afficherSur(fragment);
                setGraphic(fragment.rootNode());
            }
        }
    }
    
	@Override
	public void initialiser() {
		Ntro.assertNotNull("page", page);
		Ntro.assertNotNull("comboCouleurs", comboCouleurs);
		Ntro.assertNotNull("boutonQuitterParametre", boutonQuitterParametre);
		Ntro.assertNotNull("boutonMettre", boutonMettre);
		Ntro.assertNotNull("boutonAjouterCouleur", boutonAjouterCouleur);
		Ntro.assertNotNull("boutonSurprise", boutonSurprise);
		Ntro.assertNotNull("canvasLogo", canvasLogo);
		installerEvtAfficherMenu();
		installerMsgAjouterCouleur();
		installerMsgAleatoire();
		installerMsgSurprise();
		initialiserComboCouleurs();
	}
	
	public void afficherCouleurs(String message) {
        comboCouleurs.setPromptText(message);
    }
	
	private void installerEvtAfficherMenu() {
		EvtAfficherMenu evtNtro = NtroApp.newEvent(EvtAfficherMenu.class);
		boutonQuitterParametre.setOnAction(evtFx -> {
			evtNtro.trigger();
		});
	}
	
	private void installerMsgAjouterCouleur() {
		MsgAjouterCouleur msgAjouterCouleur = NtroApp.newMessage(MsgAjouterCouleur.class, MaquetteSession.couleurCourante().getIdCouleur());
		boutonAjouterCouleur.setOnAction(evtFx -> {
			msgAjouterCouleur.setCouleur(MaquetteCouleurs.couleurCourant());
			msgAjouterCouleur.send();
			MaquetteCouleurs.prochaineCouleur();
        });
    }
	
	private void installerMsgAleatoire() {
		//MsgMettreCouleur msgMettreCouleur = NtroApp.newMessage(MsgMettreCouleur.class, MaquetteSession.couleurCourante().getIdCouleur());
		boutonMettre.setOnAction(evtFx -> {
			//msgMettreCouleur.setCouleur(MaquetteCouleurs.couleurCourant());
			//msgMettreCouleur.send();
			mettreCouleur(MaquetteCouleurs.couleurCourant());
			MaquetteCouleurs.prochaineCouleur();
        });
	}
	
	private void installerMsgSurprise() {
		//MsgSurprise msgSurprise = NtroApp.newMessage(MsgSurprise.class, MaquetteSession.couleurCourante().getIdCouleur());
		boutonSurprise.setOnAction(evtFx -> {
			//msgSurprise.setCouleur(MaquetteCouleurs.couleurCourant());
			//msgSurprise.send();
			modifierCouleur(MaquetteCouleurs.couleurCourant());
			MaquetteCouleurs.prochaineCouleur();
        });
    }
	
	private void initialiserComboCouleurs() {
		comboCouleurs.setButtonCell(new ListCellCouleurs());
		comboCouleurs.setCellFactory(new Callback<ListView<Couleurs>, ListCell<Couleurs>>() {
	        @Override
	        public ListCell<Couleurs> call(ListView<Couleurs> param) {
	            return new ListCellCouleurs();
	        }
	    });
	}

	public void ajouterCouleurs(Couleurs couleurs) {
		comboCouleurs.getItems().add(couleurs);
	}

	public void viderListeCouleurs() {
	    comboCouleurs.getItems().clear();
	}

	public void viderCanvas() {
		canvasLogo.clearCanvas();
	}

	public void afficherLogo2d(MondeLogo2d mondeLogo2d) {
		mondeLogo2d.drawOn(canvasLogo);
	}
	
	public void modifierCouleur(Couleurs couleur) {
        if (couleur.getNomCouleur().equals("Rouge")) {
        	boutonSurprise.setStyle("-fx-background-color: red");
		} else if (couleur.getNomCouleur().equals("Vert")) {
			boutonSurprise.setStyle("-fx-background-color: green");
		} else if (couleur.getNomCouleur().equals("Bleu")) {
			boutonSurprise.setStyle("-fx-background-color: blue");
		} else if (couleur.getNomCouleur().equals("Rose")) {
			boutonSurprise.setStyle("-fx-background-color: pink");
		} else if (couleur.getNomCouleur().equals("Orange")) {
			boutonSurprise.setStyle("-fx-background-color: orange");
		} else if (couleur.getNomCouleur().equals("Mauve")) {
			boutonSurprise.setStyle("-fx-background-color: purple");
		} else if (couleur.getNomCouleur().equals("Jaune")) {
			boutonSurprise.setStyle("-fx-background-color: yellow");
		} else if (couleur.getNomCouleur().equals("Noir")) {
			boutonSurprise.setStyle("-fx-background-color: grey");
		} else if (couleur.getNomCouleur().equals("Blanc")) {
			boutonSurprise.setStyle("-fx-background-color: white");
		} else if (couleur.getNomCouleur().equals("Turquoise")) {
			boutonSurprise.setStyle("-fx-background-color: turquoise");
		} else if (couleur.getNomCouleur().equals("Brun")) {
			boutonSurprise.setStyle("-fx-background-color: brown");
		}
	}
	
	public void mettreCouleur(Couleurs couleur) {
		if (couleur.getNomCouleur().equals("Rouge")) {
        	page.setStyle("-fx-background-color: red");
		} else if (couleur.getNomCouleur().equals("Vert")) {
			page.setStyle("-fx-background-color: green");
		} else if (couleur.getNomCouleur().equals("Bleu")) {
			page.setStyle("-fx-background-color: blue");
		} else if (couleur.getNomCouleur().equals("Rose")) {
			page.setStyle("-fx-background-color: pink");
		} else if (couleur.getNomCouleur().equals("Orange")) {
			page.setStyle("-fx-background-color: orange");
		} else if (couleur.getNomCouleur().equals("Mauve")) {
			page.setStyle("-fx-background-color: purple");
		} else if (couleur.getNomCouleur().equals("Jaune")) {
			page.setStyle("-fx-background-color: yellow");
		} else if (couleur.getNomCouleur().equals("Noir")) {
			page.setStyle("-fx-background-color: grey");
		} else if (couleur.getNomCouleur().equals("Blanc")) {
			page.setStyle("-fx-background-color: white");
		} else if (couleur.getNomCouleur().equals("Turquoise")) {
			page.setStyle("-fx-background-color: turquoise");
		} else if (couleur.getNomCouleur().equals("Brun")) {
			page.setStyle("-fx-background-color: brown");
		}
    }
}


