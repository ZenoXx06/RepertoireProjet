package roche_papier_ciseaux.frontal.vues;

import ca.ntro.app.NtroApp;
import ca.ntro.app.views.ViewFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import roche_papier_ciseaux.commun.monde2d.MondeLogo2d;
import roche_papier_ciseaux.commun.valeurs.Couleurs;
import roche_papier_ciseaux.frontal.controles.CanvasLogo;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherCouleurParametre;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherPageJouer;
import roche_papier_ciseaux.maquette.MaquetteCouleurs;

public class VueMenu extends ViewFx {

	@FXML
    private Button boutonRentrerParametre;
	
	@FXML
    private CanvasLogo canvasLogo;
	
	@FXML
	private VBox page;
	
	@FXML
	private Button boutonSurpriseMenu;
	
	@FXML
	private Button boutonJouer;
	
    @Override
    public void initialiser() {
    	Ntro.assertNotNull("page", page);
    	Ntro.assertNotNull("boutonRentrerParametre", boutonRentrerParametre);
    	Ntro.assertNotNull("canvasLogo", canvasLogo);
    	Ntro.assertNotNull("boutonSurpriseMenu", boutonSurpriseMenu);
    	Ntro.assertNotNull("boutonJouer", boutonJouer);
    	installerEvtAfficherCouleurParametre();
    	installerEvtAfficherPageJouer();
    	installerMsgSurpriseMenu();
    }
    
    private void installerEvtAfficherCouleurParametre() {
    	EvtAfficherCouleurParametre evtNtro = NtroApp.newEvent(EvtAfficherCouleurParametre.class);
    	boutonRentrerParametre.setOnAction(evtFx -> {
			evtNtro.trigger();
		});
	}
    
    private void installerEvtAfficherPageJouer() {
    	EvtAfficherPageJouer evtNtro = NtroApp.newEvent(EvtAfficherPageJouer.class);
    	boutonJouer.setOnAction(evtFx -> {
			evtNtro.trigger();
		});
	}
    
    private void installerMsgSurpriseMenu() {
		//MsgSurpriseMenu msgSurpriseMenu = NtroApp.newMessage(MsgSurpriseMenu.class, MaquetteSession.couleurCourante().getIdCouleur());
		boutonSurpriseMenu.setOnAction(evtFx -> {
			//msgSurpriseMenu.setCouleur(MaquetteCouleurs.couleurCourant());
			//msgSurpriseMenu.send();
			surpriseCouleurMenu(MaquetteCouleurs.couleurCourant());
			MaquetteCouleurs.prochaineCouleur();
        });
    }
    
    public void viderCanvas() {
		canvasLogo.clearCanvas();
	}

	public void afficherLogo2d(MondeLogo2d mondeLogo2d) {
		mondeLogo2d.drawOn(canvasLogo);
	}
	
	public void surpriseCouleurMenu(Couleurs couleur) {
		int nombre = Ntro.random().nextInt(5);
        if (couleur.getNomCouleur().equals("Rouge")) {
        	if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: red");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: red");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: red");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: red");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: red");
        	}
		} else if (couleur.getNomCouleur().equals("Vert")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: green");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: green");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: green");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: green");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: green");
        	}
		} else if (couleur.getNomCouleur().equals("Bleu")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: blue");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: blue");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: blue");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: blue");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: blue");
        	}
		} else if (couleur.getNomCouleur().equals("Rose")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: pink");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: pink");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: pink");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: pink");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: pink");
        	}
		} else if (couleur.getNomCouleur().equals("Orange")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: orange");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: orange");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: orange");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: orange");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: orange");
        	}
		} else if (couleur.getNomCouleur().equals("Mauve")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: purple");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: purple");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: purple");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: purple");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: purple");
        	}
		} else if (couleur.getNomCouleur().equals("Jaune")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: yellow");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: yellow");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: yellow");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: yellow");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: yellow");
        	}
		} else if (couleur.getNomCouleur().equals("Noir")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: grey");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: grey");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: grey");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: grey");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: grey");
        	}
		} else if (couleur.getNomCouleur().equals("Blanc")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: white");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: white");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: white");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: white");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: white");
        	}
		} else if (couleur.getNomCouleur().equals("Turquoise")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: turquoise");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: turquoise");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: turquoise");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: turquoise");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: turquoise");
        	}
		} else if (couleur.getNomCouleur().equals("Brun")) {
			if (nombre == 1) {
        		boutonSurpriseMenu.setStyle("-fx-background-color: brown");
        	} else if (nombre == 2) {
        		page.setStyle("-fx-background-color: brown");
        	} else if (nombre == 3) {
        		boutonRentrerParametre.setStyle("-fx-background-color: brown");
        	} else if (nombre == 0) {
        		canvasLogo.setStyle("-fx-background-color: brown");
        	} else if (nombre == 4) {
        		boutonJouer.setStyle("-fx-background-color: brown");
        	}
		}
	}
}