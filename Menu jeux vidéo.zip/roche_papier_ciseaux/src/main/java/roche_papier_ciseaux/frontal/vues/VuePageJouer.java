package roche_papier_ciseaux.frontal.vues;

import ca.ntro.app.NtroApp;
import ca.ntro.app.views.ViewFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import roche_papier_ciseaux.commun.monde2d.MondeLogo2d;
import roche_papier_ciseaux.frontal.controles.CanvasLogo;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherMenu;

public class VuePageJouer extends ViewFx {
	
	@FXML
	private Button boutonRetourMenu;
	
	@FXML
    private CanvasLogo canvasLogo;
	
    @Override
    public void initialiser() {
    	Ntro.assertNotNull("boutonRetourMenu", boutonRetourMenu);
    	Ntro.assertNotNull("canvasLogo", canvasLogo);
    	installerEvtAfficherMenu();
    }
    
    private void installerEvtAfficherMenu() {
		EvtAfficherMenu evtNtro = NtroApp.newEvent(EvtAfficherMenu.class);
		boutonRetourMenu.setOnAction(evtFx -> {
			evtNtro.trigger();
		});
	}
    
    public void viderCanvas() {
		canvasLogo.clearCanvas();
	}

	public void afficherLogo2d(MondeLogo2d mondeLogo2d) {
		mondeLogo2d.drawOn(canvasLogo);
	}
}
