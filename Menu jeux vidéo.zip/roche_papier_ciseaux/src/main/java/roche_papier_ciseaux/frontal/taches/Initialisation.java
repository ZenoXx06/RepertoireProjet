package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.services.Window;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import roche_papier_ciseaux.frontal.vues.VueRacine;
import roche_papier_ciseaux.frontal.fragments.FragmentCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;
import roche_papier_ciseaux.frontal.vues.VueMenu;
import roche_papier_ciseaux.frontal.vues.VuePageJouer;

public class Initialisation {

	public static void creerTaches(FrontendTasks tasks) {
		tasks.taskGroup("Initialisation")
				.andContains(subTasks -> {
					creerVueRacine(subTasks);
					creerVueCouleurParametre(subTasks);
					creerVueMenu(subTasks);
					creerVuePageJouer(subTasks);
					installerVueRacine(subTasks);
					installerVueCouleurParametre(subTasks);
					afficherFenetre(subTasks);
				});
	}

	 private static void creerVueMenu(FrontendTasks tasks) {
	        tasks.task(create(VueMenu.class))
	             .waitsFor(viewLoader(VueMenu.class))
	             .thenExecutesAndReturnsValue(inputs -> {
	                 ViewLoader<VueMenu> viewLoader = inputs.get(viewLoader(VueMenu.class));
	                 VueMenu vueMenu = viewLoader.createView();
	                 return vueMenu;
	             });
	    }
	 
	 private static void creerVuePageJouer(FrontendTasks tasks) {
	        tasks.task(create(VuePageJouer.class))
	             .waitsFor(viewLoader(VuePageJouer.class))
	             .thenExecutesAndReturnsValue(inputs -> {
	                 ViewLoader<VuePageJouer> viewLoader = inputs.get(viewLoader(VuePageJouer.class));
	                 VuePageJouer vuePageJouer = viewLoader.createView();
	                 return vuePageJouer;
	             });
	    }
	 
	private static void afficherFenetre(FrontendTasks subTasks) {
		subTasks.task("afficherFenetre")
				.waitsFor(window())
				.thenExecutes(inputs -> {
					Window window = inputs.get(window());
					window.resize(600, 400);
					window.show();
				});
	}

	private static void creerVueRacine(FrontendTasks tasks) {
		tasks.task(create(VueRacine.class))
				.waitsFor(viewLoader(VueRacine.class))
				.thenExecutesAndReturnsValue(inputs -> {
					ViewLoader<VueRacine> viewLoader = inputs.get(viewLoader(VueRacine.class));
					VueRacine vueRacine = viewLoader.createView();
					return vueRacine;
				});
	}

	private static void installerVueRacine(FrontendTasks tasks) {
		tasks.task("installerVueRacine")
				.waitsFor(window())
				.waitsFor(created(VueRacine.class))
				.thenExecutes(inputs -> {
					VueRacine vueRacine = inputs.get(created(VueRacine.class));
					Window window = inputs.get(window());
					window.installRootView(vueRacine);
				});
	}

	private static void creerVueCouleurParametre(FrontendTasks tasks) {
		tasks.task(create(VueCouleurParametre.class))
				.waitsFor(viewLoader(VueCouleurParametre.class))
				.waitsFor(viewLoader(FragmentCouleurs.class))
				.thenExecutesAndReturnsValue(inputs -> {
					ViewLoader<VueCouleurParametre> viewLoaderVueCouleurs = inputs.get(viewLoader(VueCouleurParametre.class));
					ViewLoader<FragmentCouleurs> viewLoaderCouleurs = inputs.get(viewLoader(FragmentCouleurs.class));
					
					VueCouleurParametre vueCouleurParametre = viewLoaderVueCouleurs.createView();
					
					vueCouleurParametre.setViewLoaderCouleurs(viewLoaderCouleurs);
					return vueCouleurParametre;
				});
	}

	private static void installerVueCouleurParametre(FrontendTasks tasks) {
		tasks.task("installerVueCouleurParametre")
				.waitsFor("installerVueRacine")
				.waitsFor(created(VueCouleurParametre.class))
				.thenExecutes(inputs -> {
					VueRacine vueRacine = inputs.get(created(VueRacine.class));
					VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
					vueRacine.afficherSousVue(vueCouleurParametre);
				});
	}
}
