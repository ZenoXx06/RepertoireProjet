package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.reflection.observer.Modified;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class AfficherCouleurs {
	
	public static void creerTaches(FrontendTasks tasks, String idParametre) {
        tasks.taskGroup("AfficherCouleurs")
             .waitsFor("Initialisation")
             .andContains(subTasks -> {
             afficherCouleurs(subTasks, idParametre);
             });
	}
	
	private static void afficherCouleurs(FrontendTasks tasks, String idParametre) {
		tasks.task("afficherCouleurs")
             .waitsFor(modified(ModeleCouleurs.class, idParametre))
             .executes(inputs -> {
                 VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
                 Modified<ModeleCouleurs> couleurs = inputs.get(modified(ModeleCouleurs.class, idParametre));
                 ModeleCouleurs ancienneCouleurs = couleurs.previousValue();
                 ModeleCouleurs couleurCourante = couleurs.currentValue();
            	 couleurCourante.afficherSur(vueCouleurParametre);
             });
    }
}
