package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.clock;
import static ca.ntro.app.tasks.frontend.FrontendTasks.create;
import static ca.ntro.app.tasks.frontend.FrontendTasks.created;

import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.clock.Tick;
import roche_papier_ciseaux.frontal.donnees.DonneesVueMenu;
import roche_papier_ciseaux.frontal.donnees.DonneesVuePageJouer;
import roche_papier_ciseaux.frontal.vues.VuePageJouer;

public class AfficherLogoPageJouer {
	public static void creerTaches(FrontendTasks tasks) {

        creerDonneesVuePageJouer(tasks);
        
        tasks.taskGroup("AfficherLogoJouer")

	        .waitsFor(created(DonneesVuePageJouer.class))
	
	        .andContains(subTasks -> {
	
	           prochaineImageLogo(subTasks);
	
	        });
    }

    private static void prochaineImageLogo(FrontendTasks subTasks) {

        subTasks.task("prochaineImageLogoJouer")

                 .waitsFor(clock().nextTick())

                 .thenExecutes(inputs -> {
                	
                	Tick tick = inputs.get(clock().nextTick());
                    DonneesVuePageJouer donneesVuePageJouer = inputs.get(created(DonneesVuePageJouer.class));
                    VuePageJouer vuePageJouer = inputs.get(created(VuePageJouer.class));
                    donneesVuePageJouer.reagirTempsQuiPasse(tick.elapsedTime());
                    donneesVuePageJouer.afficherSur(vuePageJouer);
                 });
    }
        
    private static void creerDonneesVuePageJouer(FrontendTasks tasks) {

        tasks.task(create(DonneesVuePageJouer.class))

             .waitsFor("Initialisation")

             .executesAndReturnsCreatedValue(inputs -> {

                 return new DonneesVuePageJouer();
             });
    }
}
