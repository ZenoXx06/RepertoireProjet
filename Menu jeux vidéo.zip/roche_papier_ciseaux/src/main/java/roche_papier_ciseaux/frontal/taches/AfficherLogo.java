package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.clock.Tick;
import roche_papier_ciseaux.frontal.donnees.DonneesVueCouleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class AfficherLogo {

    public static void creerTaches(FrontendTasks tasks) {

        creerDonneesVueCouleurs(tasks);
        
        tasks.taskGroup("AfficherLogo")

	        .waitsFor(created(DonneesVueCouleurs.class))
	
	        .andContains(subTasks -> {
	
	           prochaineImageLogo(subTasks);
	
	        });
    }

    private static void prochaineImageLogo(FrontendTasks subTasks) {

        subTasks.task("prochaineImageLogo")

                 .waitsFor(clock().nextTick())

                 .thenExecutes(inputs -> {
                	
                	Tick tick = inputs.get(clock().nextTick());
                    DonneesVueCouleurs donneesVueCouleurs = inputs.get(created(DonneesVueCouleurs.class));
                    VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
                    donneesVueCouleurs.reagirTempsQuiPasse(tick.elapsedTime());
                    donneesVueCouleurs.afficherSur(vueCouleurParametre);
                 });
    }
        
    private static void creerDonneesVueCouleurs(FrontendTasks tasks) {

        tasks.task(create(DonneesVueCouleurs.class))

             .waitsFor("Initialisation")

             .executesAndReturnsCreatedValue(inputs -> {

                 return new DonneesVueCouleurs();
             });
    }
}
