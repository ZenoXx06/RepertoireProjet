package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.clock.Tick;
import roche_papier_ciseaux.frontal.donnees.DonneesVueMenu;
import roche_papier_ciseaux.frontal.vues.VueMenu;

public class AfficherLogoMenu {

	public static void creerTaches(FrontendTasks tasks) {

        creerDonneesVueMenu(tasks);
        
        tasks.taskGroup("AfficherLogoMenu")

	        .waitsFor(created(DonneesVueMenu.class))
	
	        .andContains(subTasks -> {
	
	           prochaineImageLogo(subTasks);
	
	        });
    }

    private static void prochaineImageLogo(FrontendTasks subTasks) {

        subTasks.task("prochaineImageLogoMenu")

                 .waitsFor(clock().nextTick())

                 .thenExecutes(inputs -> {
                	
                	Tick tick = inputs.get(clock().nextTick());
                    DonneesVueMenu donneesVueMenu = inputs.get(created(DonneesVueMenu.class));
                    VueMenu vueMenu = inputs.get(created(VueMenu.class));
                    donneesVueMenu.reagirTempsQuiPasse(tick.elapsedTime());
                    donneesVueMenu.afficherSur(vueMenu);
                 });
    }
        
    private static void creerDonneesVueMenu(FrontendTasks tasks) {

        tasks.task(create(DonneesVueMenu.class))

             .waitsFor("Initialisation")

             .executesAndReturnsCreatedValue(inputs -> {

                 return new DonneesVueMenu();
             });
    }
}
