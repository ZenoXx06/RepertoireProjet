package roche_papier_ciseaux.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherCouleurParametre;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherMenu;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherPageJouer;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;
import roche_papier_ciseaux.frontal.vues.VueMenu;
import roche_papier_ciseaux.frontal.vues.VuePageJouer;
import roche_papier_ciseaux.frontal.vues.VueRacine;

public class Navigation {

    public static void creerTaches(FrontendTasks tasks) {
        tasks.taskGroup("Navigation")
             .waitsFor("Initialisation")
             .andContains(subTasks -> {
                 afficherVueCouleurParametre(subTasks);
                 afficherVueMenu(subTasks);
                 afficherVuePageJouer(subTasks);
             });
    }

    private static void afficherVueMenu(FrontendTasks tasks) {
        tasks.task("afficherVueMenu")
             .waitsFor(created(VueMenu.class))
             .waitsFor(event(EvtAfficherMenu.class))
             .thenExecutes(inputs -> {
                 VueRacine vueRacine = inputs.get(created(VueRacine.class));
                 VueMenu vueMenu = inputs.get(created(VueMenu.class));
                 vueRacine.afficherSousVue(vueMenu);
             });
    }

    private static void afficherVueCouleurParametre(FrontendTasks tasks) {
        tasks.task("afficherVueCouleurParametre")
              .waitsFor(event(EvtAfficherCouleurParametre.class))
              .thenExecutes(inputs -> {
                  VueRacine vueRacine = inputs.get(created(VueRacine.class));
                  VueCouleurParametre vueCouleurParametre = inputs.get(created(VueCouleurParametre.class));
                  vueRacine.afficherSousVue(vueCouleurParametre);
              });
    }
    
    private static void afficherVuePageJouer(FrontendTasks tasks) {
        tasks.task("afficherVuePageJouer")
              .waitsFor(event(EvtAfficherPageJouer.class))
              .thenExecutes(inputs -> {
                  VueRacine vueRacine = inputs.get(created(VueRacine.class));
                  VuePageJouer vuePageJouer = inputs.get(created(VuePageJouer.class));
                  vueRacine.afficherSousVue(vuePageJouer);
              });
    }
}
