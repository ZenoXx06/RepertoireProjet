package roche_papier_ciseaux.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;

public class EvtAfficherMenu extends EventNtro{

}
