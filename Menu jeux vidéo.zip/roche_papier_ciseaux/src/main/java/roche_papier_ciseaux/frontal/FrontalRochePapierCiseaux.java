package roche_papier_ciseaux.frontal;

import ca.ntro.app.NtroApp;
import ca.ntro.app.frontend.FrontendFx;
import ca.ntro.app.frontend.ViewRegistrarFx;
import ca.ntro.app.frontend.events.EventRegistrar;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import roche_papier_ciseaux.frontal.vues.VueRacine;
import roche_papier_ciseaux.maquette.MaquetteSession;
import roche_papier_ciseaux.frontal.donnees.DonneesVueCouleurs;
import roche_papier_ciseaux.frontal.donnees.DonneesVueMenu;
import roche_papier_ciseaux.frontal.donnees.DonneesVuePageJouer;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherCouleurParametre;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherMenu;
import roche_papier_ciseaux.frontal.evenements.EvtAfficherPageJouer;
import roche_papier_ciseaux.frontal.fragments.FragmentCouleurs;
import roche_papier_ciseaux.frontal.taches.AfficherCouleurs;
import roche_papier_ciseaux.frontal.taches.AfficherLogo;
import roche_papier_ciseaux.frontal.taches.AfficherLogoMenu;
import roche_papier_ciseaux.frontal.taches.AfficherLogoPageJouer;
import roche_papier_ciseaux.frontal.taches.Initialisation;
import roche_papier_ciseaux.frontal.taches.Navigation;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;
import roche_papier_ciseaux.frontal.vues.VueMenu;
import roche_papier_ciseaux.frontal.vues.VuePageJouer;

public class FrontalRochePapierCiseaux implements FrontendFx {

	@Override
	public void createTasks(FrontendTasks tasks) {
		Initialisation.creerTaches(tasks);
        AfficherCouleurs.creerTaches(tasks, MaquetteSession.couleurCourante().getIdCouleur());
        Navigation.creerTaches(tasks);
        AfficherLogo.creerTaches(tasks);
        AfficherLogoMenu.creerTaches(tasks);
        AfficherLogoPageJouer.creerTaches(tasks);
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

	@Override
	public void registerEvents(EventRegistrar registrar) {
		registrar.registerEvent(EvtAfficherCouleurParametre.class);
		registrar.registerEvent(EvtAfficherMenu.class);
		registrar.registerEvent(EvtAfficherPageJouer.class);
	}

	@Override
	public void registerViews(ViewRegistrarFx registrar) {
		registrar.registerView(VueRacine.class, "/racine.xml");
		registrar.registerView(VueCouleurParametre.class, "/couleur_parametre.xml");
		registrar.registerView(VueMenu.class, "/menu.xml");
		registrar.registerView(VuePageJouer.class, "/pageJouer.xml");
		
		registrar.registerFragment(FragmentCouleurs.class, "/fragments/couleurs.xml");
		
		registrar.registerStylesheet("/couleur_parametre.css");
		
		registrar.registerDefaultResources("/couleur_parametre_fr.properties");
		registrar.registerResources(NtroApp.locale("en"), 
				"/couleur_parametre_en.properties");
		
		registrar.registerViewData(DonneesVueCouleurs.class);
		registrar.registerViewData(DonneesVueMenu.class);
		registrar.registerViewData(DonneesVuePageJouer.class);
	}

}
