package roche_papier_ciseaux.frontal.fragments;

import ca.ntro.app.NtroApp;
import ca.ntro.app.views.ViewFragmentFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import roche_papier_ciseaux.commun.message.MsgRetirerCouleur;

public class FragmentCouleurs extends ViewFragmentFx{

    @FXML
    private Label labelCouleur;
    
    @FXML
    private Button boutonRetirer;
    
    @FXML
    private Button boutonMettreCouleur;
    
    private String idCouleur;

    public void memoriserIdCouleur(String idCouleur) {
        this.idCouleur = idCouleur;
        installerMsgRetirerCouleur(idCouleur);
    }
    
    @Override
    public void initialiser() {
        Ntro.assertNotNull("labelCouleur", labelCouleur);
        Ntro.assertNotNull("boutonRetirer", boutonRetirer);
        Ntro.assertNotNull("boutonMettreCouleur", boutonMettreCouleur);
    }
    
    public void installerMsgRetirerCouleur(String idCouleur) {
        //MsgRetirerCouleur msgRetirerCouleur = NtroApp.newMessage(MsgRetirerCouleur.class);
        //msgRetirerCouleur.setIdCouleur(idCouleur);
        
        boutonRetirer.setOnAction(evtFx -> {
            //msgRetirerCouleur.send();
            //Ce que sa devrait faire:
            //ModeleCouleur.retirerCouleur(idCouleur);
        });
    }
        
    public void afficherCouleur(String nomCouleur) {
    	labelCouleur.setText("");
        labelCouleur.setText(nomCouleur);
        if (nomCouleur.equals("Rouge")) {
        	labelCouleur.setStyle("-fx-text-fill: Red");
		} else if (nomCouleur.equals("Vert")) {
			labelCouleur.setStyle("-fx-text-fill: green");
		} else if (nomCouleur.equals("Bleu")) {
			labelCouleur.setStyle("-fx-text-fill: blue");
		} else if (nomCouleur.equals("Rose")) {
			labelCouleur.setStyle("-fx-text-fill: pink");
		} else if (nomCouleur.equals("Orange")) {
			labelCouleur.setStyle("-fx-text-fill: orange");
		} else if (nomCouleur.equals("Mauve")) {
			labelCouleur.setStyle("-fx-text-fill: purple");
		} else if (nomCouleur.equals("Jaune")) {
			labelCouleur.setStyle("-fx-text-fill: yellow");
		} else if (nomCouleur.equals("Noir")) {
			labelCouleur.setStyle("-fx-text-fill: black");
		} else if (nomCouleur.equals("Blanc")) {
			labelCouleur.setStyle("-fx-text-fill: white");
		} else if (nomCouleur.equals("Turquoise")) {
			labelCouleur.setStyle("-fx-text-fill: turquoise");
		} else if (nomCouleur.equals("Brun")) {
			labelCouleur.setStyle("-fx-text-fill: brown");
		} 
    }
}
