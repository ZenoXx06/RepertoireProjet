package roche_papier_ciseaux.frontal.controles;

import ca.ntro.app.fx.controls.ResizableWorld2dCanvasFx;
import roche_papier_ciseaux.commun.monde2d.MondeLogo2d;

public class CanvasLogo extends ResizableWorld2dCanvasFx{

	@Override
	protected void initialize() {
		setInitialWorldSize(MondeLogo2d.LARGEUR_MONDE, MondeLogo2d.HAUTEUR_MONDE);
	}

}
