package roche_papier_ciseaux.maquette;

import java.util.List;

import ca.ntro.core.initialization.Ntro;
import roche_papier_ciseaux.commun.valeurs.Couleurs;

public class MaquetteCouleurs {

	public static void prochaineCouleur() {
        MaquetteSession.couleurCourante = eviterRepetitionDeCouleur(couleurAleatoire());
    }
	
    public static Couleurs couleurCourant() {
        return MaquetteSession.couleurCourante;
    }

    static Couleurs couleurAleatoire() {
    	Couleurs couleur = new Couleurs();
    	couleur.setIdCouleur(idAleatoire());
    	couleur.setNomCouleur(nomAleatoire());
        return couleur;
    }

    private static Couleurs eviterRepetitionDeCouleur(Couleurs couleurAleatoire) {
        while(couleurAleatoire.getNomCouleur().equals(MaquetteSession.couleurCourante.getNomCouleur())) {
        	couleurAleatoire.setNomCouleur(nomAleatoire());
        }
        return couleurAleatoire;
    }

    static String idAleatoire() {
        return Ntro.random().nextId(4);
    }

    static String nomAleatoire() {
        List<String> choixDeCouleurs = List.of("Bleu", 
                                           "Vert", 
                                           "Rouge", 
                                           "Rose", 
                                           "Orange", 
                                           "Mauve", 
                                           "Jaune",
                                           "Noir",
                                           "Blanc",
                                           "Turquoise",
                                           "Brun");
        return Ntro.random().choice(choixDeCouleurs);
    }
}
