package roche_papier_ciseaux.maquette;

import java.util.List;

public class MaquetteParametre {
	public static List<String> parametreEnCours(){
        return List.of("aaaa","bbbb","cccc");
    }
}
