package roche_papier_ciseaux.maquette;

import roche_papier_ciseaux.commun.valeurs.Couleurs;

public class MaquetteSession {
	public static boolean modeTest = true;

    static Couleurs couleurCourante = MaquetteCouleurs.couleurAleatoire();
    public static Couleurs couleurCourante () {
        return couleurCourante;
    }
    
    public static void initialiser(String[] args) {
        String id = null;
        String nom = null;
        	
        if(args.length > 0) {
            id = args[0];
            modeTest = false;
        }else {
            id = MaquetteCouleurs.idAleatoire();
        }           

        //if(args.length > 1) {
        //    nom = args[1];
        //}else {
            nom = MaquetteCouleurs.nomAleatoire();
        //}

        couleurCourante = new Couleurs(id, nom);
    }
}
