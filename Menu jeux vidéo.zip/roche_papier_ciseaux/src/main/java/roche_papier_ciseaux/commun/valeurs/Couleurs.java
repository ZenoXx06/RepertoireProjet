package roche_papier_ciseaux.commun.valeurs;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.models.ModelValue;
import roche_papier_ciseaux.frontal.fragments.FragmentCouleurs;

public class Couleurs implements ModelValue{

	private String idCouleur;
	private String nomCouleur;
	
	public String getIdCouleur() {
		return idCouleur;
	}

	public void setIdCouleur(String idCouleur) {
		this.idCouleur = idCouleur;
	}

	public String getNomCouleur() {
		return nomCouleur;
	}

	public void setNomCouleur(String nomCouleur) {
		this.nomCouleur = nomCouleur;
	}

	public Couleurs() {
		
	}
	
	public Couleurs(String id, String couleur) {
        setIdCouleur(id);
        setNomCouleur(couleur);
    }
	
	@Override
    public String toString() {
        return nomCouleur.toString();
    }

	public void afficherSur(FragmentCouleurs fragmentCouleurs) {
		fragmentCouleurs.afficherCouleur(this.getNomCouleur());
		fragmentCouleurs.memoriserIdCouleur(idCouleur);
	}
	
	public FragmentCouleurs creerFragment(ViewLoader<FragmentCouleurs> viewLoaderCouleurs) {
		return viewLoaderCouleurs.createView();
	}
}
