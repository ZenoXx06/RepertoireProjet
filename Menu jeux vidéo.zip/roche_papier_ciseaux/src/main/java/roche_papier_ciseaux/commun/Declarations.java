package roche_papier_ciseaux.commun;

import ca.ntro.app.ServerRegistrar;
import ca.ntro.app.messages.MessageRegistrar;
import ca.ntro.app.models.ModelRegistrar;
import roche_papier_ciseaux.commun.message.MsgAjouterCouleur;
import roche_papier_ciseaux.commun.message.MsgMettreCouleur;
import roche_papier_ciseaux.commun.message.MsgRetirerCouleur;
import roche_papier_ciseaux.commun.message.MsgSurprise;
import roche_papier_ciseaux.commun.message.MsgSurpriseMenu;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.commun.valeurs.Couleurs;

public class Declarations {

	public static void declarerMessages(MessageRegistrar registrar) {
		registrar.registerMessage(MsgAjouterCouleur.class);
		registrar.registerMessage(MsgSurprise.class);
		registrar.registerMessage(MsgRetirerCouleur.class);
		registrar.registerMessage(MsgMettreCouleur.class);
		registrar.registerMessage(MsgSurpriseMenu.class);
	}

	public static void declarerModeles(ModelRegistrar registrar) {
		registrar.registerModel(ModeleCouleurs.class);
		registrar.registerValue(Couleurs.class);
	}

	public static void declarerServeur(ServerRegistrar registrar) {
		registrar.registerName("localhost");
        registrar.registerPort(8002);
	}

}
