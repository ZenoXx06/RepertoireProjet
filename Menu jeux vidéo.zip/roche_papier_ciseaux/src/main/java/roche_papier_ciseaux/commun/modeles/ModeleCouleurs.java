package roche_papier_ciseaux.commun.modeles;

import java.util.ArrayList;
import java.util.List;

import ca.ntro.app.models.Model;
import ca.ntro.app.models.WriteObjectGraph;
import roche_papier_ciseaux.commun.valeurs.Couleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;
import roche_papier_ciseaux.frontal.vues.VueMenu;

public class ModeleCouleurs implements Model, WriteObjectGraph {
	
		private List<Couleurs> lesCouleurs = new ArrayList<>();

		public List<Couleurs> getLesCouleurs() {
			return lesCouleurs;
		}

		public void setLesCouleurs(List<Couleurs> lesCouleurs) {
			this.lesCouleurs = lesCouleurs;
		}

		public ModeleCouleurs() {
	    	
	     	}
		
		public void afficherSur(VueCouleurParametre vueCouleurParametre) {
            vueCouleurParametre.viderListeCouleurs();
            for(Couleurs couleur : lesCouleurs) {
                vueCouleurParametre.ajouterCouleurs(couleur);
            }
		}
		
		@Override
	    public String toString() {
	        StringBuilder builder = new StringBuilder();
	        for(Couleurs couleurs : lesCouleurs) {
	            builder.append(couleurs.toString());
	            builder.append("\n");
	        }
	        return builder.toString();
	    }
		
		public void ajouterCouleur(Couleurs couleur) {
	        lesCouleurs.add(couleur);
	    }
		
		public void modifierCouleur(VueCouleurParametre vueCouleurParametre, Couleurs couleur) {
			vueCouleurParametre.modifierCouleur(couleur);
		}
		
		public void surpriseCouleurMenu(VueMenu vueMenu, Couleurs couleur) {
			vueMenu.surpriseCouleurMenu(couleur);
		}
		
		public void mettreCouleur(VueCouleurParametre vueCouleurParametre, Couleurs couleur) {
			vueCouleurParametre.mettreCouleur(couleur);
		}
		
		public void retirerCouleur(String idCouleur) {
	        int indiceCouleur = -1;
	        
	        for(int i = 0; i < lesCouleurs.size(); i++) {
	            if(lesCouleurs.get(i).getIdCouleur().equals(idCouleur)) {
	            	indiceCouleur = i;
	                break;
	            }
	        }
	        
	        if(indiceCouleur >= 0) {
	        	lesCouleurs.remove(indiceCouleur);
	        }
	    }
}
