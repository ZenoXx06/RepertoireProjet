package roche_papier_ciseaux.commun.monde2d;

import ca.ntro.app.fx.controls.ResizableWorld2dCanvasFx;
import ca.ntro.app.fx.controls.World2dMouseEventFx;
import ca.ntro.app.fx.world2d.World2dFx;
import ca.ntro.core.initialization.Ntro;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class MondeLogo2d extends World2dFx{
	public static final double LARGEUR_MONDE = 250;
    public static final double HAUTEUR_MONDE = 250;
    public static int nombre = Ntro.random().nextInt(15);

    @Override
    protected void initialize() {
        setWidth(LARGEUR_MONDE);
        setHeight(HAUTEUR_MONDE);
        if (nombre == 0) {
    		nombre = 1;
    	}
        for (int i = 0; i < nombre; i++) {
        	addObject2d(new Balle2d());
		}
    }

    @Override
    public void drawOn(ResizableWorld2dCanvasFx canvas) {
        canvas.drawOnWorld(gc -> {
            dessinerTerrain(gc);
        });
        super.drawOn(canvas);
    }

    private void dessinerTerrain(GraphicsContext gc) {
        gc.save();
        gc.setStroke(Color.RED);
        gc.setLineWidth(1);
        gc.strokeRect(0, 0, getWidth(), getHeight());
        gc.restore();
    }

	@Override
	protected void onMouseEventNotConsumed(World2dMouseEventFx mouseEvent) {
		// TODO Auto-generated method stub
		
	}
}
