package roche_papier_ciseaux.commun.monde2d;

import ca.ntro.app.fx.world2d.Object2dFx;

public abstract class ObjetLogo2d extends Object2dFx<MondeLogo2d>{

}
