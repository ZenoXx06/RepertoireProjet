package roche_papier_ciseaux.commun.message;

import ca.ntro.app.messages.MessageNtro;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.commun.valeurs.Couleurs;
import roche_papier_ciseaux.frontal.vues.VueCouleurParametre;

public class MsgSurprise extends MessageNtro {

	private Couleurs couleur;

	public MsgSurprise() {
	}

	public Couleurs getCouleur() {
		return couleur;
	}

	public void setCouleur(Couleurs couleur) {
		this.couleur = couleur;
	}
	
	public void modifierCouleur(VueCouleurParametre vueCouleurParametre, ModeleCouleurs couleurs) {
        couleurs.modifierCouleur(vueCouleurParametre, couleur);
    }
}