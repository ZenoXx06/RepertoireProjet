package roche_papier_ciseaux.commun.message;

import ca.ntro.app.messages.MessageNtro;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;

public class MsgRetirerCouleur extends MessageNtro{

	private String idCouleur;

    public String getIdCouleur() {
        return idCouleur;
    }

    public void setIdCouleur(String idCouleur) {
        this.idCouleur = idCouleur;
    }

    public void retirerDe(ModeleCouleurs couleurs) {
        couleurs.retirerCouleur(idCouleur);
    }
}
