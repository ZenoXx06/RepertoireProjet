package roche_papier_ciseaux.commun.message;

import ca.ntro.app.messages.MessageNtro;
import roche_papier_ciseaux.commun.modeles.ModeleCouleurs;
import roche_papier_ciseaux.commun.valeurs.Couleurs;

public class MsgAjouterCouleur extends MessageNtro {

	private Couleurs couleur;

	public MsgAjouterCouleur() {
	}

	public Couleurs getCouleur() {
		return couleur;
	}

	public void setCouleur(Couleurs couleur) {
		this.couleur = couleur;
	}
	
	public void ajouterA(ModeleCouleurs couleurs) {

        couleurs.ajouterCouleur(couleur);

    }
	
}
