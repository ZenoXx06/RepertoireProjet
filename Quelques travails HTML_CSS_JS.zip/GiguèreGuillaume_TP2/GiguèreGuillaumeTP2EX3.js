const poste = [ "P", "A", "P", "A", "P", "A", "O", "P", "O"];
const nbCafe = [ 3, 2, 1, 20, 4, 2, 5, 11, 32];

function moyenneO(nbCafe, poste){
	let somme = 0;
	let i = 0;
	let k = 0
	let j = 0;
	let index = 0;
	let tempPoste = [];
	let tempNbCafe = [];
	while (i < poste.length) {
		if (poste[i] == "O") {
			tempPoste.push(i);
		}
		i++;
	}
	while (k < nbCafe.length) {
		if (k == tempPoste[j]) {
			tempNbCafe.push(nbCafe[k]);
			j++;
		}
		k++;
	}
	while (index < tempNbCafe.length) {
        somme += tempNbCafe[index];
		index++;
	}
	let moyenne = somme / tempNbCafe.length;
	document.write("Consommation moyenne des opérateurs: " + moyenne + " tasses" + "<br>")
}

function moyenneP(nbCafe, poste){
	let somme = 0;
	let i = 0;
	let k = 0
	let j = 0;
	let index = 0;
	let tempPoste = [];
	let tempNbCafe = [];
	while (i < poste.length) {
		if (poste[i] == "P") {
			tempPoste.push(i);
		}
		i++;
	}
	while (k < nbCafe.length) {
		if (k == tempPoste[j]) {
			tempNbCafe.push(nbCafe[k]);
			j++;
		}
		k++;
	}
	while (index < tempNbCafe.length) {
        somme += tempNbCafe[index];
		index++;
	}
	let moyenne = somme / tempNbCafe.length;
	document.write("Consommation moyenne des opérateurs: " + moyenne + " tasses" + "<br>")
}

function moyenneA(nbCafe, poste){
	let somme = 0;
	let i = 0;
	let k = 0
	let j = 0;
	let index = 0;
	let tempPoste = [];
	let tempNbCafe = [];
	while (i < poste.length) {
		if (poste[i] == "A") {
			tempPoste.push(i);
		}
		i++;
	}
	while (k < nbCafe.length) {
		if (k == tempPoste[j]) {
			tempNbCafe.push(nbCafe[k]);
			j++;
		}
		k++;
	}
	while (index < tempNbCafe.length) {
        somme += tempNbCafe[index];
		index++;
	}
	let moyenne = somme / tempNbCafe.length;
	document.write("Consommation moyenne des opérateurs: " + moyenne + " tasses" + "<br>")
}

function minimumP(nbCafe, poste){
	let i = 0;
	let k = 0
	let j = 0;
	let index = 0;
	let tempPoste = [];
	let tempNbCafe = [];
	while (i < poste.length) {
		if (poste[i] == "P") {
			tempPoste.push(i);
		}
		i++;
	}
	while (k < nbCafe.length) {
		if (k == tempPoste[j]) {
			tempNbCafe.push(nbCafe[k]);
			j++;
		}
		k++;
	}
	let min = tempNbCafe[0];
	while (index < tempNbCafe.length) {
		if (min > tempNbCafe[index]) {
			min = tempNbCafe[index];
		}
		index++;
	}
	document.write("Consommation minimal des opérateurs: " + min + " tasses" + "<br>")
}

function remplacement(nbCafe, poste){
	let i = 0;
	let k = 0;
	poste[3] = "T";
	poste[4] = "T";
	poste[5] = "T";
	document.write("<br>" + "Tableau des postes:" + "<br>")
	while (i < poste.length) {
		document.write(poste[i] + " ")
		i++;
	}
	nbCafe[3] = Math.floor(Math.random() * (55 - 35 + 1)) + 35;
	nbCafe[4] = Math.floor(Math.random() * (55 - 35 + 1)) + 35;
	nbCafe[5] = Math.floor(Math.random() * (55 - 35 + 1)) + 35;
	document.write("<br>" + "Tableau des consommations:" + "<br>")
	while (k < poste.length) {
		document.write(nbCafe[k] + " ")
		k++;
	}
}

moyenneO(nbCafe, poste);
moyenneP(nbCafe, poste);
moyenneA(nbCafe, poste);
minimumP(nbCafe, poste);
remplacement(nbCafe, poste);