let num = prompt("Entrez un numéro: ");

function recursive(tab1) {
	if(tab1.length == 1) {
		document.write("--- " + tab1[0] + "<br>")
	} else {
		document.write("--- " + tab1[0] + "<br>")
		tab1 = tab1.slice(1);
		recursive(tab1);
	}
}

function iterative(num) {
	let debut = new Date().getTime();
	const tab = num.split("");
	let i = 0;
	while(i < tab.length) {
		document.write("--- " + tab[i])
		document.write("<br>")
		i++;
	}
	let fin = new Date().getTime();
	let time = fin - debut;
	document.write("Le temps d'éxecution: " + time + " ms")
}

const tab1 = num.split("");
if (tab1.length != 0) {
	let debut = new Date().getTime();
	recursive(tab1);
	let fin = new Date().getTime();
	let time = fin - debut;
	document.write("Le temps d'éxecution: " + time + " ms" + "<br>")
	iterative(num);
} else {
	document.write("Vous n'avez pas rentrez de nombre")
}