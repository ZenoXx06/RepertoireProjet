function afficher(nombre){
	let tab = [];
	let i = 1;
	let k = 0;
	let boucle = 0;
	while (i <= nombre) {
		tab.push(i);
		i = i + 2;
	}
	while (tab.length != 0) {
		k = 0;
		while (k < tab.length){
			document.write(tab[k] + " ")
			k++
		}
		document.write("<br>")
		tab = tab.slice(1);
	}
	document.write("<br>")
}

afficher(5);
afficher(7);
afficher(9);