/* EXERCICE 1

// Afficher le nouveau contenu du paragraphe 
function afficherP(){
    const div = document.querySelector('p');
    div.innerHTML = "Nouveau contenu du paragraphe";
}

// supprimer le h2
function supprimerH2(){
    const div = document.querySelector('h2');
    div.innerHTML = "";
} 

// supprimer la photo
function ImageSup(){
    const parentA = document.querySelector('a');
    parentA.removeChild(parentA.firstChild);
}

setTimeout(function(){
    afficherP();
},5000); // 5s

setTimeout(function(){
    supprimerH2();
},10000); // 10s

setTimeout(function(){
    ImageSup();
},15000); // 15s
*/

/* EXERCICE 2 */
let pos = 0;
function action () {
	if (pos == 0) {
		const para = document.querySelector('p');
		para.innerHTML = "Nouveau contenu du paragraphe";
	} else if (pos == 1) {
		const h2 = document.querySelector('h2');
		h2.innerHTML = "";
	} else {
		const parentA = document.querySelector('a');
		parentA.removeChild(parentA.firstChild);
	}
	pos++
	if (pos >= 3){
		clearInterval(interval);
	}
}

let interval = setInterval(action, 2000);

