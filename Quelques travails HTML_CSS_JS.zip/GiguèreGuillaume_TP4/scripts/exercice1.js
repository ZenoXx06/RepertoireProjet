//creation du header
const headerEl = document.createElement("header");
document.body.appendChild(headerEl)
const spanEl = document.createElement("span")
    h1Text = document.createTextNode("Meuble ")
    h1 = document.createElement("h1")
    spanNom = document.createTextNode(" Namir et Guillaume")

headerEl.appendChild(h1)
h1.appendChild(h1Text)
spanEl.setAttribute("class","rouge")
h1.appendChild(spanEl)
spanEl.appendChild(spanNom)


// creation nav 
const nav = document.createElement("nav") 
        ulEl = document.createElement("ul")
        liEl_produits = document.createElement("li")
        liEl_services = document.createElement("li")
        liEl_contacter = document.createElement("li")
        aElP = document.createElement("a")
        aElS = document.createElement("a")
        aElC = document.createElement("a")
        aEl_produit = document.createTextNode("Nos Produits")
        aEl_services = document.createTextNode("Nos services")
        aEl_contacter = document.createTextNode("Nous contacter")

document.body.appendChild(nav)
nav.appendChild(ulEl)

ulEl.appendChild(liEl_produits) // produit 
liEl_produits.appendChild(aElP)
aElP.setAttribute("href","Produits/produits.html")
aElP.appendChild(aEl_produit)

ulEl.appendChild(liEl_services) // services
liEl_services.appendChild(aElS)
aElS.setAttribute("href","Services/services.html")
aElS.appendChild(aEl_services)

ulEl.appendChild(liEl_contacter) // contacter
liEl_contacter.appendChild(aElC)
aElC.setAttribute("href","mailto:coco@meubles.com")
aElC.appendChild(aEl_contacter)


// section 
const section = document.createElement("section");
        h2El = document.createElement("h2")
        articleEl = document.createElement("article")
        pEl = document.createElement("p")
        h2Text = document.createTextNode("Vente de meubles de qualité")
        pText = document.createTextNode("Notre compagnie vous offre les meilleurs rapports qualité-prix")

document.body.appendChild(section);
section.appendChild(h2El)
h2El.setAttribute("class","rouge")
h2El.appendChild(h2Text)

section.appendChild(articleEl)
articleEl.appendChild(pEl)
pEl.appendChild(pText)

// footer
const footerEl = document.createElement("footer");
        addEl = document.createElement("address");
        addText = document.createTextNode("Adresse: 9876 Route de l'Avenir Tél, : (450) 123-4567")

document.body.appendChild(footerEl);
footerEl.appendChild(addEl);
addEl.appendChild(addText);
