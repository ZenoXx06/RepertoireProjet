function calcul(num){
	const tab = num.split('');
	let longueur = tab.length;
	let unite = tab[tab.length - 1]
	let uniteLettre = '';
	let dizaine = 0;
	let dizaineLettre = '';
	let centaine = 0;
	let centaineLettre = '';
	if (longueur >= 2) {
		dizaine = tab[tab.length - 2]
	}
	if (longueur == 3) {
		centaine = tab[tab.length - 3]	
	}
	const tabUnite = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
    const tabDizaine = ['', 'dix', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante', 'quatre-vingt', 'quatre-vingt'];
	let dizaineTiret = '-';

	if (num == 0) {
		document.write('zéro');
		} else {
			if (unite == 1 && dizaine > 0 && dizaine != 8){
				uniteLettre = 'et-' + tabUnite[unite];
			} else {
				uniteLettre = tabUnite[unite];
			}
			if (dizaine == 1 && unite > 0) {
			dizaineLettre = tabUnite[10 + parseInt(unite)];
			uniteLettre = '';
			} else if (dizaine == 7 || dizaine == 9) {
				if (dizaine == 7 && unite == 1) {
					dizaineTiret = '-et-';
				}
				dizaineLettre = tabDizaine[dizaine] + dizaineTiret + tabUnite[10 + parseInt(unite)];
			    uniteLettre = '';
			} else {
				if ((dizaine == 2 || dizaine == 3 || dizaine == 4 || dizaine == 5 || dizaine == 6) && unite == 1) {
					dizaineTiret = '-et-';
					dizaineLettre = tabDizaine[dizaine] + dizaineTiret + tabUnite[unite];
					uniteLettre = '';
				} else {
					dizaineLettre = tabDizaine[dizaine];
				}
			}
			if (dizaine == 8 && unite == 0) {
				dizaineLettre += 's';
			}
			if (centaine > 1) {
				centaineLettre = tabUnite[centaine] + '-';
			}
			if (centaine > 0) {
				centaineLettre += 'cent';
			}
			if (centaine > 1 && dizaine == 0 && unite == 0){
				centaineLettre += 's';
			}
			document.write(centaineLettre)
			if (centaineLettre != '' && dizaineLettre != '') {
				document.write('-')
			}
			document.write(dizaineLettre)
			if ((centaineLettre != '' && uniteLettre != '') || (dizaineLettre != '' && uniteLettre != '')){
				document.write('-')
			}
			document.write(uniteLettre)
		}
}

let bon = false;
while (bon == false) {
	let num = prompt('Entrez un numéro entre 0 et 999: ');
	if (num < 0 || num > 999 || num == '') {
        alert('Veuillez entrer un nombre entre 0 et 999');
    } else {
		calcul(num);
		bon = true
	}
}

// Les tableau sont déja utilisée il n'a donc pas d'exercice 2 comme dit en classe