const min = 1; 
const max = 10000; 
const numDeFois = 10;
const temps = 500
let i = 0
function num(){
		let debut = new Date().getTime();
		let random = Math.floor((Math.random() * (max - min) + min)); 
		let bin = random.toString(2);
		document.write(random + "  =  " + bin + "<br>")
		let fin = new Date().getTime();
		let time = fin - debut;
		document.write("Le temps d'execution est: " + time + " ms" + "<br>")
		i++;
		if (i >= numDeFois){
			clearInterval(interval);
		}
}
let interval = setInterval(num, temps);
