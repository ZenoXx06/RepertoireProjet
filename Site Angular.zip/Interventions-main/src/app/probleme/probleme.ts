export interface IProbleme{
    id: number,
    prenom: string,
    nom: string,
    noTypeProbleme: number,
    courriel?: string,
    telephone?: string,
    notification: string,
    noUnite?: string,
    descriptionProbleme: string
}